import React, { SetStateAction, Dispatch } from "react";
import { JSX } from "react/jsx-runtime";
import { UseMutationResult, NoInfer, UseQueryResult, UseInfiniteQueryOptions, InfiniteData, UseInfiniteQueryResult } from "@tanstack/react-query";
import { AccessCodeIdEnum as _AccessCodeIdEnum1, AccessMethodIdEnum as _AccessMethodIdEnum1, AccessCodeTypeIDEnum as _AccessCodeTypeIDEnum1, DamageDepositModeId as _DamageDepositModeId1, JoinStatusIDEnum as _JoinStatusIDEnum1, EmergencyContact as _EmergencyContact1, Amenity as _Amenity1, PropertyPermission as _PropertyPermission1, RequiredSubformsEnum as _RequiredSubformsEnum1, OptionalSubformsEnum as _OptionalSubformsEnum1, User as _User1, WithRequiredProperty as _WithRequiredProperty1, APIResponse as _APIResponse1 } from "api";
import { InfiniteData as _InfiniteData1, QueryObserverRefetchErrorResult, QueryObserverSuccessResult, QueryObserverLoadingErrorResult, QueryObserverPendingResult, QueryObserverPlaceholderResult } from "@tanstack/query-core";
import dayjs, { Dayjs } from "dayjs";
import * as yup from "yup";
import { AnyObject } from "yup/lib/types";
import { RequiredBooleanSchema } from "yup/lib/boolean";
import { RequiredStringSchema } from "yup/lib/string";
import { RequiredNumberSchema } from "yup/lib/number";
import { ObjectShape, Assign, AnyObject as _AnyObject1, TypeOfShape, AssertsShape, OptionalObjectSchema } from "yup/lib/object";
import { RequiredDateSchema } from "yup/lib/date";
import { CountryCode, CountryCallingCode } from "libphonenumber-js";
export enum FetchMethods {
    GET = "GET",
    PUT = "PUT",
    POST = "POST",
    DELETE = "DELETE"
}
export type FetchMethodTypes = 'GET' | 'PUT' | 'POST' | 'DELETE';
export interface QueryFnOptions {
    isOffline: boolean;
    method?: FetchMethods | FetchMethodTypes;
    values?: any;
    /** Special encoding required for subforms */
    isSubform?: boolean;
    /** Ignore any potential data-transformations, data is already formatted */
    isCustomSendData?: boolean;
}
interface QueryContextValues {
    isOffline: boolean;
    queryFn: <TData = unknown>(url: string, options: QueryFnOptions) => Promise<TData>;
    onSuccessToast: (data: any) => void;
    onErrorToast: (data: any) => void;
}
export const QueryContext: React.Context<QueryContextValues | null>;
export const useQueryContext: () => QueryContextValues;
interface Props {
    children: React.ReactNode;
}
/** This Provider should be wrapped at a high-level around an app that uses it.
 * Allows access to useAppMutation and useAppQuery
 * Allows us to avoid re-writing hooks using two different version of useAppQuery and useAppMutation
 * Provides runtime configuration changes which determine offline functionality, how toasts are display and the query function that is used
 * */
export const QueryContextProvider: ({ children, isOffline, onErrorToast, onSuccessToast, queryFn, }: Props & QueryContextValues) => JSX.Element;
interface Args<TVariables = any, TData = any> {
    /** Pass in string unless you need to modify the url based on TVariables data
     * Pass in a function and an array in TVariables urlArgs field to modify the url on send
     * ex) function fun(a, b, c) => string
     *     values.urlArgs = [1, 2, 3]
     * */
    url: string | ((...args: string[]) => string);
    method: FetchMethods | FetchMethodTypes;
    isCustomSendData?: boolean;
    isSubform?: boolean;
    onSuccess?: (data: TData, variables: TVariables) => Promise<unknown> | void;
    onError?: (error: unknown, variables: TVariables, context: void | undefined) => Promise<unknown> | void;
    onSettled?: (data: any, error: unknown, variables: TVariables, context: void | undefined) => Promise<unknown> | void;
    onMutate?: (value: any) => void;
    hasToastsEnabled?: boolean;
    mutationKey?: string;
    hasSuccessToastEnabled?: boolean;
    hasErrorToastEnabled?: boolean;
    /** modify the data before its sent, useful for encapsulating logic in a custom mutation hook */
    modifySendDataFn?: (data: TVariables) => any;
}
export type ConfigurableAppMutationArgs = Omit<Args, 'url' | 'method' | 'isCustomSendData' | 'isSubform'>;
export const useAppMutation: <TVariables = any, TData = any>({ url, method, isCustomSendData, isSubform, onSuccess, onError, onSettled, onMutate, hasToastsEnabled, mutationKey, hasSuccessToastEnabled, hasErrorToastEnabled, modifySendDataFn, }: Args<TVariables, TData>) => UseMutationResult<TData, Error, TVariables, void>;
export const bookingEndpoint = "/RESTAUTH/booking/";
export const bookingQuoteEndpoint = "/RESTAUTH/booking/quote/";
export const bookingNotesEndpoint = "/RESTAUTH/booking/notes/";
export const reviewPublishEndPoint = "/RESTAUTH/booking/review/publish/";
export const reviewDisputeEndpoint = "/RESTAUTH/booking/review/dispute/";
export const reviewResponseEndpoint = "/RESTAUTH/booking/review/response/";
export const bookingEmailEndpoint = "/RESTAUTH/booking/email/";
export const bookingcustomMessageEndpoint = "/RESTAUTH/booking/custommessage/";
export const generateBookingEmailEndpoint: (reservationId: number, emailTemplate: "details" | "checkin", cc_emails?: string) => string;
export const generateBookingCancellationDetailEndpoint: (bookingId: string) => string;
export const generateQuoteEndPoint: () => string;
export const generateBookingContactTracingEndpoint: () => string;
export const generateBookingNotesEndpoint: (notesParamString: any) => string;
export const generateBookingPropertyGuidebook: (ownerId: number) => string;
export const generateBookingPropertyGuidebookBinaryEndpoint: ({ bookingId }: {
    bookingId: number;
}) => string;
/** @param guestEmail the email of the guest to check if a guest account with that email exists */
export const generateBookingGuestExists: (guestEmail: string) => string;
interface Values {
    bookingId: number;
    message?: string;
    entry_code?: string;
}
export const useCustomMessageMutation: (args: ConfigurableAppMutationArgs) => UseMutationResult<any, Error, Values, void>;
interface _Args1<T> {
    endpoint: string;
    queryKey?: string | string[];
    enabled?: boolean;
    select?: (data: any) => T;
    onSuccess?: (data: T) => void;
    onError?: (err: any) => void;
    onSettled?: (data: T | undefined, err: any) => void;
    retry?: boolean | number | ((failureCount: number, error: Error) => boolean) | undefined;
    staleTime?: number | undefined;
    cacheTime?: number | undefined;
    refetchOnWindowFocus?: boolean;
    refetchInterval?: number | false;
    useErrorBoundary?: boolean;
    hasToastsEnabled?: boolean;
}
/** Include this type as an argument with your custom query hook to gain access to the defined useQuery methods listed as args in useAppQuery
 * These methods include onSuccess, onError, onSettled, retry, staleTime, cacheTime, etc.
 */
export type ConfigurableAppQueryArgs<T = any> = Omit<_Args1<T>, 'endpoint' | 'queryKey'>;
export function useAppQuery<TData = any>({ endpoint, enabled, select, onSuccess, onError, onSettled, staleTime, cacheTime, retry, refetchOnWindowFocus, queryKey, refetchInterval, hasToastsEnabled, useErrorBoundary, }: _Args1<TData>): UseQueryResult<NoInfer<TData>, Error>;
export const address: {
    AREA: string;
    AREA_ID: number;
    CITY: string;
    COUNTRY: string;
    COUNTRY_CODE: string;
    COUNTRY_ID: number;
    DEVELOPMENT: string;
    DEVELOPMENT_ID: number;
    ID: number;
    LATITUDE: number;
    LONGITUDE: number;
    POSTAL: string;
    REGION: string;
    REGION_ID: number;
    RESORT: string;
    RESORT_ID: number;
    STREET_NAME: string;
    STREET_NUMBER: string;
    UNIT: string;
};
export const amenity: {
    ID: number;
    NAME: string;
    INSTRUCTIONS: string;
    DESCRIPTION: string;
    PROPERTY_AMENITY_ID: number;
    /** Optional field on an amenity */
    ACCESS_CODE: string;
    /** Only appears when using the internet amenity */
    INTERNET_PASSWORD: string;
    INTERNET_NETWORK_NAME: string;
};
export const CANCELLATION_POLICY: {
    ADMIN_PENALTY: number;
    ADMIN_PENALTY_UNIT: string;
    BOOKING_GRACE_PERIOD: string;
    DATE_ACTIVATED: string;
    DATE_LAST_UPDATED: string;
    DATE_RANGES: {
        DATE_ACTIVATED: string;
        DESCRIPTION: string;
        FROM_DAYS: string;
        ID: number;
        LABEL: string;
        REFUND_PERCENTAGE: string;
        TO_DAYS: string;
    }[];
    DESCRIPTION: string;
    ID: number;
    IS_CREDIT_ONLY_REFUND: boolean;
    IS_REFUND_REBOOKED_DATES: boolean;
    IS_SPECIAL_CIRCUMSTANCE: boolean;
    NAME: string;
    POLICY_ID: number;
    SERVICE_FEE_REFUND: string;
    SPECIAL_CIRCUMSTANCE_DESCRIPTION: string;
    SPECIAL_CIRCUMSTANCE_ID: number;
    SPECIAL_CIRCUMSTANCE_NAME: string;
    SURCHARGE_REFUND: string;
};
export const notification: {
    CATEGORY_ID: NotificationCategoryIdEnum;
    LEVEL_ID: number;
    IS_DISMISSIBLE: boolean;
    DATE_CREATED: string;
    CATEGORY_LINK_ID: number;
    LEVEL_NAME: NotificationLevelsEnum;
    LEVEL: number;
    HTML_CONTENT: string;
    IS_FEATURED: boolean;
    IS_DISMISSED: boolean;
    CATEGORY: NotificationCategoriesEnum;
    DATE_DISMISSED: string;
    ID: number;
    IMAGE_URL: string;
    TITLE: string;
    DESCRIPTION: string;
    PROPERTY_ID: number;
    PROPERTY_NAME: string;
    PROPERTY_ADDRESS: string;
};
export const NOTIFICATION_ENDPOINT_RESPONSE: {
    PROPERTY_ID: number;
    UNREAD_COUNT: number;
    NOTIFICATIONS: AlluraNotification[];
};
export const BLACKOUT_PERIOD: {
    ID: number;
    START: string;
    END: string;
};
export const OFFER: {
    BLACKOUT_PERIODS: BlackoutPeriod[];
    CODE: string;
    DESCRIPTION: string;
    DISTRIBUTION: string;
    DISTRIBUTION_ID: number;
    DOLLAR: string;
    GIFT_CERTIFICATE_URL: string;
    GUEST_EMAIL: string;
    GUEST_ID: number;
    INSTRUCTIONS: string;
    IS_ALL_PROPERTIES: boolean;
    IS_EDITABLE: boolean;
    IS_ENABLED: boolean;
    IS_PERMANENT_REPEAT_GUEST_OFFER: boolean;
    IS_PROMOTED: boolean;
    IS_PUBLIC: boolean;
    MAX_USAGE_COUNT: number;
    MIN_NIGHTS: number;
    NIGHTS_FREE: number;
    NIGHTS_REQUIRED: number;
    OFFER_AVAILABILITY_ID: number;
    OFFER_AVAILABLE_END: string;
    OFFER_AVAILABLE_START: string;
    OFFER_CATEGORY: string;
    OFFER_CATEGORY_ID: number;
    OFFER_END: string;
    OFFER_ID: number;
    OFFER_START: string;
    OFFER_TYPE_ID: number;
    OFFER_URL: string;
    PERCENTAGE: number;
    PROMOTED_OFFER_ID: number;
    PROPERTY_IDS: string;
    STATUS: string;
    TITLE: string;
    USAGE_COUNT: number;
    USER_ID: number;
};
export const tax: {
    AMOUNT: string;
    ID: number;
    NAME: string;
};
export const taxSurcharge: {
    IS_PASS_THROUGH_TO_OWNER: boolean;
    AMOUNT: string;
    ID: number;
    NAME: string;
};
export const contactTracingGuest: {
    EMAIL: string;
    FIRST_NAME: string;
    ID: number;
    IS_CHILD: boolean;
    LAST_NAME: string;
    PHONE: string;
};
export const surchargeTaxItem: {
    ACCOUNT: string;
    STRING: string;
};
export const taxItem: {
    AMOUNT: string;
    ID: number;
    IS_PASS_THROUGH_TO_OWNER: boolean;
    NAME: string;
    RATE: number;
};
declare const BOOKING_SURCHARGE: {
    IS_ENABLED: boolean;
    TAX: string;
    TAXES: {};
    FEE: string;
    NAME: string;
    ID: number;
    TOTAL: string;
};
export const BOOKING_SURCHARGES_LIST: {
    [key: string]: typeof BOOKING_SURCHARGE;
};
export const BOOKING_SURCHARGES: {
    GROSS: string;
    LIST: {
        [key: string]: {
            IS_ENABLED: boolean;
            TAX: string;
            TAXES: {};
            FEE: string;
            NAME: string;
            ID: number;
            TOTAL: string;
        };
    };
    NET: string;
    TAXES_TOTAL: string;
    TAXES_TOTALS: {
        AMOUNT: string;
        ID: number;
        IS_PASS_THROUGH_TO_OWNER: boolean;
        NAME: string;
        RATE: number;
    }[];
};
export const DIRECT_VACATIONS: {
    ID: number;
    IS_ACTIVE: boolean;
    LOGO: string;
    NAME: string;
    URL: string;
};
export const propertyGuidebookPDF: {
    PROPERTY_GUIDEBOOK_PDF: string;
    BOOKING_ID: number;
    ID: number;
};
export const propertyOwner: {
    COMPANY_NAME: string;
    FIRST_NAME: string;
    ID: number;
    IS_COMPANY: boolean;
    LAST_NAME: string;
    EMAIL: string;
    THUMBNAIL: string;
};
export const propertyRules: {
    CHECK_IN_TIME: string;
    CHECK_OUT_TIME: string;
    MAX_GUESTS: number;
    QUIET_TIME: string;
};
export const serviceFee: {
    DESCRIPTION: string;
    FEE: string;
    ID: number;
    NAME: string;
    TAX: string;
    TAXES: {
        AMOUNT: string;
        ID: number;
        IS_PASS_THROUGH_TO_OWNER: boolean;
        NAME: string;
        RATE: number;
    }[];
    TAXES_STRING: string;
    TOTAL: string;
};
export const accommodationTaxItem: {
    AMOUNT: string;
    NAME: string;
};
export const totalsPaid: {
    ACCOMMODATION_NET: string;
    ACCOMMODATION_TAXES: {
        AMOUNT: string;
        NAME: string;
    }[];
    BANK_DEPOSIT: string;
    COMMISSION: string;
    COMMISSION_PARTNER: string;
    CREDIT_CARD_FEE: string;
    DAMAGE_DEPOSIT: string;
    NR6: string;
    OWNER_PASS_THROUGH_TAXES: {
        AMOUNT: string;
        ID: number;
        IS_PASS_THROUGH_TO_OWNER: boolean;
        NAME: string;
        RATE: number;
    }[];
    REVENUE_NET: string;
    PROPERTY_MANAGER_SERVICE_FEE: {
        IS_FEE_ON_SUBTOTAL_TO_OWNER: boolean;
        NET: string;
        TAXES: {
            AMOUNT: string;
            ID: number;
            IS_PASS_THROUGH_TO_OWNER: boolean;
            NAME: string;
            RATE: number;
        }[];
        TOTAL: string;
    };
    SURCHARGE: {
        TAXES: {
            AMOUNT: string;
            ID: number;
            IS_PASS_THROUGH_TO_OWNER: boolean;
            NAME: string;
            RATE: number;
        }[];
        NET: string;
    };
    SURCHARGE_NET: string;
    SURCHARGE_TAXES: {
        AMOUNT: string;
        ID: number;
        IS_PASS_THROUGH_TO_OWNER: boolean;
        NAME: string;
        RATE: number;
    }[];
    TAX: string;
};
export const serviceFeeTaxItem: {
    AMOUNT: number;
    ID: number;
    NAME: string;
    RATE: number;
};
export const transaction: {
    AMOUNT: string;
    BANK_DEPOSIT: {
        ACCOUNT: string;
        AMOUNT: string;
        DATE: string;
    };
    BOOKING_NET: string;
    CATEGORY: string;
    COMMISSION: {
        GST: string;
        MRDT: string;
        NET: string;
        PST: string;
        TOTAL: string;
    };
    CREDIT_CARD: {
        CARDHOLDER_NAME: string;
        NAME: string;
        NUMBER: string;
    };
    CREDIT_CARD_WITHHELD: string;
    DAMAGE_DEPOSIT_AMOUNT: string;
    DATE: string;
    ID: number;
    NR6_PERCENTAGE: number;
    NR6_WITHHELD: string;
    SERVICE_FEE: {
        FEE: number;
        ID: number;
        NAME: string;
        TAX: number;
        TAXES: {
            AMOUNT: number;
            ID: number;
            NAME: string;
            RATE: number;
        }[];
        TOTAL: number;
    };
    SURCHARGES: {
        GROSS: string;
        LIST: {
            [key: string]: {
                IS_ENABLED: boolean;
                TAX: string;
                TAXES: {};
                FEE: string;
                NAME: string;
                ID: number;
                TOTAL: string;
            };
        };
        NET: string;
        TAXES_TOTAL: string;
        TAXES_TOTALS: {
            AMOUNT: string;
            ID: number;
            IS_PASS_THROUGH_TO_OWNER: boolean;
            NAME: string;
            RATE: number;
        }[];
    };
    TAX: {
        TAXES: {
            AMOUNT: string;
            ID: number;
            IS_PASS_THROUGH_TO_OWNER: boolean;
            NAME: string;
            RATE: number;
        }[];
        TOTAL: string;
        WITHHELD: {
            MRDT: string;
            PST: string;
        };
    };
    TYPE: string;
};
export const initialLocationData: {
    COUNTRIES: NameIdItem[];
    REGIONS: LocationDataRegion[];
    AREAS: NameIdItem[];
    RESORTS: LocationDataResort[];
    DEVELOPMENTS: LocationDataDevelopment[];
    PROPERTY_CATEGORIES: NameIdItem[];
};
export const RESERVATION_SETTINGS: {
    DEPOSIT_PERCENTAGE: number;
    BALANCE_DAYS_BEFORE_ARRIVAL: number;
    BOOKING_GATEWAY_MODE_ID: number;
};
export type NotificationEndpointResponse = typeof NOTIFICATION_ENDPOINT_RESPONSE;
export type PropertyGuidebookPDF = typeof propertyGuidebookPDF;
export type BookingSurchargesList = typeof BOOKING_SURCHARGES_LIST;
export type Address = typeof address;
export type CancellationPolicy = typeof CANCELLATION_POLICY;
export type Tax = typeof tax;
export type TaxSurcharge = typeof taxSurcharge;
export type Transaction = typeof transaction;
export type LocationDetails = typeof initialLocationData;
export type AlluraNotification = typeof notification;
export type Amenity = typeof amenity;
export type BlackoutPeriod = typeof BLACKOUT_PERIOD;
/** Group an api url with corresponding methods and typings!
 * Makes it easy for developers to put together related info regarding an endpoint
 */
export type APIEndpoint<TEndpoint = any, TReturn = any, TSend = any> = {
    endpoint: TEndpoint;
    method: FetchMethods | FetchMethodTypes;
    returnType: TReturn;
    sendType?: TSend;
};
export type APIResponse<T> = {
    DATA: T;
    ERRORS: {
        CLIENT_MESSAGE?: string;
        DEVELOPER_MESSAGE?: string;
    };
    MESSAGES: {
        CLIENT_MESSAGE?: string;
        DEVELOPER_MESSAGE?: string;
    };
    SUCCESS: boolean;
};
export interface APIKeyResponse<T, P extends string> extends Omit<APIResponse<T>, 'DATA'> {
    DATA: {
        [key in P]: T;
    };
}
export type WithRequiredProperty<Type, Key extends keyof Type> = Type & {
    [Property in Key]-?: Type[Property];
};
export enum SurchargeIDEnum {
    cleaningFee = 1,
    petFee = 2
}
export enum SurchargeNameEnum {
    cleaning = "CLEANING",
    pet = "PETS"
}
export enum TaxIDEnum {
    GST = 1,
    PST = 2,
    MRDT = 19
}
export enum NotificationCategoriesEnum {
    NEWS = "news",
    BOOKING = "booking",
    FINANCE = "finance",
    INQUIRIES = "inquiry",
    PROPERTIES = "properties",
    REVIEW = "review",
    RESERVATION_REQUEST = "reservation_request",
    SUBSCRIPTION_RENEWAL = "subscription_renewal",
    UNBOOKABLE_DATES = "unbookable_dates",
    UPDATE_LISTING = "update_listing"
}
export enum NotificationCategoryIdEnum {
    ALLURA_NEWS = 1,
    BOOKING = 2,
    FINANCE = 3,
    INQUIRY = 4,
    REVIEW = 5,
    /** Appears when a property is in gateway closed mode */
    RESERVATION_REQUEST = 6,
    SUBSCRIPTION_RENEWAL = 7,
    UNBOOKABLE_DATES = 8,
    UPDATE_LISTING = 9
}
export enum NotificationEndpointFilterCategory {
    NEWS = "news",
    FEATURED = "featured",
    PRIMARY = "primary"
}
export enum NotificationEndpointFilterStatus {
    ALL = "all",
    DISMISSED = "dismissed",
    ACTIVE = "active"
}
export enum NotificationLevelsEnum {
    INFORMATIONAL = "informational",
    DEADLINE_APPROACHING = "deadline approaching",
    REQUIRES_ACTION = "requires action",
    URGENT_NOTICE = "urgent notice"
}
export enum DamageDepositModeId {
    COLLECT_AT_CHECKIN = 1,
    COLLECT_45_DAYS_BEFORE_ARRIVAL = 3,
    COLLECT_DAMAGE_UPON_DEPARTURE = 4
}
export interface LocationDataResort {
    REGION_ID: number;
    NAME: string;
    ID: number;
}
export interface LocationDataDevelopment {
    AREA_ID: number;
    ID: number;
    NAME: string;
    RESORT_ID: number;
}
export interface LocationDataRegion {
    ID: number;
    NAME: string;
    COUNTRY_ID: number;
}
export interface NameIdItem {
    NAME: string;
    ID: number;
}
export enum PropertyTaxIDEnum {
    GST = 1,
    PST_BC = 2,
    MRDT_WHISTLER = 19
}
export enum PropertyAmenityId {
    PRIVATE_SKI_STORAGE = 14,
    PRIVATE_BIKE_STORAGE = 15,
    BUILDING_BIKE_STORAGE = 21,
    BUILDING_SKI_STORAGE = 22,
    BUILDING_HOT_TUB = 25,
    BUILDING_SAUNA = 26,
    BUILDING_STEAM_ROOM = 27,
    BUILDING_POOL = 28,
    BUILDING_FITNESS_FACILITIES = 30,
    BUILDING_GAMES_REC_ROOM = 31,
    WIFI = 93
}
export enum LocationURLParamsEnum {
    developments = "developments",
    countries = "countries",
    resorts = "resorts",
    regions = "regions",
    areas = "areas",
    property_categories = "property_categories"
}
export enum ToastVariants {
    default = "default",
    error = "error",
    success = "success",
    warning = "warning",
    info = "info"
}
export enum NotificationStatus {
    DISMISSED = "dismissed",
    ACTIVE = ""
}
export type ContactTracingGuest = typeof contactTracingGuest;
export type PropertyOwner = typeof propertyOwner;
export type InfiniteQueryPageDirections = 'future' | 'past';
export type Property = typeof initialPropertyState;
export type UnavailableDates = typeof UNAVAILABLE_DATES;
export type BankDeposits = typeof BANK_DEPOSITS;
export type PropertySurcharge = typeof SURCHARGE;
export type PropertySurcharges = typeof PROPERTY_SURCHARGES;
export type Photo = typeof PHOTO;
export type PropertyDefaultContent = typeof PROPERTY_DEFAULT_CONTENT;
export type ExternalEvent = typeof EXTERNAL_EVENT;
export type LastAndNextGuest = typeof initialLastAndNextGuest;
export type PropertyReviews = typeof PROPERTY_REVIEWS;
/** Returned from /property/ratesuggestion/ */
export type RateSuggestions = typeof RATE_SUGGESTIONS;
/** Return from /property/rateschedule/generate/optimize/ */
export type RateScheduleGenerateOptimize = typeof RATE_SCHEDULE_GENERATE_OPTIMIZE;
/** /property/rateschedule/generate/insight/ */
export type RateScheduleGenerateInsight = typeof RATE_SCHEDULE_GENERATE_INSIGHT;
export type AccessToUnit = typeof ACCESS_TO_UNIT;
export type PropertyCodes = typeof initialPropertyState.CODES;
export type RateSuggestion = typeof RATE_SUGGESTION;
export type ReservationSettings = typeof RESERVATION_SETTINGS;
export interface CalendarDate extends Omit<typeof calendarDate, 'SEASON'> {
    SEASON: SparseSeason;
}
export type CalendarDates = CalendarDate[];
export interface CalendarEvent extends Omit<typeof calendarEvent, 'TYPE'> {
    TYPE: EventTypeEnum;
}
export type CalendarEvents = CalendarEvent[];
export interface Bed {
    NAME: string;
    ID: number;
    QUANTITY: number;
}
export interface BathroomAmenity {
    CATEGORY: string;
    NAME: string;
    CATEGORY_ID: number;
    ID: number;
}
export interface Bathroom {
    DESCRIPTION: string;
    HAS_BATH: boolean | null;
    HAS_SHOWER: boolean | null;
    ID: number;
    IS_ENSUITE: boolean;
    NAME: string;
    AMENITIES_BATHROOM: BathroomAmenity[];
}
export enum BedroomTypeIDEnum {
}
export interface Bedroom {
    BEDS: Bed[];
    DESCRIPTION: string;
    HAS_ENSUITE: boolean;
    HAS_STAIRS: boolean;
    ID: number;
    IS_COMMON_AREA: boolean;
    IS_DEN: boolean;
    IS_LOFT: boolean;
    LEVEL: number;
    NAME: string;
    SLEEPS: number;
    TYPE: {
        ID: number;
        NAME: string;
    };
}
export interface EmergencyContact {
    DESCRIPTION: string;
    EMAIL: string;
    ID: number;
    FIRST_NAME: string;
    LAST_NAME: string;
    PHONE: string;
    COMPANY_NAME: string;
    IS_COMPANY: boolean;
    TYPE: string;
    TYPE_ID: number;
}
export enum EventTypeEnum {
    Blockoff = "blockoff",
    Booking = "booking",
    Cleaning = "cleaning",
    ExternalBooking = "external_booking",
    Gap = "gap",
    NewBlockoff = "newBlockoff",
    NewBooking = "newBooking",
    Quote = "quote",
    Season = "season",
    RateSchedule = "rateSchedule"
}
export interface OwnerResponse {
    ID: number;
    MESSAGE: string;
    RESPONSE_DATE: string;
    RESPONSE_TIME: string;
    SUBJECT: string;
    TO_EMAILS: string;
    FROM_EMAIL: string;
    INQUIRY_ID: number;
}
export interface Inquiry {
    ID: number;
    GUEST_REQUESTS: string;
    INQUIRY_TIME: string;
    INQUIRY_DATE: string;
    NIGHTS: number;
    ARRIVAL: string;
    DEPARTURE: string;
    NUM_HOST_RECOMMENDATIONS: string;
    GUEST_PHONE: string;
    GUEST_NAME: string;
    GUEST_EMAIL: string;
    PARTY_SIZE: number;
    OWNER_RESPONSES: OwnerResponse[];
}
export enum JoinStatusIDEnum {
    NotStarted = 1,
    InProgress = 2,
    FormsCompleted = 3,
    ActivationRequested = 4,
    AskedForMoreInformation = 5,
    SetUpInProgress = 6,
    ListingActive = 7,
    ApplicationDeclined = 8,
    DeactivationRequested = 9,
    ListingDisabled = 10,
    ListingInactive = 11
}
export interface Policy {
    DATE_CREATED: Date | string;
    DATE_UPDATED: Date | string;
    DESCRIPTION: string;
    GROUP: 'General' | 'Reservation' | 'House_Rules' | 'Property';
    GROUP_ID: number;
    ID: number;
    IS_EDITABLE: boolean;
    NAME: string;
    PROPERTY_ID: number;
}
export type PolicyCategories = typeof initialPropertyState.POLICIES;
export enum PropertySubscriptionTierIdEnum {
    PREMIUM = 1,
    /** Host Commission */
    STANDARD = 2,
    GUEST_COMMISION = 3
}
export type RatesSettings = typeof RATES_SETTINGS;
export enum RatesSettingsWeekendPremiumId {
    NOT_SET = 0,
    DISABLED = 1,
    DOLLAR = 2,
    PERCENTAGE = 3
}
export enum RatePropertySettingEnum {
    NOT_SET = 0,
    STATIC = 1,
    DYNAMIC = 2
}
export enum RateAvailabilityIdEnum {
    NOT_SET = 0,
    MONTHS_12 = 1,
    MONTHS_15 = 2,
    MONTHS_18 = 3,
    UNRESTRICTED = 4,
    MONTHS_6 = 5
}
export type RateGroups = typeof RATES_SETTINGS.RATE_GROUPS;
export type AvailabilityWindow = typeof RATES_SETTINGS.AVAILABILITY_WINDOW;
export interface RateGroup {
    ID: number;
    NAME: string;
    RATE_GROUP_TYPE_ID: RateGroupTypesIdEnum;
    PROPERTY_ID: number;
    BASE_RATE: string;
    MIN_NIGHTS: number;
}
export interface RateSchedule {
    /** The id of this specific rate schedule, set to 0 for a new rate schedule to be saved on the backend */
    ID: number;
    NAME: string;
    /** The actual setting id. 1-4 for low,mid,high,prime and 7 for manual */
    RATE_GROUP_TYPE_ID: RateGroupTypesIdEnum;
    BASE_RATE: string;
    DATE_ADDED: string;
    MIN_NIGHTS: number;
    IS_WEEKEND_PREMIUM_ENABLED: boolean;
    IS_DISCOUNT_GROUP_ENABLED: boolean;
    /** 0 for disabled, otherwise the date range gets its base rate automatically updated each month at the pricing level set */
    RATE_INSIGHTS_LEVEL_ID: 0 | RateInsightLevelIdEnum;
    /** Users can overwrite the property setting for optimized pricing by modifying an individual rate schedule */
    IS_OPTIMIZED_PRICING_ENABLED: boolean;
}
export interface ServerRateSchedule extends RateSchedule {
    START: string;
    END: string;
}
export interface Rate {
    ID: number;
    NIGHTS: number;
    RATE: string;
}
export enum RateGroupTypesIdEnum {
    LOW = 1,
    MID = 2,
    HIGH = 3,
    PRIME = 4,
    MANUAL = 7
}
export interface Season {
    COMMENT: string;
    ID: number;
    NAME: string;
    RATES: Rate[];
    END: string;
    START: string;
}
export enum SeasonType {
    newSeason = "newSeason",
    alluraSeason = "alluraSeason"
}
export type SparseRate = typeof sparseRate;
export interface SparseSeason extends Omit<typeof sparseSeason, 'RATES'> {
    RATES: SparseRate[];
}
export interface Suitability {
    ID: number;
    IS_SUITABLE: boolean;
    NAME: string;
    DESCRIPTION: string;
}
export enum SurchargeId {
    SMOKING = 1,
    PETS = 2,
    LONG_TERM_RENTALS = 3,
    PARTIES_AND_EVENTS = 4,
    TRAVEL_RESELLERS = 5,
    WHEELCHAIR_ACCESSIBLE = 6
}
export interface Surcharge {
    NAME: string;
    ID: SurchargeId;
    VALUE: number;
}
export enum BookingGateWayModeIdEnum {
    closed = 1,
    open = 2
}
export enum PropertyFeesIdEnum {
    Cleaning = 1,
    Pets = 2
}
export interface EmergencyContact {
    ID: number;
    FIRST_NAME: string;
    LAST_NAME: string;
    COMPANY_NAME: string;
    IS_COMPANY: boolean;
    EMAIL: string;
    PHONE: string;
    DESCRIPTION: string;
    TYPE: string;
}
export type EmergencyContacts = typeof initialPropertyState.EMERGENCY_CONTACTS;
export type ITNInformation = typeof ITN_INFORMATION;
export enum PropertyDefaultContentTypes {
    TITLE = "title",
    SEARCHSUMMARY = "searchsummary",
    DESCRIPTION = "description"
}
export enum GenerateRateMode {
    DEFAULT = "",
    BLANK = "blank/",
    MANUAL = "manual/"
}
export interface TransactionsOrReservationsServerSearchTool {
    sort: SearchFiltersFilterByItemValue;
    source: SearchFilterSourceItemValue;
    status: SearchFiltersStatusEnum;
    startDate: string;
    endDate: string;
}
export enum PropertyInstructionsEnum {
    aboutTheBuilding = "about_the_building",
    checkIn = "check_in",
    checkOut = "check_out",
    toFromLifts = "to_from_lifts",
    emergencyContacts = "emergency_contacts",
    frontDesk = "front_desk",
    garbageAndRecycling = "garbage_recycling",
    gettingAround = "getting_around",
    heating = "heating",
    housekeeping = "housekeeping",
    lateCheckIn = "late_check_in",
    linensAndTowels = "linens_and_towels",
    location = "location",
    other = "other",
    parking = "parking",
    welcome = "welcome",
    restaurants = "restaurants",
    services = "services",
    skiInSkiOut = "ski_in_ski_out",
    whatToBring = "what_to_bring",
    gettingToUnit = "getting_to_unit"
}
export enum RateInsightLevelIdEnum {
    low = 1,
    lowMid = 2,
    mid = 3,
    midHigh = 4,
    high = 5
}
export enum PricingStrategyEnum {
    rateGroup = 1,
    smartPricing = 2
}
export interface NoRatesDate {
    START_MONTH: number;
    END_MONTH: number;
    START_DAY: number;
    END_DAY: number;
    ID: number;
}
export enum GuidebookWizardFormNamesEnum {
    amenities = "AmenitiesSubform",
    checkIn = "CheckinSubform",
    commonQuestions = "CommonQuestionsSubform",
    departure = "DepartureSubform",
    directions = "DirectionsSubform",
    frontDesk = "FrontDeskSubform",
    houseKeeping = "HousekeepingSubform",
    introduction = "Introduction",
    gettingAround = "GettingAroundSubform",
    uniqueCodes = "UniqueCodesSubform",
    welcomeMessage = "WelcomeMessageSubform"
}
export interface GuidebookWalkthrough {
    STEPS: [
        GuidebookWizardFormNamesEnum.introduction,
        GuidebookWizardFormNamesEnum.welcomeMessage,
        GuidebookWizardFormNamesEnum.directions,
        GuidebookWizardFormNamesEnum.checkIn,
        GuidebookWizardFormNamesEnum.departure,
        GuidebookWizardFormNamesEnum.houseKeeping,
        GuidebookWizardFormNamesEnum.uniqueCodes,
        GuidebookWizardFormNamesEnum.amenities,
        GuidebookWizardFormNamesEnum.gettingAround,
        GuidebookWizardFormNamesEnum.frontDesk,
        GuidebookWizardFormNamesEnum.commonQuestions
    ];
    COMPLETION_PERCENTAGE: number;
    COMPLETED_STEPS: GuidebookWizardFormNamesEnum[];
    NUM_STEPS: number;
}
/** Setup Questions form which platforms are you listed on */
export enum PlatformListedId {
    airbnb = 1,
    vrbo = 2,
    my_site = 3,
    other = 4
}
export enum RequiredSubformsEnum {
    AccessToUnitForm = "AccessToUnitForm",
    AccountOwnerForm = "AccountOwnerForm",
    ActivationForm = "ActivationForm",
    AdvancedBookingSettingsForm = "AdvancedBookingSettingsForm",
    BankingForm = "BankingForm",
    BathroomsForm = "BathroomsForm",
    BedroomsForm = "BedroomsForm",
    BuildingAmenitiesForm = "BuildingAmenitiesForm",
    BusinessLicenceForm = "BusinessLicenceForm",
    CalendarBlockOffsForm = "CalendarBlockOffsForm",
    CancellationPoliciesForm = "CancellationPoliciesForm",
    CheckInOutForm = "CheckInOutForm",
    CleaningProtocolForm = "CleaningProtocolForm",
    DamageDepositForm = "DamageDepositForm",
    EmergencyContactsForm = "EmergencyContactsForm",
    EssentialAmenitiesForm = "EssentialAmenitiesForm",
    KitchenAmenitiesForm = "KitchenAmenitiesForm",
    LocationForm = "LocationForm",
    MembershipForm = "MembershipForm",
    NewListingOfferForm = "NewListingOfferForm",
    NonResidentStatusForm = "NonResidentStatusForm",
    ParkingForm = "ParkingForm",
    PartnersForm = "PartnersForm",
    PhotosForm = "PhotosForm",
    PrivateSafetyAmenitiesForm = "PrivateSafetyAmenitiesForm",
    PropertyAddressForm = "PropertyAddressForm",
    PropertyContactForm = "PropertyContactForm",
    RateGroupForm = "RateGroupForm",
    RateSettingsForm = "RateSettingsForm",
    RatesScheduleForm = "RatesScheduleForm",
    ReservationSettingsInstantBookingForm = "ReservationSettingsInstantBookingForm",
    ReservationSettingsPaymentScheduleForm = "ReservationSettingsPaymentScheduleForm",
    SetupQuestionsForm = "SetupQuestionsForm",
    StyleSquareFootageForm = "StyleSquareFootageForm",
    SuitabilitiesForm = "SuitabilitiesForm",
    SurchargesForm = "SurchargesForm",
    TaxesForm = "TaxesForm"
}
export enum OptionalSubformsEnum {
    AllAmenitiesFormOptional = "AllAmenitiesForm",
    PropertyTitleSummaryFormOptional = "PropertyTitleSummaryFormOptional",
    BedroomsFormOptional = "BedroomsFormOptional",
    BathroomsFormOptional = "BathroomsFormOptional",
    LocationFormOptional = "LocationFormOptional",
    EssentialAmenitiesFormOptional = "EssentialAmenitiesFormOptional",
    PrivateSafetyAmenitiesFormOptional = "PrivateSafetyAmenitiesFormOptional",
    KitchenAmenitiesFormOptional = "KitchenAmenitiesFormOptional",
    BuildingAmenitiesFormOptional = "BuildingAmenitiesFormOptional",
    CheckInOutFormOptional = "CheckInOutFormOptional",
    CheckInEmailFormOptional = "CheckInEmailFormOptional",
    ExtendedDescriptionFormOptional = "ExtendedDescriptionFormOptional",
    PropertyPoliciesForm = "PropertyPoliciesForm"
}
export type SubformName = OptionalSubformsEnum | RequiredSubformsEnum;
declare const TAX: {
    REGION_NAME: string;
    IS_MANDATORY: boolean;
    IS_REGISTRATION_NUMBER_REQUIRED: boolean;
    NAME: string;
    ID: number;
    RESORT_NAME: string;
    RATE: number;
    COUNTRY_NAME: string;
    DESCRIPTION: string;
};
export const initialFormInputs: {
    ACCESS_TO_UNIT: {
        TYPES: {
            NAME: string;
            ID: AccessCodeIdEnum;
        }[];
        METHODS: {
            NAME: string;
            ID: AccessMethodIdEnum;
        }[];
        CODES: {
            NAME: string;
            ID: AccessCodeTypeIDEnum;
        }[];
    };
    ADVANCED_BOOKING: NameIdItem[];
    AMENITIES: Amenities;
    AMENITY_CATEGORIES: AmenityCategories;
    BEDROOM_TYPES: BedroomTypes[];
    BED_TYPES: BedroomTypeItem[];
    CONTACT_EMAIL_NOTIFICATION_TYPES: LabelNameItem[];
    DAMAGE_DEPOSIT_MODES: NameIdItem[];
    DEFAULT_CHANNELS: Channel[];
    EMERGENCY_CONTACT_TYPES: EmergencyContactType[];
    JOIN_STATUSES: JoinStatusItem[];
    MILESTONE_MESSAGES: any;
    NON_RESIDENT: {
        MIN_OWNERS: number;
        MAX_OWNERS: number;
    };
    PARTNERS: any;
    CLEANING_PROTOCOL_URL: string;
    PHOTO_VALIDATION: PhotoValidation;
    POLICIES: Policies;
    POLICIES_CANCELLATION: CancellationPolicy[];
    POLICIES_CANCELLATION_SPECIAL: NameIdDescriptionItem[];
    POLICIES_MANDATORY: NameIdItem[];
    PROPERTY_CATEGORIES: NameIdItem[];
    PROPERTY_MANAGERS: PropertyManagerItem[];
    PROPERTY_STYLES: NameIdItem[];
    RATES_SETTINGS: {
        RATE_GROUP_ITEMS: RateGroupItem[];
        AVAILABILITY_WINDOW: RateAutomationItem[];
        PROPERTY_SETTINGS: PropertySetting[];
        RATE_GROUP_TYPES: PropertySettingItem[];
        WEEKEND_PREMIUMS: PropertySettingItem[];
        LAST_ALLURA_EVENT: string;
        EXTEND_RATES_SCHEDULE_MONTHS: number[];
        REPLACE_RATES_SCHEDULE_MONTHS: number[];
        RATE_INSIGHTS: {
            ID: RateInsightLevelIdEnum;
            NAME: string;
        }[];
    };
    RATES_SETTINGS_SUGGESTIONS: {
        DISCOUNT_GROUP: {
            FIVE_NIGHTS: number;
            ID: number;
            SEVEN_NIGHTS: number;
            TEN_NIGHTS: number;
        };
        WEEKEND_PREMIUM_SUGGESTION: {
            PERCENTAGE_AMOUNT: number;
            DOLLAR_AMOUNT: number;
            ID: RatesSettingsWeekendPremiumId;
        };
        LAST_DAY_OF_SUGGESTIONS: string;
        RATE_INSIGHTS_LEVEL_ID: number;
    };
    RATES_SUGGESTIONS: RateSuggestionItem[];
    RESERVATION_SETTINGS: FormInputsReservationSettings;
    REST_API_SEARCH_MIN_DATE: string;
    SUBSCRIPTION_TIERS: SubscriptionTier[];
    SETUP_QUESTIONS: {
        MOST_IMPORTANT: FormMostImportant[];
        PLATFORMS: FormBookingPlatform[];
    };
    SUBFORMS_OPTIONAL: string[];
    SUBFORMS: {
        OPTIONAL: Subforms[];
        REQUIRED: Subforms[];
    };
    SUITABILITIES: SuitabilityItem[];
    SURCHARGES: NameIdDescriptionItem[];
    TAXES: (typeof TAX)[];
    TAX_NUMBERS: NameIdDescriptionItem[];
    EXTERNAL_CHANNELS: Channel[];
    SEARCH_FILTERS: SearchFilters;
    UNBOOKABLE_NIGHTS_DATE_RANGE: {
        VALUE: number;
        LABEL: string;
    }[];
};
export type FormInputs = typeof initialFormInputs;
export type FormInputKeys = keyof FormInputs;
export type FormInputValues = FormInputs[FormInputKeys];
export enum ResortIdEnum {
    Whistler = 1,
    SunPeaks = 2,
    BigWhite = 3
}
export enum PartnerIdEnum {
    Whistler = 4,
    WhistlerBlackomb = 26
}
export interface NameIdDescriptionItem {
    ID: number;
    NAME: string;
    DESCRIPTION: string;
}
interface TypeItem {
    TYPE: string;
}
export interface LabelNameItem {
    LABEL: string;
    NAME: string;
}
export interface AmenityItem {
    CATEGORY: string;
    LIST: NameIdItem[];
    TITLE: string;
}
export interface Amenities {
    BATHROOM: AmenityItem;
    BUILDING: AmenityItem;
    ESSENTIAL: AmenityItem;
    KITCHEN: AmenityItem;
    LAUNDRY: AmenityItem;
    PRIVATE: AmenityItem;
    SAFETY: AmenityItem;
}
export interface AmenityCategories {
    BATHROOM: TypeItem[];
    BUILDING: TypeItem[];
    ESSENTIAL: TypeItem[];
    KITCHEN: TypeItem[];
    PRIVATE: TypeItem[];
    SAFETY: TypeItem[];
}
export interface BedroomTypeItem {
    DESCRIPTION: string;
    ID: 1;
    IS_BEDROOM: number;
    NAME: string;
    SORT_ORDER: number;
}
export enum CancellationPolicySpecicalCircumstanceIDEnum {
    OneHundredPercentRefund = 1,
    OneHundredPercentCredit = 2,
    Other = 3
}
export interface FormBookingPlatform {
    NAME: 'Airbnb' | 'VRBO' | 'My Own Site' | 'Other';
    ID: PlatformListedId;
}
export interface FormMostImportant {
    NAME: 'Quality Guests' | 'Higher Revenue';
    ID: number;
}
interface PoliciesItem {
    ID: number;
    NAME: string;
    GROUP: string;
    GROUP_ID: number;
    DEFAULT_DESCRIPTION: string;
    IS_EDITABLE: boolean;
}
export interface Policies {
    ACCOUNT: PoliciesItem[];
    CANCELLATION: PoliciesItem[];
    GENERAL: PoliciesItem[];
    GUEST_STAY: PoliciesItem[];
    RESERVATION: PoliciesItem[];
}
export interface PropertyManagerItem {
    COMPANY_NAME: string;
    EMAIL: string;
    FIRST_NAME: string;
    ID: number;
    LAST_NAME: string;
    PHONE: string;
}
export interface SuitabilityItem {
    ID: number;
    IS_SUITABLE: string | boolean;
    NAME: string;
}
export interface BedroomTypes {
    SORT_ORDER: number;
    NAME: string;
    ID: number;
    DESCRIPTION: string;
    IS_BEDROOM: string;
}
export interface Subforms {
    SORT_ORDER: number;
    MILESTONE: number;
    NAME: RequiredSubformsEnum | OptionalSubformsEnum;
    ID: number;
    DESCRIPTION: string;
}
export interface Channel {
    BOOKING_COMMISSION_DESCRIPTION: string;
    DESCRIPTION: string;
    BOOKING_COMMISSION_PERCENTAGE: number;
    CREDIT_CARD_PERCENTAGE: number;
    ID: number;
    LOGO_URL: string;
    TERMS_OF_SERVICE: string;
    WEBSITE_URL: string;
}
export enum SearchFilterSourceEnum {
    ALL = "all",
    AD = "ad",
    DV = "dv",
    WC = "wc",
    VAIL = "vail"
}
export type SearchFilterSourceItemValue = SearchFilterSourceEnum;
interface SearchFilterSourceItem {
    value: SearchFilterSourceEnum;
    label: 'All' | 'alluraDirect' | 'Direct Vacations' | 'Whistler.com' | 'Resort Reservations Vail';
}
export enum SearchFiltersSortEnum {
    ARRIVAL = "arrival",
    ARRIVAL_DATE = "arrival_date",
    BOOKING_DATE = "booking_date"
}
export type SearchFiltersFilterByItemValue = SearchFiltersSortEnum;
interface SearchFiltersFilterByItem {
    value: SearchFiltersFilterByItemValue;
    label: 'Arrival Date' | 'Booking Date';
}
export enum SearchFiltersStatusEnum {
    ALL = "all",
    ACTIVE = "active",
    CANCELLED = "cancelled"
}
export type SearchFiltersStatusItemValue = SearchFiltersStatusEnum;
interface SearchFiltersStatusItem {
    value: SearchFiltersStatusItemValue;
    label: SearchFiltersStatusEnum;
}
export interface SearchFilters {
    SOURCE: SearchFilterSourceItem[];
    FILTER_BY: SearchFiltersFilterByItem[];
    STATUS: SearchFiltersStatusItem[];
}
export interface JoinStatusItem {
    NAME: string;
    ID: number;
}
export interface FormInputsReservationSettings {
    DEPOSIT_PERCENTAGES: number[];
    BALANCE_DUE_DATES: {
        ID: number;
        DESCRIPTION: string;
    }[];
    BOOKING_GATEWAY_MODES: NameIdDescriptionItem[];
}
export interface SubscriptionTier {
    /** premium-only options */
    ANNUAL_FEE: string;
    NUMBER_OF_DAYS: number;
    /** Percentage fee */
    BOOKING_FEE: number;
    /** Percentage fee */
    CREDIT_CARD_FEE: number;
    TITLE: string;
    DESCRIPTION: string;
    SUBTITLE: string;
    ID: number;
    IS_ALLOWED_PRIVATE_SITE: boolean;
    IS_RECOMMENDED: boolean;
    RESORT_ID: number;
    SIMILAR_SITE: string;
    TAXES: [
        {
            NAME: string;
            ID: number;
            TOTAL: string;
            RATE: number;
        }
    ];
}
export enum AccessCodeTypeIDEnum {
    AccessCode = 1,
    PhysicalKeyCard = 2
}
export enum AccessMethodIdEnum {
    FrontDesk = 1,
    Email = 2,
    LockBox = 3,
    Other = 4
}
export enum AccessCodeIdEnum {
    NO_CODE = 0,
    STANDARD_CODE = 1,
    UNIQUE_PER_GUEST = 2
}
export interface PhotoValidation {
    MAX_SIZE_MB: number;
    MIN_HEIGHT_PIXELS: number;
    ACCEPTED_FILE_FORMATS: string;
    ACCEPTED_FILE_FORMATS_EXTENSION: string;
    ACCEPTED_MIME_FORMATS: string;
    LOGO_MAX_SIZE_KB: number;
    LOGO_MAX_SIZE_MB: number;
    MAX_NUMBER_PHOTOS: number;
    MAX_SIZE_BYTES: number;
    MIN_NUMBER_PHOTOS: number;
}
export interface EmergencyContactType {
    SORT_ORDER: number;
    NAME: string;
    ID: number;
}
export interface RateGroupItem {
    TITLE: string;
    DESCRIPTION: string;
    MIN_NIGHTS_RATE: number;
    BASE_RATE: number;
}
export interface RateAutomationItem {
    ID: number;
    NAME: string;
    NUM_MONTHS: number;
}
export interface PropertySettingItem {
    ID: number;
    NAME: string;
}
export interface RateSuggestionItem {
    BASE_RATE: number;
    ID: number;
    MIN_NIGHTS: number;
    RATE_GROUP_TYPE: string;
    RATE_GROUP_TYPE_ID: number;
    RESORT: string;
    RESORT_ID: number;
    SIZE_CATEGORY: string;
    SIZE_CATEGORY_ID: number;
}
export interface PropertySetting extends PropertySettingItem {
    REFERENCE: string;
}
export const GUEST_PROFILE: {
    MEMBER_SINCE: string;
    PERMISSIONS: {
        SHOW_NUM_REVIEWS: boolean;
        SHOW_MEMBER_SINCE: boolean;
        SHOW_NUM_RECOMMENDS: boolean;
    };
    NUM_BOOKINGS: number;
    NUM_RECOMMENDATIONS: number;
    NUM_REVIEWS: number;
};
export const OWNER_PROFILE: {
    PROPERTY_IDS: number[];
    MEMBER_SINCE: string;
};
export interface PropertyPermission {
    PROPERTY_ID: number;
    NOTIFY_CHECKIN_REMINDER: false;
    NOTIFY_RESORT_SPECIFIC: false;
    NOTIFY_GENERAL_INQUIRIES: false;
    NOTIFY_ALL_OWNERS: false;
    NOTIFY_RESERVATION_REQUESTS: false;
    NOTIFY_RENEWALS: false;
    NOTIFY_RESERVATIONS_CANCELLED: false;
    NOTIFY_RESERVATIONS_ADDED: false;
}
export const PROPERTY_MANAGER_PROFILE: {
    PERMISSIONS: PropertyPermission[];
    PROPERTY_IDS: number[];
};
export const COHOST_PROFILE: {
    PERMISSIONS: PropertyPermission[];
    PROPERTY_IDS: number[];
};
export const USER: {
    ID: number;
    FIRST_NAME: string;
    LAST_NAME: string;
    IS_COMPANY: boolean;
    COMPANY_NAME: string;
    THUMBNAIL: string;
    PHONE: string;
    EMAIL: string;
    CREATED_DATE: string;
    DATE_LAST_LOGIN: string;
    DATE_UPDATED: string;
    ADDRESS: {
        AREA: string;
        AREA_ID: number;
        CITY: string;
        COUNTRY: string;
        COUNTRY_CODE: string;
        COUNTRY_ID: number;
        DEVELOPMENT: string;
        DEVELOPMENT_ID: number;
        ID: number;
        LATITUDE: number;
        LONGITUDE: number;
        POSTAL: string;
        REGION: string;
        REGION_ID: number;
        RESORT: string;
        RESORT_ID: number;
        STREET_NAME: string;
        STREET_NUMBER: string;
        UNIT: string;
    };
    IS_SMS_VERIFIED: boolean;
    IS_EMAIL_VERIFIED: boolean;
    DATE_EMAIL_VERIFIED: string;
    DATE_SMS_VERIFIED: string;
    DATE_OF_BIRTH: string;
    /** Django-compatibility fields */
    IS_ACTIVE: boolean;
    IS_STAFF: boolean;
    IS_SUPERUSER: boolean;
    IS_DUE_DILIGENCE_REQUIRED: boolean;
};
/** Inquiry message OR Booking message */
export const MESSAGE: {
    MESSAGE: string;
    SUBJECT: string;
    TO_EMAILS: string;
    DATE_SENT: string;
    FROM_EMAIL: string;
    RECIPIENT: string;
    THUMBNAIL: string;
    TIME_SENT: string;
    ID: number;
    RECIPIENT_ID: number;
    IS_READ: boolean;
    READ_DATE: string;
    READ_TIME: string;
    NUM_UNREAD: number;
    ARRIVAL_DATE: string;
    DEPARTURE_DATE: string;
    CREATED_DATE: string;
    NUM_BEDS: number;
    NUM_GUESTS: number;
    IS_INQUIRY: boolean;
};
/** Only appears on Booking messages */
export const MESSAGE_BOOKING: {
    ID: number;
    ARRIVAL_DATE: string;
    DEPARTURE_DATE: string;
    CREATED_DATE: string;
    REFERENCE: string;
};
export const MESSAGE_PROPERTY: {
    ID: number;
    THUMBNAIL: string;
    NAME: string;
    SIZE_CATEGORY: string;
};
export const MESSAGE_CONTACT: {
    ID: number;
    THUMBNAIL: string;
    NAME: string;
    USER_TYPE_ID: UserRoleIDEnum;
    EMAIL: string;
};
export const USER_LOGIN: {
    IS_AUTHENTICATED_GUEST: boolean;
    IS_AUTHENTICATED_OWNER: boolean;
    GUEST_ID: number;
    OWNER_ID: number;
    HAS_GUEST_AND_OWNER_ACCOUNTS: boolean;
    IS_PASSWORDS_SYNCED: boolean;
    OLD_PASSWORD_USER_ROLE_ID: UserRoleIDEnum;
};
export const GUEST_OWNER_LOGIN: {
    USER_ROLE_ID: UserRoleIDEnum.owner;
    JSESSIONID: string;
    ID: number;
};
export const USER_MESSAGE_SUBJECT: {
    ID: number;
    CONTACT: {
        ID: number;
        THUMBNAIL: string;
        NAME: string;
        USER_TYPE_ID: UserRoleIDEnum;
        EMAIL: string;
    };
    BOOKING: {
        ID: number;
        ARRIVAL_DATE: string;
        DEPARTURE_DATE: string;
        CREATED_DATE: string;
        REFERENCE: string;
    };
    PROPERTY: {
        ID: number;
        THUMBNAIL: string;
        NAME: string;
        SIZE_CATEGORY: string;
    };
    MESSAGE: {
        MESSAGE: string;
        SUBJECT: string;
        TO_EMAILS: string;
        DATE_SENT: string;
        FROM_EMAIL: string;
        RECIPIENT: string;
        THUMBNAIL: string;
        TIME_SENT: string;
        ID: number;
        RECIPIENT_ID: number;
        IS_READ: boolean;
        READ_DATE: string;
        READ_TIME: string;
        NUM_UNREAD: number;
        ARRIVAL_DATE: string;
        DEPARTURE_DATE: string;
        CREATED_DATE: string;
        NUM_BEDS: number;
        NUM_GUESTS: number;
        IS_INQUIRY: boolean;
    };
};
export const USER_MESSAGE_OVERVIEW: {
    ID: number;
    MESSAGE: {
        MESSAGE: string;
        MESSAGE_HTML: string;
        SUBJECT: string;
        TO_EMAILS: string;
        DATE_SENT: string;
        FROM_EMAIL: string;
        RECIPIENT: string;
        THUMBNAIL: string;
        TIME_SENT: string;
        ID: number;
        RECIPIENT_ID: number;
        IS_READ: boolean;
        READ_DATE: string;
        READ_TIME: string;
        NUM_UNREAD: number;
    };
    PROPERTY: {
        ID: number;
        THUMBNAIL: string;
        NAME: string;
        SIZE_CATEGORY: string;
    };
    CONTACT: {
        ID: number;
        THUMBNAIL: string;
        NAME: string;
        USER_TYPE_ID: UserRoleIDEnum;
        EMAIL: string;
        DETAILS: {
            NEXT_RESERVATION_DATE: string;
            MEMBER_SINCE: string;
            HAS_NEXT_RESERVATION: boolean;
            HAS_MEMBER_SINCE: boolean;
            DETAILS_NUMBER_OF_RESERVATIONS: number;
            HAS_NUMBER_OF_RESERVATIONS: boolean;
            HAS_LAST_RESERVATION: boolean;
            LAST_RESERVATION_DATE: string;
        };
    };
};
export const MESSAGE_THREAD: {
    MESSAGE: {
        MESSAGE: string;
        IS_READ: boolean;
        SUBJECT: string;
        TO_EMAILS: string;
        FROM_EMAIL: string;
        THUMBNAIL: string;
        SENT_DATE: string;
        SENT_TIME: string;
        BOOKING_ID: number;
        ID: number;
        READ_DATE: string;
        READ_TIME: string;
        INQUIRY_ID: number;
        SENDER_USER_ID: number;
        SENDER_USER_TYPE_ID: UserRoleIDEnum;
        RECEIVER_USER_ID: number;
        RECEIVER_USER_TYPE_ID: UserRoleIDEnum;
        ARRIVAL_DATE: string;
        DEPARTURE_DATE: string;
        IS_INQUIRY: boolean;
        NUM_BEDS: number;
        NUM_GUESTS: number;
    };
    PROPERTY: {
        ID: number;
        THUMBNAIL: string;
        NAME: string;
        SIZE_CATEGORY: string;
    };
    BOOKING: {
        ID: number;
        ARRIVAL_DATE: string;
        DEPARTURE_DATE: string;
        CREATED_DATE: string;
        REFERENCE: string;
    };
};
export const MESSAGE_UNREAD_COUNT: {
    USER_MESSAGE_COUNT: number;
};
export type UserLogin = typeof USER_LOGIN;
export type GuestOwnerLogin = typeof GUEST_OWNER_LOGIN;
export type UserMessageOverview = typeof USER_MESSAGE_OVERVIEW;
export type UserMessageSubject = typeof USER_MESSAGE_SUBJECT;
export type MessageThreadItem = typeof MESSAGE_THREAD;
export type MessageUnreadCount = typeof MESSAGE_UNREAD_COUNT;
export interface MessageUserContact {
    CONTACT: User;
}
export type UserMessageContact = typeof MESSAGE_CONTACT;
export type UserMessageProperty = typeof MESSAGE_PROPERTY;
/** The allura user is now the root user for all DB operations.
 * Previously, there were separate owner, property manager and guest db tables, but in April of 2022 the decision
 * was made to only have one user type which can have multiple roles.
 */
export type User = typeof USER & {
    OWNER_PROFILE?: typeof OWNER_PROFILE;
    GUEST_PROFILE?: typeof GUEST_PROFILE;
    COHOST_PROFILE?: typeof COHOST_PROFILE;
    PROPERTY_MANAGER_PROFILE?: typeof PROPERTY_MANAGER_PROFILE;
};
export enum UserRoleIDEnum {
    allura = 1,
    owner = 2,
    guest = 3,
    propertyContact = 5
}
export enum UserTypeEnum {
    GUEST = "GUEST",
    OWNER = "OWNER",
    USER = "USER"
}
export enum UserMessageType {
    generalInquiry = 1,
    dateChange = 2,
    cancellation = 3,
    booking = 4,
    property = 5,
    alluraInquiry = 6
}
/** Base data expected when creating a user message */
interface BaseUserMessage {
    /** id of user sending the message */
    id: number;
    /** type of user sending the message */
    user_type_id: UserRoleIDEnum;
    /** id of the user receiving the message. send 0 if receiver_user_type_id is allura[1] */
    receiver_user_id: number;
    /** type of user receiving the message */
    receiver_user_type_id: UserRoleIDEnum;
    /** the actual message contents */
    message: string;
}
/** Use when a user needs to contact allura about help/support/other issue */
interface AlluraInquiryUserMessage extends BaseUserMessage {
    message_type_id: UserMessageType.alluraInquiry;
}
/** Use this when a user is communicating to alluradirect */
interface GeneralInquiryUserMessage extends BaseUserMessage {
    message_type_id: UserMessageType.generalInquiry;
    inquiry_id: number;
}
/** User makes a message about a property.
 *  This is like a general inquiry except it is about a specific property  */
interface PropertyUserMessage extends BaseUserMessage {
    message_type_id: UserMessageType.property;
    property_id: number;
    inquiry_id: number;
}
/** User makes a message about a specific booking */
interface BookingUserMessage extends BaseUserMessage {
    message_type_id: UserMessageType.booking;
    booking_id: number;
}
/** User requests to change booking dates */
interface DateChangeUserMessage extends BaseUserMessage {
    message_type_id: UserMessageType.dateChange;
    booking_id: number;
    start: string;
    end: string;
}
/** User requests to cancel a booking */
interface CancellationUserMessage extends BaseUserMessage {
    message_type_id: UserMessageType.cancellation;
    booking_id: number;
}
export type UserMessage = GeneralInquiryUserMessage | DateChangeUserMessage | CancellationUserMessage | BookingUserMessage | PropertyUserMessage | AlluraInquiryUserMessage;
export const RATES_SETTINGS: {
    /** Every month, extend the users rate schedule up to their availability window, cannot be use when availability window is unrestricted */
    IS_AVAILABILITY_AUTOMATION_ENABLED: boolean;
    /** AKA Pricing insights/Smart Pricing data
     * If true then the property has the option to enable optimized pricing */
    HAS_RATE_INSIGHTS_DATA: boolean;
    /** Every month, optimize the users rate schedule using the smart pricing level set
     *  Each date range can have its own smart pricing level, otherwise uses the property-level smart pricing level */
    IS_OPTIMIZED_PRICING_ENABLED: boolean;
    NO_RATES_DATES: NoRatesDate[];
    PRICING_STRATEGY: {
        ID: PricingStrategyEnum;
        RATE_INSIGHTS_LEVEL_ID: RateInsightLevelIdEnum;
    };
    WEEKEND_PREMIUM: {
        ID: RatesSettingsWeekendPremiumId;
        DOLLAR_AMOUNT: number;
        PERCENTAGE_AMOUNT: number;
    };
    AVAILABILITY_WINDOW: {
        ID: RateAvailabilityIdEnum;
    };
    DATE_LAST_SAVED: string;
    RATE_GROUPS: {
        HIGH: RateGroup;
        LOW: RateGroup;
        PRIME: RateGroup;
        MID: RateGroup;
    };
    DISCOUNT_GROUP: {
        TEN_DAY: number;
        SEVEN_DAY: number;
        FIVE_DAY: number;
        ID: number;
    };
    ID: number;
};
export const ACCESS_TO_UNIT: {
    CODE: {
        NAME: string;
        ID: AccessCodeIdEnum;
    };
    METHOD: {
        NAME: string;
        ID: AccessMethodIdEnum;
    };
    /** STANDARD_CODE and FRONT_DOOR_CODE are linked for a property */
    STANDARD_CODE: string;
    TYPE: {
        NAME: string;
        ID: AccessCodeTypeIDEnum;
    };
};
export const SURCHARGE: {
    AMOUNT: string;
    ID: number;
    IS_ENABLED: boolean;
    NAME: string;
};
export const PROPERTY_SURCHARGES: {
    CLEANING: {
        AMOUNT: string;
        ID: number;
        IS_ENABLED: boolean;
        NAME: string;
    };
    PETS: {
        AMOUNT: string;
        ID: number;
        IS_ENABLED: boolean;
        NAME: string;
    };
};
export const ITN_INFORMATION: {
    ID: number;
    ITN: number;
    PERCENTAGE_OWNERSHIP: number;
    DOB: string;
    FIRST_NAME: string;
    LAST_NAME: string;
};
export const NON_RESIDENT: {
    ITN_INFO: {
        ID: number;
        ITN: number;
        PERCENTAGE_OWNERSHIP: number;
        DOB: string;
        FIRST_NAME: string;
        LAST_NAME: string;
    }[];
    IS_NON_RESIDENT: boolean;
    WITHHOLDING_PERCENTAGE: number;
};
export const PROPERTY_CODES: {
    BIKE_LOCKER_CODE: string;
    /** Used for building entrance when a single door code is not sufficient */
    DEVELOPMENT_DOOR_CODE: string;
    /** Used for sauna and steam room */
    DEVELOPMENT_GYM_CODE: string;
    DEVELOPMENT_HOT_TUB_CODE: string;
    /** Used for pool and hot-tub */
    DEVELOPMENT_POOL_CODE: string;
    DEVELOPMENT_SAUNA_CODE: string;
    DEVELOPMENT_STEAM_ROOM_CODE: string;
    /** Used for access to unit/building. This is linked to the ACCESS_TO_UNIT STANDARD_CODE field */
    FRONT_DOOR_CODE: string;
    GAMES_REC_ROOM_CODE: string;
    GARAGE_DOOR_CODE: string;
    GARBAGE_RECYCLING_CODE: string;
    ID: number;
    INTERNET_NETWORK_NAME: string;
    INTERNET_PASSWORD: string;
    PHONE_NUMBER: string;
    PROPERTY_ID: string;
    SKI_LOCKER_CODE: string;
    DATE_LAST_UPDATED: string;
};
export const PROPERTY_RULES: {
    ID: number;
    ADVANCED_BOOKING: {
        NAME: string;
        ID: number;
    };
    CHECK_IN: string;
    CHECK_OUT: string;
    MAX_BOOKABLE_DAYS: number;
    MAX_GUESTS: number;
    MIN_AGE_TO_BOOK: number;
    QUIET_TIME: string;
};
export const initialPropertyState: {
    ID: number;
    ACCESS_TO_UNIT: {
        CODE: {
            NAME: string;
            ID: AccessCodeIdEnum;
        };
        METHOD: {
            NAME: string;
            ID: AccessMethodIdEnum;
        };
        /** STANDARD_CODE and FRONT_DOOR_CODE are linked for a property */
        STANDARD_CODE: string;
        TYPE: {
            NAME: string;
            ID: AccessCodeTypeIDEnum;
        };
    };
    ADDRESS: {
        AREA: string;
        AREA_ID: number;
        CITY: string;
        COUNTRY: string;
        COUNTRY_CODE: string;
        COUNTRY_ID: number;
        DEVELOPMENT: string;
        DEVELOPMENT_ID: number;
        ID: number;
        LATITUDE: number;
        LONGITUDE: number;
        POSTAL: string;
        REGION: string;
        REGION_ID: number;
        RESORT: string;
        RESORT_ID: number;
        STREET_NAME: string;
        STREET_NUMBER: string;
        UNIT: string;
    };
    AMENITIES: {
        BUILDING: {
            TYPE: string;
            LIST: Amenity[];
        };
        ESSENTIAL: {
            TYPE: string;
            LIST: Amenity[];
        };
        KITCHEN: {
            TYPE: string;
            LIST: Amenity[];
        };
        PRIVATE: {
            TYPE: string;
            LIST: Amenity[];
        };
        SAFETY: {
            TYPE: string;
            LIST: Amenity[];
        };
    };
    BANKING: {
        ACCOUNTHOLDER: {
            ADDRESS: {
                AREA: string;
                AREA_ID: number;
                CITY: string;
                COUNTRY: string;
                COUNTRY_CODE: string;
                COUNTRY_ID: number;
                DEVELOPMENT: string;
                DEVELOPMENT_ID: number;
                ID: number;
                LATITUDE: number;
                LONGITUDE: number;
                POSTAL: string;
                REGION: string;
                REGION_ID: number;
                RESORT: string;
                RESORT_ID: number;
                STREET_NAME: string;
                STREET_NUMBER: string;
                UNIT: string;
            };
            COMPANY_NAME: string;
            FIRST_NAME: string;
            IS_COMPANY: boolean;
            LAST_NAME: string;
        };
        BANK: {
            ACCOUNT_NUMBER: string;
            INSTITUTION: string;
            NAME: string;
            TRANSIT: string;
            ID: number;
        };
    };
    BATHROOMS: Bathroom[];
    BEDROOMS: Bedroom[];
    BLOCKOFFS: never[];
    CANCELLATION_POLICY: {
        ADMIN_PENALTY: number;
        ADMIN_PENALTY_UNIT: string;
        BOOKING_GRACE_PERIOD: string;
        DATE_ACTIVATED: string;
        DATE_LAST_UPDATED: string;
        DATE_RANGES: {
            DATE_ACTIVATED: string;
            DESCRIPTION: string;
            FROM_DAYS: string;
            ID: number;
            LABEL: string;
            REFUND_PERCENTAGE: string;
            TO_DAYS: string;
        }[];
        DESCRIPTION: string;
        ID: number;
        IS_CREDIT_ONLY_REFUND: boolean;
        IS_REFUND_REBOOKED_DATES: boolean;
        IS_SPECIAL_CIRCUMSTANCE: boolean;
        NAME: string;
        POLICY_ID: number;
        SERVICE_FEE_REFUND: string;
        SPECIAL_CIRCUMSTANCE_DESCRIPTION: string;
        SPECIAL_CIRCUMSTANCE_ID: number;
        SPECIAL_CIRCUMSTANCE_NAME: string;
        SURCHARGE_REFUND: string;
    };
    CLEANING_PROTOCOL: {
        HAS_AUTOMATIC_BUFFER_DAYS: boolean;
        IS_APPLY_TO_EXISTING_BOOKINGS: boolean;
        NUMBER_OF_BLOCKOFF_DAYS: number;
    };
    CODES: {
        BIKE_LOCKER_CODE: string;
        /** Used for building entrance when a single door code is not sufficient */
        DEVELOPMENT_DOOR_CODE: string;
        /** Used for sauna and steam room */
        DEVELOPMENT_GYM_CODE: string;
        DEVELOPMENT_HOT_TUB_CODE: string;
        /** Used for pool and hot-tub */
        DEVELOPMENT_POOL_CODE: string;
        DEVELOPMENT_SAUNA_CODE: string;
        DEVELOPMENT_STEAM_ROOM_CODE: string;
        /** Used for access to unit/building. This is linked to the ACCESS_TO_UNIT STANDARD_CODE field */
        FRONT_DOOR_CODE: string;
        GAMES_REC_ROOM_CODE: string;
        GARAGE_DOOR_CODE: string;
        GARBAGE_RECYCLING_CODE: string;
        ID: number;
        INTERNET_NETWORK_NAME: string;
        INTERNET_PASSWORD: string;
        PHONE_NUMBER: string;
        PROPERTY_ID: string;
        SKI_LOCKER_CODE: string;
        DATE_LAST_UPDATED: string;
    };
    CO_HOST: {
        COHOST_PROFILE: {
            PERMISSIONS: Omit<PropertyPermission, "PROPERTY_ID">;
            PROPERTY_IDS: never[];
        };
        ID: number;
        FIRST_NAME: string;
        LAST_NAME: string;
        IS_COMPANY: boolean;
        COMPANY_NAME: string;
        THUMBNAIL: string;
        PHONE: string;
        EMAIL: string;
        CREATED_DATE: string;
        DATE_LAST_LOGIN: string;
        DATE_UPDATED: string;
        ADDRESS: {
            AREA: string;
            AREA_ID: number;
            CITY: string;
            COUNTRY: string;
            COUNTRY_CODE: string;
            COUNTRY_ID: number;
            DEVELOPMENT: string;
            DEVELOPMENT_ID: number;
            ID: number;
            LATITUDE: number;
            LONGITUDE: number;
            POSTAL: string;
            REGION: string;
            REGION_ID: number;
            RESORT: string;
            RESORT_ID: number;
            STREET_NAME: string;
            STREET_NUMBER: string;
            UNIT: string;
        };
        IS_SMS_VERIFIED: boolean;
        IS_EMAIL_VERIFIED: boolean;
        DATE_EMAIL_VERIFIED: string;
        DATE_SMS_VERIFIED: string;
        DATE_OF_BIRTH: string;
        IS_ACTIVE: boolean;
        IS_STAFF: boolean;
        IS_SUPERUSER: boolean;
        IS_DUE_DILIGENCE_REQUIRED: boolean;
    };
    CONTENT: {
        ABOUT_THE_BUILDING: string;
        DESCRIPTION: string;
        KITCHEN: string;
        LOCATION: string;
        SUMMARY: string;
        TITLE: string;
    };
    DAMAGE_DEPOSIT: {
        AMOUNT: string;
        TYPE: {
            ID: DamageDepositModeId;
            NAME: string;
        };
    };
    DAYS_TO_EXPIRY: number;
    DIRECT_VACATIONS: {
        ID: number;
        IS_ACTIVE: boolean;
        LOGO: string;
        NAME: string;
        URL: string;
    };
    EMERGENCY_CONTACTS: {
        PRIMARY: EmergencyContact;
        OTHERS: EmergencyContact[];
    };
    EXTERNAL_URLS: {
        URL_AIRBNB: string;
        URL_OTHER: string;
        URL_VRBO: string;
    };
    ICALS: {
        HAS_ICALS: boolean;
        PRIMARY: {
            ALLURA_URL: string;
            AVAILABILITY_WINDOW: number;
            IS_AVAILABILITY_WINDOW: boolean;
            IS_BLOCK_RATELESS: boolean;
        };
        SECONDARY: {
            ALLURA_URL: string;
            AVAILABILITY_WINDOW: number;
            IS_ACTIVE: boolean;
            IS_AVAILABILITY_WINDOW: boolean;
            IS_BLOCK_RATELESS: boolean;
        };
        EXTERNAL: {
            ID: number;
            LISTING_URL: string;
            NAME: string;
            URL: string;
        }[];
    };
    INSTRUCTIONS: {
        ABOUT_THE_BUILDING: string;
        ACTIVITIES: string;
        BUILDING_COMMON_AREAS: string;
        CHECK_IN: string;
        CHECK_OUT: string;
        EMERGENCY_CONTACTS: string;
        FRONT_DESK: string;
        GARBAGE_RECYCLING: string;
        GETTING_AROUND: string;
        GETTING_TO_UNIT: string;
        HEATING: string;
        HOUSEKEEPING: string;
        ID: number;
        INFANT_SUPPLIES: string;
        KITCHEN: string;
        LATE_CHECK_IN: string;
        LINENS_AND_TOWELS: string;
        OTHER: string;
        PARKING: string;
        RESTAURANTS: string;
        SERVICES: string;
        SKI_IN_SKI_OUT: string;
        TO_FROM_LIFTS: string;
        WELCOME: string;
        WHAT_TO_BRING: string;
    };
    IS_ALLURA_RATES: boolean;
    IS_CO_HOST_MANAGER_ENABLED: string;
    IS_ENABLED: boolean;
    IS_SKI_IN_SKI_OUT: boolean;
    JOIN_STATUS: {
        COMPLETION_PERCENTAGE_REQUIRED: number;
        COMPLETION_PERCENTAGE_OPTIONAL: number;
        DATES: {
            CREATED: string;
            LAST_UPDATED: string;
            ACTIVATED: string;
            ACTIVATION_REQUEST: string;
        };
        HAS_COMPLETED_ONBOARDING: boolean;
        STATUS: string;
        STATUS_ID: JoinStatusIDEnum;
        SUBFORMS_COMPLETED: RequiredSubformsEnum[];
        SUBFORMS_OPTIONAL_COMPLETED: OptionalSubformsEnum[];
    };
    LISTING_QUALITY: {
        MESSAGE: string;
        RATES_AVAILABILITY: {
            MESSAGE: string;
            PROPERTY_COUNT: number;
            RECOMMENDED_COUNT: number;
            SCORE: number;
        };
        PROPERTY_GUIDEBOOK: {
            MESSAGE: string;
            PROPERTY_COUNT: number;
            RECOMMENDED_COUNT: number;
            SCORE: number;
        };
        STAR_RATING: number;
        PHOTOS: {
            MESSAGE: string;
            PROPERTY_COUNT: number;
            RECOMMENDED_COUNT: number;
            SCORE: number;
        };
    };
    NAME: string;
    NON_RESIDENT: {
        ITN_INFO: {
            ID: number;
            ITN: number;
            PERCENTAGE_OWNERSHIP: number;
            DOB: string;
            FIRST_NAME: string;
            LAST_NAME: string;
        }[];
        IS_NON_RESIDENT: boolean;
        WITHHOLDING_PERCENTAGE: number;
    };
    OFFERS: {
        IS_NEW_LISTING_OFFER_ENABLED: boolean;
        IS_NEW_LISTING_OFFER_BLACKOUT_ENABLED: boolean;
    };
    OWNER: WithRequiredProperty<User, "OWNER_PROFILE">;
    PARKING: {
        DESCRIPTION: string;
        HAS_ADDITIONAL_FREE_SPOTS: string;
        HAS_ADDITIONAL_PAID_SPOTS: string;
        INSTRUCTIONS: string;
        IS_DEFAULT_DESCRIPTION: boolean;
        NUM_SPOTS_PROVIDED: string;
    };
    PARTNERS: never[];
    PHOTOS: Photo[];
    POLICIES: {
        ACCOUNT: Policy[];
        GENERAL: Policy[];
        GUEST_STAY: Policy[];
        HOUSE_RULES: Policy[];
        PROPERTY: Policy[];
        RESERVATION: Policy[];
    };
    /** Either the owner of the property or the PROPERTY_CONTACT if defined */
    PRIMARY_CONTACT: User;
    /** PROPERTY_CONTACT is either sent with info or sent as an empty object
     * The PROPERTY_CONTACT is the rental manager of the property
     * The values are pre-filled so that the rental manager form can use those values  */
    PROPERTY_CONTACT: {
        PROPERTY_MANAGER_PROFILE: {
            PERMISSIONS: Omit<PropertyPermission, "PROPERTY_ID">;
            PROPERTY_IDS: never[];
        };
        ID: number;
        FIRST_NAME: string;
        LAST_NAME: string;
        IS_COMPANY: boolean;
        COMPANY_NAME: string;
        THUMBNAIL: string;
        PHONE: string;
        EMAIL: string;
        CREATED_DATE: string;
        DATE_LAST_LOGIN: string;
        DATE_UPDATED: string;
        ADDRESS: {
            AREA: string;
            AREA_ID: number;
            CITY: string;
            COUNTRY: string;
            COUNTRY_CODE: string;
            COUNTRY_ID: number;
            DEVELOPMENT: string;
            DEVELOPMENT_ID: number;
            ID: number;
            LATITUDE: number;
            LONGITUDE: number;
            POSTAL: string;
            REGION: string;
            REGION_ID: number;
            RESORT: string;
            RESORT_ID: number;
            STREET_NAME: string;
            STREET_NUMBER: string;
            UNIT: string;
        };
        IS_SMS_VERIFIED: boolean;
        IS_EMAIL_VERIFIED: boolean;
        DATE_EMAIL_VERIFIED: string;
        DATE_SMS_VERIFIED: string;
        DATE_OF_BIRTH: string;
        IS_ACTIVE: boolean;
        IS_STAFF: boolean;
        IS_SUPERUSER: boolean;
        IS_DUE_DILIGENCE_REQUIRED: boolean;
    };
    RATES_SCHEDULE: ServerRateSchedule[];
    RATES_SETTINGS: {
        /** Every month, extend the users rate schedule up to their availability window, cannot be use when availability window is unrestricted */
        IS_AVAILABILITY_AUTOMATION_ENABLED: boolean;
        /** AKA Pricing insights/Smart Pricing data
         * If true then the property has the option to enable optimized pricing */
        HAS_RATE_INSIGHTS_DATA: boolean;
        /** Every month, optimize the users rate schedule using the smart pricing level set
         *  Each date range can have its own smart pricing level, otherwise uses the property-level smart pricing level */
        IS_OPTIMIZED_PRICING_ENABLED: boolean;
        NO_RATES_DATES: NoRatesDate[];
        PRICING_STRATEGY: {
            ID: PricingStrategyEnum;
            RATE_INSIGHTS_LEVEL_ID: RateInsightLevelIdEnum;
        };
        WEEKEND_PREMIUM: {
            ID: RatesSettingsWeekendPremiumId;
            DOLLAR_AMOUNT: number;
            PERCENTAGE_AMOUNT: number;
        };
        AVAILABILITY_WINDOW: {
            ID: RateAvailabilityIdEnum;
        };
        DATE_LAST_SAVED: string;
        RATE_GROUPS: {
            HIGH: RateGroup;
            LOW: RateGroup;
            PRIME: RateGroup;
            MID: RateGroup;
        };
        DISCOUNT_GROUP: {
            TEN_DAY: number;
            SEVEN_DAY: number;
            FIVE_DAY: number;
            ID: number;
        };
        ID: number;
    };
    RESERVATION_SETTINGS: {
        DEPOSIT_PERCENTAGE: number;
        BALANCE_DAYS_BEFORE_ARRIVAL: number;
        BOOKING_GATEWAY_MODE_ID: number;
    };
    RULES: {
        ID: number;
        ADVANCED_BOOKING: {
            NAME: string;
            ID: number;
        };
        CHECK_IN: string;
        CHECK_OUT: string;
        MAX_BOOKABLE_DAYS: number;
        MAX_GUESTS: number;
        MIN_AGE_TO_BOOK: number;
        QUIET_TIME: string;
    };
    SETUP_QUESTIONS: {
        NUM_PROPERTIES: number;
        PLATFORMS_LISTED: {
            ID: number;
            URL: string;
        }[];
        ID: number;
    };
    SIZE_CATEGORY: {
        NAME: string;
        ID: number;
    };
    SQUARE_FEET: string;
    STYLE: {
        NAME: string;
        ID: number;
    };
    SURCHARGES: {
        CLEANING: {
            AMOUNT: string;
            ID: number;
            IS_ENABLED: boolean;
            NAME: string;
        };
        PETS: {
            AMOUNT: string;
            ID: number;
            IS_ENABLED: boolean;
            NAME: string;
        };
    };
    SUBSCRIPTION: {
        COMMISSION_PERCENTAGE: number;
        CREDIT_CARD_PERCENTAGE: number;
        DESCRIPTION: string;
        DURATION: string;
        FEE: string;
        GST: string;
        GST_RATE: number;
        ID: number;
        NAME: string;
        NUMBER_OF_DAYS: number;
        RESORT_ID: number;
        SUBSCRIPTION_TIER_ID: PropertySubscriptionTierIdEnum;
    };
    SUITABILITIES: {
        LONG_TERM_RENTALS: {
            ID: number;
            DESCRIPTION: string;
            IS_SUITABLE: boolean;
            NAME: string;
        };
        PARTIES_EVENTS: {
            ID: number;
            DESCRIPTION: string;
            IS_SUITABLE: boolean;
            NAME: string;
        };
        PETS: {
            ID: number;
            DESCRIPTION: string;
            IS_SUITABLE: boolean;
            NAME: string;
        };
        SMOKING: {
            ID: number;
            DESCRIPTION: string;
            IS_SUITABLE: boolean;
            NAME: string;
        };
        TRAVEL_RESELLERS: {
            ID: number;
            DESCRIPTION: string;
            IS_SUITABLE: boolean;
            NAME: string;
        };
        WHEELCHAIR_ACCESSIBLE: {
            ID: number;
            DESCRIPTION: string;
            IS_SUITABLE: boolean;
            NAME: string;
        };
    };
    TAXES: {
        IS_MANDATORY: boolean;
        IS_PASS_THROUGH_TO_OWNER: boolean;
        NAME: string;
        ID: number;
        RATE: number;
        REGISTRATION_NUMBER: string;
        DESCRIPTION: string;
    }[];
    TAX_NUMBERS: {
        BC_SHORT_TERM_REGISTRY_NUMBER: string;
        BUSINESS_LICENCE_NUMBER: string;
        GST_NUMBER: string;
        PST_NUMBER: string;
    };
    THUMBNAIL_URL: string;
    URL: string;
    VIDEOS: {
        THREESIXTY: {
            DATA: string;
            ID: number;
        };
        YOUTUBE: {
            DATA: string;
            ID: number;
        }[];
        FEATURED: {
            DATA: string;
            ID: number;
        };
    };
    WALKTHROUGH: {
        PROPERTY_GUIDEBOOK: GuidebookWalkthrough;
    };
};
export const calendarEvent: {
    ARRIVAL: string;
    ARRIVAL_UTC: number;
    BOOKING_NET: string;
    DATE_CREATED: string;
    DEPARTURE: string;
    DEPARTURE_UTC: number;
    GUEST: {
        EMAIL: string;
        FIRST_NAME: string;
        LAST_NAME: string;
        MEMBER_SINCE: string;
        NAME: string;
        NUM_BOOKINGS: number;
        NUM_RECOMMENDATIONS: number;
        NUM_REVIEWS: number;
        PHONE: string;
        THUMBNAIL: string;
    };
    GUEST_REQUESTS: string;
    HAS_PETS: boolean;
    ID: number;
    IS_ALLURA_BOOKING: boolean;
    NOTES_OWNER: string;
    PAID_TO_DATE: string;
    PARTY_SIZE_ADULTS: number;
    PARTY_SIZE_KIDS: string;
    PROPERTY: {
        THUMBNAIL_URL: string;
    };
    REFERENCE: string;
    SOURCE: string;
    STATUS: string;
    TITLE: string;
    TYPE: EventTypeEnum;
};
export const sparseRate: {
    NIGHTS: number;
    ID: number;
    RATE: string;
};
export const sparseSeason: {
    START: string;
    NAME: string;
    ID: number;
    COMMENT: string;
    END: string;
    RATES: never[];
};
export const calendarDate: {
    IS_BOOKED: boolean;
    DATE: string;
    DATE_UTC: number;
    ID: number;
    TYPE: string;
    SEASON: {
        START: string;
        NAME: string;
        ID: number;
        COMMENT: string;
        END: string;
        RATES: never[];
    };
};
export const reservationDetails: {
    ARRIVAL_DATE: string;
    DEPARTURE_DATE: string;
    GUEST_NAME: string;
    GUEST_EMAIL: string;
    GUEST_PHONE: string;
    /** The guest's ID */
    ID: number;
    USER_TYPE_ID: UserRoleIDEnum;
    REFERENCE: string;
    BOOKING_ID: string;
    BOOKING_STATUS: string;
    CONFIRMED_DATE: string;
};
export const initialLastAndNextGuest: {
    HAS_LAST_GUEST: boolean;
    LAST_GUEST: {
        ARRIVAL_DATE: string;
        DEPARTURE_DATE: string;
        GUEST_NAME: string;
        GUEST_EMAIL: string;
        GUEST_PHONE: string;
        /** The guest's ID */
        ID: number;
        USER_TYPE_ID: UserRoleIDEnum;
        REFERENCE: string;
        BOOKING_ID: string;
        BOOKING_STATUS: string;
        CONFIRMED_DATE: string;
    };
    HAS_NEXT_GUEST: boolean;
    NEXT_GUEST: {
        ARRIVAL_DATE: string;
        DEPARTURE_DATE: string;
        GUEST_NAME: string;
        GUEST_EMAIL: string;
        GUEST_PHONE: string;
        /** The guest's ID */
        ID: number;
        USER_TYPE_ID: UserRoleIDEnum;
        REFERENCE: string;
        BOOKING_ID: string;
        BOOKING_STATUS: string;
        CONFIRMED_DATE: string;
    };
    PROPERTY_ID: string;
};
export const BANK_DEPOSITS: {
    TRANSFERRED: {
        BANK_ACCOUNT_HOLDER: string;
        BANK_ACCOUNT_NUMBER: string;
        EXPECTED_DEPOSIT_DATE: string;
        TRANSACTION_ID: number;
        BOOKING_ID: number;
        REFERENCE: string;
        TRANSFER_DATE: string;
        AMOUNT: number;
    }[];
    EXPECTED: {
        EXPECTED_PAYOUT: string;
        SUM_IN_TRANSIT: number;
    };
};
export const UNAVAILABLE_DATES: {
    CANNOT_ARRIVE: string[];
    CANNOT_DEPART: string[];
    UNAVAILABILITY_ARRIVAL: string[];
    UNAVAILABILITY_DEPARTURE: string[];
};
export const PHOTO: {
    ORIGINAL: string;
    CAPTION: string;
    SORT_ORDER: number;
    THUMB: string;
    FULL: string;
    ID: number;
};
export const PROPERTY_DEFAULT_CONTENT: {
    DEFAULT_CONTENT: string;
    OTHER_DEFAULTS: string[];
    ID: number;
};
export const EXTERNAL_EVENT: {
    SOURCE: string;
    NIGHTS: number;
    ARRIVAL: string;
    DEPARTURE: string;
    ID: number;
    SUMMARY: string;
};
export const PROPERTY_REVIEWS: {
    PROPERTY_ID: number;
    AVERAGE_SCORE: number;
    AVERAGE_SCORES: {
        AVERAGE_SCORE: number;
        TITLE: string;
    }[];
    NUM_REVIEWS: number;
    REVIEWS: {
        ID: number;
        IS_GUEST_RESPONSE_POSSIBLE: boolean;
        BOOKING_INFO: {
            RESORT: string;
            PROPERTY_IMAGE: string;
            NIGHTS: number;
            ARRIVAL: string;
            DEPARTURE: string;
            REFERENCE: string;
            CONFIRMED: string;
            ID: number;
            DEVELOPMENT: string;
        };
        REVIEW: string;
        STATUS: string;
        STATUS_ID: ReviewStatusId;
        REVIEW_DATE: string;
        GUEST_INFO: {
            MEMBER_SINCE: string;
            COUNTRY: string;
            NUM_BOOKINGS: number;
            FIRST_NAME: string;
            STATUS: string;
            NUM_HOST_RECOMMENDATIONS: number;
            LAST_NAME: string;
            ID: number;
            NUM_RECOMMENDS: number;
            CITY: string;
            NUM_REVIEWS: number;
            USER_TYPE_ID: number;
            THUMBNAIL: string;
        };
        RATINGS: {
            QUESTION: string;
            MAX_SCORE: number;
            ID: number;
            TITLE: string;
            SCORE: number;
        }[];
        RATINGS_AVERAGE: number;
        IS_PUBLISHED: boolean;
        WOULD_RECOMMEND: boolean;
        PUBLISHED_DATE: string;
        TITLE: string;
        RESPONSES: {
            RESPONSE: string;
            RESPONSE_DATE: string;
            USER_ROLE: string;
            TITLE: string;
        }[];
    }[];
};
export const RATE_SUGGESTION: {
    DATE: string;
    LOW: string;
    LOW_MID: string;
    MID: string;
    MID_HIGH: string;
    HIGH: string;
    ID: number;
};
export const RATE_SUGGESTIONS: {
    ID: number;
    RESORT: string;
    RESORT_ID: number;
    SIZE_CATEGORY: string;
    SIZE_CATEGORY_ID: number;
    RATES_SCHEDULE: {
        DATE: string;
        LOW: string;
        LOW_MID: string;
        MID: string;
        MID_HIGH: string;
        HIGH: string;
        ID: number;
    }[];
};
export const RATE_SCHEDULE_GENERATE_OPTIMIZE: {
    ID: string | number;
    RATES_SCHEDULE: ServerRateSchedule[];
};
export const RATE_SCHEDULE_GENERATE_INSIGHT: {
    ID: string | number;
    RATES_SCHEDULE: ServerRateSchedule[];
};
export const bookingStatus: {
    DATE: string;
    IS_DONE: boolean;
    LABEL: string;
};
export const bookingInfo: {
    RESORT: string;
    NIGHTS: number;
    ARRIVAL: string;
    DEPARTURE: string;
    DEVELOPMENT: string;
    REFERENCE: string;
    CONFIRMED: string;
    ID: number;
    PROPERTY_IMAGE: string;
};
declare const inquiry: {
    GUEST_ID: number;
    MESSAGE: string;
    PROPERTY_ID: number;
    SUBJECT: string;
    TO_EMAILS: string;
    DATE_SENT: string;
    MESSAGE_RECIPIENT_ID: MessageRecipientIdEnum;
    FROM_EMAIL: string;
    TIME_SENT: string;
    BOOKING_ID: number;
    ID: number;
    INQUIRY_ID: number;
};
export const reviewRating: {
    QUESTION: string;
    MAX_SCORE: string;
    ID: number;
    TITLE: string;
    SCORE: RatingRange;
};
export const reviewResponses: {
    ID: number;
    CHECKIN_DATE: string;
    CHECKOUT_DATE: string;
    BOOKING_NUMBER: string;
    HOST_NAME: string;
    HOST_RECOMMENDATION: boolean;
    HOST_COMMENTS: string;
    HAS_COMMENT_ENABLED: boolean;
};
export const ELIGIBLE_REVIEW: {
    BOOKING_INFO: {
        RESORT: string;
        NIGHTS: number;
        ARRIVAL: string;
        DEPARTURE: string;
        DEVELOPMENT: string;
        REFERENCE: string;
        CONFIRMED: string;
        ID: number;
        PROPERTY_IMAGE: string;
    };
    ID: number;
    IS_GUEST_RESPONSE_POSSIBLE: boolean;
    IS_PUBLISHED: boolean;
    STATUS: string;
    STATUS_ID: ReviewStatusId;
};
export const REVIEW: Readonly<{
    PRIVATE_MESSAGE_TO_OWNER: "";
    REVIEW: "";
    GUEST_INFO: any;
    PUBLISHED_DATE: "";
    RATINGS: RatingItem[];
    RATINGS_AVERAGE: 0;
    RESPONSES: ReviewResponse[];
    REVIEW_DATE: "";
    TITLE: "";
    WOULD_RECOMMEND: false;
    BOOKING_INFO: {
        RESORT: string;
        NIGHTS: number;
        ARRIVAL: string;
        DEPARTURE: string;
        DEVELOPMENT: string;
        REFERENCE: string;
        CONFIRMED: string;
        ID: number;
        PROPERTY_IMAGE: string;
    };
    ID: number;
    IS_GUEST_RESPONSE_POSSIBLE: boolean;
    IS_PUBLISHED: boolean;
    STATUS: string;
    STATUS_ID: ReviewStatusId;
}>;
export const BOOKING_PROPERTY: {
    ADDRESS: {
        AREA: string;
        AREA_ID: number;
        CITY: string;
        COUNTRY: string;
        COUNTRY_CODE: string;
        COUNTRY_ID: number;
        DEVELOPMENT: string;
        DEVELOPMENT_ID: number;
        ID: number;
        LATITUDE: number;
        LONGITUDE: number;
        POSTAL: string;
        REGION: string;
        REGION_ID: number;
        RESORT: string;
        RESORT_ID: number;
        STREET_NAME: string;
        STREET_NUMBER: string;
        UNIT: string;
    };
    DIRECT_VACATIONS: {
        ID: number;
        IS_ACTIVE: boolean;
        LOGO: string;
        NAME: string;
        URL: string;
    };
    DAMAGE_DEPOSIT: {
        AMOUNT: string;
        DESCRIPTION: string;
        ID: number;
        IS_COLLECTED: boolean;
        MODE: string;
    };
    GATEWAY_MODE: {
        ID: BookingGateWayModeIdEnum;
        VALUE: string;
    };
    RULES: {
        ID: number;
        ADVANCED_BOOKING: {
            NAME: string;
            ID: number;
        };
        CHECK_IN: string;
        CHECK_OUT: string;
        MAX_BOOKABLE_DAYS: number;
        MAX_GUESTS: number;
        MIN_AGE_TO_BOOK: number;
        QUIET_TIME: string;
    };
    IS_ENABLED: boolean;
    MAX_GUESTS: number;
    NAME: string;
    SIZE_CATEGORY: string;
    SQUARE_FEET: number;
    SURCHARGES: {
        PETS: {
            IS_ENABLED: boolean;
            NAME: string;
            ID: number;
            AMOUNT: string;
        };
        CLEANING: {
            IS_ENABLED: boolean;
            NAME: string;
            ID: number;
            AMOUNT: string;
        };
    };
    STYLE: string;
    URL: string;
    JOIN_STATUS: {
        STATUS_ID: JoinStatusIDEnum;
    };
    ID: number;
    THUMBNAIL_URL: string;
    ACCESS_TO_UNIT: {
        CODE: {
            NAME: string;
            ID: _AccessCodeIdEnum1;
        };
        METHOD: {
            NAME: string;
            ID: _AccessMethodIdEnum1;
        };
        STANDARD_CODE: string;
        TYPE: {
            NAME: string;
            ID: _AccessCodeTypeIDEnum1;
        };
    };
    CODES: {
        BIKE_LOCKER_CODE: string;
        DEVELOPMENT_DOOR_CODE: string;
        DEVELOPMENT_GYM_CODE: string;
        DEVELOPMENT_HOT_TUB_CODE: string;
        DEVELOPMENT_POOL_CODE: string;
        DEVELOPMENT_SAUNA_CODE: string;
        DEVELOPMENT_STEAM_ROOM_CODE: string;
        FRONT_DOOR_CODE: string;
        GAMES_REC_ROOM_CODE: string;
        GARAGE_DOOR_CODE: string;
        GARBAGE_RECYCLING_CODE: string;
        ID: number;
        INTERNET_NETWORK_NAME: string;
        INTERNET_PASSWORD: string;
        PHONE_NUMBER: string;
        PROPERTY_ID: string;
        SKI_LOCKER_CODE: string;
        DATE_LAST_UPDATED: string;
    };
    PRIMARY_CONTACT: EmergencyContact & {
        THUMBNAIL_URL: string;
    };
};
export const fullPayment: {
    DAMAGE_DEPOSIT: {
        AMOUNT: string;
        DUE_DATE: string;
        IS_COLLECTED: boolean;
        MODE: string;
        MODE_ID: DamageDepositModeId;
    };
    DEPOSIT: {
        AMOUNT: string;
        DUE_DATE: string;
        NET: string;
        PAYMENT_DATE: string;
        PERCENTAGE: number;
        TOTAL: string;
    };
    BOOKING_NET: string;
    BOOKING_GROSS: string;
    PAID_TO_DATE: string;
    PRICE_PER_NIGHT: string;
    TAXES_AND_FEES_TOTAL: string;
    LOS_DISCOUNT: string;
    AMOUNT_OUTSTANDING: string;
    AMOUNT_REFUNDED: string;
    BALANCE: {
        DUE_DATE: string;
        PAYMENT_DATE: string;
        TOTAL: string;
    };
    NEXT_PAYMENT: {
        DUE_DATE: string;
        IS_PAST_DUE: boolean;
        NAME: string;
        TOTAL: string;
    };
};
export const BOOKING_STATUS: {
    ID: BookingStatusId;
    NAME: string;
};
export const CUSTOM_MESSAGE: {
    MESSAGE: string;
    ENTRY_CODE: string;
};
export const SPARSE_BOOKING: {
    CUSTOM_MESSAGE: {
        MESSAGE: string;
        ENTRY_CODE: string;
    };
    DATES: {
        ARRIVAL: string;
        BOOKING: string;
        BOOKING_TIME: string;
        CHECK_IN_SENT: string;
        DEPARTURE: string;
        SERVER_TIMESTAMP: string;
    };
    FLAGS: {
        IS_PAST_DUE: boolean;
    };
    GUEST: {
        AGE: string;
        EMAIL: string;
        FIRST_NAME: string;
        GUEST_PROFILE: {
            MEMBER_SINCE: string;
            PERMISSIONS: {
                SHOW_NUM_REVIEWS: boolean;
                SHOW_MEMBER_SINCE: boolean;
                SHOW_NUM_RECOMMENDS: boolean;
            };
            NUM_BOOKINGS: number;
            NUM_RECOMMENDATIONS: number;
            NUM_REVIEWS: number;
        };
        ID: number;
        IS_AGE_VERIFIED: boolean;
        IS_EMAIL_VERIFIED: boolean;
        IS_SMS_VERIFIED: boolean;
        LAST_NAME: string;
        PHONE: string;
        THUMBNAIL: string;
    };
    GUEST_COMMENT: string;
    GUEST_REQUESTS: string;
    ID: number;
    NIGHTS: number;
    NIGHTLY_RATES: {
        DATE: string;
        DAY: string;
        RATE: string;
        BASE_RATE: string;
        LOS_DISCOUNT: string;
        OFFER_DISCOUNT: string;
    }[];
    NOTES_OWNER: string;
    PARTY_SIZE: {
        ADULTS: number;
        KIDS: number;
    };
    PAYMENT: {
        AMOUNT_OUTSTANDING: string;
        AMOUNT_REFUNDED: string;
        BALANCE: {
            DUE_DATE: string;
            PAYMENT_DATE: string;
            TOTAL: string;
        };
        BOOKING_NET: string;
        DAMAGE_DEPOSIT: {
            MODE: string;
            MODE_ID: DamageDepositModeId;
        };
        DEPOSIT: {
            DUE_DATE: string;
            PAYMENT_DATE: string;
            TOTAL: string;
        };
        NEXT_PAYMENT: {
            DUE_DATE: string;
            IS_PAST_DUE: boolean;
            NAME: string;
            TOTAL: string;
        };
        PAID_TO_DATE: string;
    };
    PAYMENT_INFORMATION: {
        ACCOMMODATION_SUBTOTAL: string;
        ALLURA_OFFER_DISCOUNT: string;
        BOOKING_NET_BASE_RATE: string;
        BOOKING_NET_BASE_RATE_MINUS_LOS: string;
        LENGTH_OF_STAY_DISCOUNT: string;
        OWNER_OFFER_DISCOUNT: string;
    };
    PROPERTY: {
        RULES: {
            CHECK_IN: string;
            CHECK_OUT: string;
            MAX_GUESTS: string;
            MIN_AGE_TO_BOOK: number;
            MAX_BOOKABLE_DAYS: number;
            QUIET_TIME: number;
        };
        ADDRESS: {
            UNIT: string;
            RESORT: string;
            DEVELOPMENT: string;
            STREET_NAME: string;
            STREET_NUMBER: string;
        };
        JOIN_STATUS: {
            STATUS_ID: JoinStatusIDEnum;
        };
        ID: number;
        THUMBNAIL_URL: string;
        ACCESS_TO_UNIT: {
            CODE: {
                NAME: string;
                ID: _AccessCodeIdEnum1;
            };
            METHOD: {
                NAME: string;
                ID: _AccessMethodIdEnum1;
            };
            STANDARD_CODE: string;
            TYPE: {
                NAME: string;
                ID: _AccessCodeTypeIDEnum1;
            };
        };
        CODES: {
            BIKE_LOCKER_CODE: string;
            DEVELOPMENT_DOOR_CODE: string;
            DEVELOPMENT_GYM_CODE: string;
            DEVELOPMENT_HOT_TUB_CODE: string;
            DEVELOPMENT_POOL_CODE: string;
            DEVELOPMENT_SAUNA_CODE: string;
            DEVELOPMENT_STEAM_ROOM_CODE: string;
            FRONT_DOOR_CODE: string;
            GAMES_REC_ROOM_CODE: string;
            GARAGE_DOOR_CODE: string;
            GARBAGE_RECYCLING_CODE: string;
            ID: number;
            INTERNET_NETWORK_NAME: string;
            INTERNET_PASSWORD: string;
            PHONE_NUMBER: string;
            PROPERTY_ID: string;
            SKI_LOCKER_CODE: string;
            DATE_LAST_UPDATED: string;
        };
        PRIMARY_CONTACT: EmergencyContact & {
            THUMBNAIL_URL: string;
        };
    };
    REFERENCE: string;
    REVIEW: {
        ID: number;
    };
    SOURCE: string;
    STATUS: {
        ID: BookingStatusId;
        NAME: string;
    };
    STATUSES: {
        DATE: string;
        IS_DONE: boolean;
        LABEL: string;
    }[];
    SURCHARGES: {
        NET: string;
        TAXES_TOTAL: string;
    };
    TAX: {
        TOTAL: string;
    };
    TOTAL: string;
};
export const FULL_BOOKING: {
    /** Total credit card processing fee on this booking.
     *  Deducted from net amount owner recieves for a booking
     *  Calculated from (accomodation + surcharges) x 0.3 = CREDIT_CARD_FEE
     */
    COMMISSION: string;
    CREDIT_CARD_FEE: string;
    /** Percentage fee deducted from the accomodation + surcharges total  */
    CREDIT_CARD_PERCENTAGE: number;
    /** The total amount that the owner will receive for this booking after all other deductions and additions */
    BANK_DEPOSIT: {
        AMOUNT: string;
        DATE: string;
        ACCOUNT: string;
    };
    BLOCK_OFF_REASON: string;
    CONTACT_TRACING: {
        EMAIL: string;
        FIRST_NAME: string;
        ID: number;
        IS_CHILD: boolean;
        LAST_NAME: string;
        PHONE: string;
    }[];
    DATES: {
        NEXT_PAYMENT: string;
        PROPERTY_GUIDEBOOK_SEND: string;
        ARRIVAL: string;
        BOOKING: string;
        BOOKING_TIME: string;
        CHECK_IN_SENT: string;
        DEPARTURE: string;
        SERVER_TIMESTAMP: string;
    };
    FLAGS: {
        IS_ALLURA_BOOKING: boolean;
        IS_BLOCK_OFF: boolean;
        IS_DIRECT_VACATIONS: boolean;
        IS_EDITABLE: boolean;
        IS_INNTOPIA_BOOKING: boolean;
        IS_LMVR_PARTNER_BOOKING: boolean;
        IS_LMVR_PM_BOOKING: boolean;
        IS_PAST_DUE: boolean;
    };
    GUEST: WithRequiredProperty<User, "GUEST_PROFILE">;
    GUEST_COMMENT: string;
    INQUIRIES: (typeof inquiry)[];
    NR6_PERCENTAGE: string;
    NR6_WITHHELD: string;
    PARTNER: {
        INFLATION_TOTAL: number;
    };
    PARTY_SIZE: {
        MAX: number;
        ADULTS: number;
        KIDS: number;
    };
    PAYMENT: {
        DAMAGE_DEPOSIT: {
            AMOUNT: string;
            DUE_DATE: string;
            IS_COLLECTED: boolean;
            MODE: string;
            MODE_ID: DamageDepositModeId;
        };
        DEPOSIT: {
            AMOUNT: string;
            DUE_DATE: string;
            NET: string;
            PAYMENT_DATE: string;
            PERCENTAGE: number;
            TOTAL: string;
        };
        BOOKING_NET: string;
        BOOKING_GROSS: string;
        PAID_TO_DATE: string;
        PRICE_PER_NIGHT: string;
        TAXES_AND_FEES_TOTAL: string;
        LOS_DISCOUNT: string;
        AMOUNT_OUTSTANDING: string;
        AMOUNT_REFUNDED: string;
        BALANCE: {
            DUE_DATE: string;
            PAYMENT_DATE: string;
            TOTAL: string;
        };
        NEXT_PAYMENT: {
            DUE_DATE: string;
            IS_PAST_DUE: boolean;
            NAME: string;
            TOTAL: string;
        };
    };
    PROPERTY: {
        ADDRESS: {
            AREA: string;
            AREA_ID: number;
            CITY: string;
            COUNTRY: string;
            COUNTRY_CODE: string;
            COUNTRY_ID: number;
            DEVELOPMENT: string;
            DEVELOPMENT_ID: number;
            ID: number;
            LATITUDE: number;
            LONGITUDE: number;
            POSTAL: string;
            REGION: string;
            REGION_ID: number;
            RESORT: string;
            RESORT_ID: number;
            STREET_NAME: string;
            STREET_NUMBER: string;
            UNIT: string;
        };
        DIRECT_VACATIONS: {
            ID: number;
            IS_ACTIVE: boolean;
            LOGO: string;
            NAME: string;
            URL: string;
        };
        DAMAGE_DEPOSIT: {
            AMOUNT: string;
            DESCRIPTION: string;
            ID: number;
            IS_COLLECTED: boolean;
            MODE: string;
        };
        GATEWAY_MODE: {
            ID: BookingGateWayModeIdEnum;
            VALUE: string;
        };
        RULES: {
            ID: number;
            ADVANCED_BOOKING: {
                NAME: string;
                ID: number;
            };
            CHECK_IN: string;
            CHECK_OUT: string;
            MAX_BOOKABLE_DAYS: number;
            MAX_GUESTS: number;
            MIN_AGE_TO_BOOK: number;
            QUIET_TIME: string;
        };
        IS_ENABLED: boolean;
        MAX_GUESTS: number;
        NAME: string;
        SIZE_CATEGORY: string;
        SQUARE_FEET: number;
        SURCHARGES: {
            PETS: {
                IS_ENABLED: boolean;
                NAME: string;
                ID: number;
                AMOUNT: string;
            };
            CLEANING: {
                IS_ENABLED: boolean;
                NAME: string;
                ID: number;
                AMOUNT: string;
            };
        };
        STYLE: string;
        URL: string;
        JOIN_STATUS: {
            STATUS_ID: JoinStatusIDEnum;
        };
        ID: number;
        THUMBNAIL_URL: string;
        ACCESS_TO_UNIT: {
            CODE: {
                NAME: string;
                ID: _AccessCodeIdEnum1;
            };
            METHOD: {
                NAME: string;
                ID: _AccessMethodIdEnum1;
            };
            STANDARD_CODE: string;
            TYPE: {
                NAME: string;
                ID: _AccessCodeTypeIDEnum1;
            };
        };
        CODES: {
            BIKE_LOCKER_CODE: string;
            DEVELOPMENT_DOOR_CODE: string;
            DEVELOPMENT_GYM_CODE: string;
            DEVELOPMENT_HOT_TUB_CODE: string;
            DEVELOPMENT_POOL_CODE: string;
            DEVELOPMENT_SAUNA_CODE: string;
            DEVELOPMENT_STEAM_ROOM_CODE: string;
            FRONT_DOOR_CODE: string;
            GAMES_REC_ROOM_CODE: string;
            GARAGE_DOOR_CODE: string;
            GARBAGE_RECYCLING_CODE: string;
            ID: number;
            INTERNET_NETWORK_NAME: string;
            INTERNET_PASSWORD: string;
            PHONE_NUMBER: string;
            PROPERTY_ID: string;
            SKI_LOCKER_CODE: string;
            DATE_LAST_UPDATED: string;
        };
        PRIMARY_CONTACT: EmergencyContact & {
            THUMBNAIL_URL: string;
        };
    };
    PROPERTY_GUIDEBOOK_SEND_DATE: string;
    PROPERTY_MANAGER_SERVICE_FEE: {
        IS_FEE_ON_SUBTOTAL_TO_OWNER: boolean;
        NET: string;
        TAXES: {
            AMOUNT: string;
            ID: number;
            IS_PASS_THROUGH_TO_OWNER: boolean;
            NAME: string;
            RATE: number;
        }[];
        TOTAL: string;
    };
    PROPERTY_OWNER: {
        COMPANY_NAME: string;
        FIRST_NAME: string;
        ID: number;
        IS_COMPANY: boolean;
        LAST_NAME: string;
        EMAIL: string;
        THUMBNAIL: string;
    };
    REVIEW: Readonly<{
        PRIVATE_MESSAGE_TO_OWNER: "";
        REVIEW: "";
        GUEST_INFO: any;
        PUBLISHED_DATE: "";
        RATINGS: RatingItem[];
        RATINGS_AVERAGE: 0;
        RESPONSES: ReviewResponse[];
        REVIEW_DATE: "";
        TITLE: "";
        WOULD_RECOMMEND: false;
        BOOKING_INFO: {
            RESORT: string;
            NIGHTS: number;
            ARRIVAL: string;
            DEPARTURE: string;
            DEVELOPMENT: string;
            REFERENCE: string;
            CONFIRMED: string;
            ID: number;
            PROPERTY_IMAGE: string;
        };
        ID: number;
        IS_GUEST_RESPONSE_POSSIBLE: boolean;
        IS_PUBLISHED: boolean;
        STATUS: string;
        STATUS_ID: ReviewStatusId;
    }>;
    SERVICE_FEE: {
        DESCRIPTION: string;
        FEE: string;
        ID: number;
        NAME: string;
        TAX: string;
        TAXES: {
            AMOUNT: string;
            ID: number;
            IS_PASS_THROUGH_TO_OWNER: boolean;
            NAME: string;
            RATE: number;
        }[];
        TAXES_STRING: string;
        TOTAL: string;
    };
    SURCHARGES: {
        GROSS: string;
        LIST: {
            [key: string]: {
                IS_ENABLED: boolean;
                TAX: string;
                TAXES: {};
                FEE: string;
                NAME: string;
                ID: number;
                TOTAL: string;
            };
        };
        NET: string;
        TAXES_TOTAL: string;
        TAXES_TOTALS: {
            AMOUNT: string;
            ID: number;
            IS_PASS_THROUGH_TO_OWNER: boolean;
            NAME: string;
            RATE: number;
        }[];
    };
    /** Taxes applied to the accommodation subtotal */
    TAX: {
        RATE_TOTAL: number;
        /** Taxes aplied to the accomodation/booking subtotal (PAYMENT.BOOKING_NET)
         * This can be an empty array due to the rulesets below:
         *
        # Bookings and Surcharges on Inntopia (Partner Bookings)
        * will have GST applied, if an owner collects GST and has supplied a GST Number
        * if rental in BC, has PST and MRDT applied
      
        # Bookings on alluraDirect
        * will have GST applied, if an owner collects GST and has supplied a GST Number, and if the booking is under 30 nights, else it is GST exempt and the tax is not applied
        * if rental in BC, has PST and MRDT applied if the booking is under 27 nights, else it is PST/MRDT exempt and those taxes are not applied
        * if rental in PQ, has QST and MTLT applied if owner decides to charge and remit these taxes
         */
        BOOKING: {
            AMOUNT: string;
            ID: number;
            IS_PASS_THROUGH_TO_OWNER: boolean;
            NAME: string;
            RATE: number;
        }[];
        BOOKING_AND_FEES: {
            AMOUNT: string;
            ID: number;
            IS_PASS_THROUGH_TO_OWNER: boolean;
            NAME: string;
            RATE: number;
        }[];
        BOOKING_AND_FEES_TOTAL: number;
        PERCENTAGES: string;
        TOTAL: number;
        TOTALS: {
            AMOUNT: string;
            ID: number;
            IS_PASS_THROUGH_TO_OWNER: boolean;
            NAME: string;
            RATE: number;
        }[];
        WITHHELD: {
            GST: string;
            PST: string;
            MRDT: string;
        };
    };
    THUMBNAIL_URL: string;
    TOTALS_PAID: {
        ACCOMMODATION_NET: string;
        ACCOMMODATION_TAXES: {
            AMOUNT: string;
            NAME: string;
        }[];
        BANK_DEPOSIT: string;
        COMMISSION: string;
        COMMISSION_PARTNER: string;
        CREDIT_CARD_FEE: string;
        DAMAGE_DEPOSIT: string;
        NR6: string;
        OWNER_PASS_THROUGH_TAXES: {
            AMOUNT: string;
            ID: number;
            IS_PASS_THROUGH_TO_OWNER: boolean;
            NAME: string;
            RATE: number;
        }[];
        REVENUE_NET: string;
        PROPERTY_MANAGER_SERVICE_FEE: {
            IS_FEE_ON_SUBTOTAL_TO_OWNER: boolean;
            NET: string;
            TAXES: {
                AMOUNT: string;
                ID: number;
                IS_PASS_THROUGH_TO_OWNER: boolean;
                NAME: string;
                RATE: number;
            }[];
            TOTAL: string;
        };
        SURCHARGE: {
            TAXES: {
                AMOUNT: string;
                ID: number;
                IS_PASS_THROUGH_TO_OWNER: boolean;
                NAME: string;
                RATE: number;
            }[];
            NET: string;
        };
        SURCHARGE_NET: string;
        SURCHARGE_TAXES: {
            AMOUNT: string;
            ID: number;
            IS_PASS_THROUGH_TO_OWNER: boolean;
            NAME: string;
            RATE: number;
        }[];
        TAX: string;
    };
    TRANSACTIONS: {
        AMOUNT: string;
        BANK_DEPOSIT: {
            ACCOUNT: string;
            AMOUNT: string;
            DATE: string;
        };
        BOOKING_NET: string;
        CATEGORY: string;
        COMMISSION: {
            GST: string;
            MRDT: string;
            NET: string;
            PST: string;
            TOTAL: string;
        };
        CREDIT_CARD: {
            CARDHOLDER_NAME: string;
            NAME: string;
            NUMBER: string;
        };
        CREDIT_CARD_WITHHELD: string;
        DAMAGE_DEPOSIT_AMOUNT: string;
        DATE: string;
        ID: number;
        NR6_PERCENTAGE: number;
        NR6_WITHHELD: string;
        SERVICE_FEE: {
            FEE: number;
            ID: number;
            NAME: string;
            TAX: number;
            TAXES: {
                AMOUNT: number;
                ID: number;
                NAME: string;
                RATE: number;
            }[];
            TOTAL: number;
        };
        SURCHARGES: {
            GROSS: string;
            LIST: {
                [key: string]: {
                    IS_ENABLED: boolean;
                    TAX: string;
                    TAXES: {};
                    FEE: string;
                    NAME: string;
                    ID: number;
                    TOTAL: string;
                };
            };
            NET: string;
            TAXES_TOTAL: string;
            TAXES_TOTALS: {
                AMOUNT: string;
                ID: number;
                IS_PASS_THROUGH_TO_OWNER: boolean;
                NAME: string;
                RATE: number;
            }[];
        };
        TAX: {
            TAXES: {
                AMOUNT: string;
                ID: number;
                IS_PASS_THROUGH_TO_OWNER: boolean;
                NAME: string;
                RATE: number;
            }[];
            TOTAL: string;
            WITHHELD: {
                MRDT: string;
                PST: string;
            };
        };
        TYPE: string;
    }[];
    TIMELINE: {
        DATE: string;
        TITLE: string;
        IS_COMPLETED: boolean;
    }[];
    CUSTOM_MESSAGE: {
        MESSAGE: string;
        ENTRY_CODE: string;
    };
    GUEST_REQUESTS: string;
    ID: number;
    NIGHTS: number;
    NIGHTLY_RATES: {
        DATE: string;
        DAY: string;
        RATE: string;
        BASE_RATE: string;
        LOS_DISCOUNT: string;
        OFFER_DISCOUNT: string;
    }[];
    NOTES_OWNER: string;
    PAYMENT_INFORMATION: {
        ACCOMMODATION_SUBTOTAL: string;
        ALLURA_OFFER_DISCOUNT: string;
        BOOKING_NET_BASE_RATE: string;
        BOOKING_NET_BASE_RATE_MINUS_LOS: string;
        LENGTH_OF_STAY_DISCOUNT: string;
        OWNER_OFFER_DISCOUNT: string;
    };
    REFERENCE: string;
    SOURCE: string;
    STATUS: {
        ID: BookingStatusId;
        NAME: string;
    };
    STATUSES: {
        DATE: string;
        IS_DONE: boolean;
        LABEL: string;
    }[];
    TOTAL: string;
};
export const bookingSurcharge: {
    FEE: string;
    ID: number;
    NAME: string;
    TAX: string;
    Taxes: {
        IS_PASS_THROUGH_TO_OWNER: boolean;
        AMOUNT: string;
        ID: number;
        NAME: string;
    };
};
export const bookingSurchargesTotal: {
    TAXES_TOTAL: number;
    LIST: never[];
    NET: string;
    GROSS: string;
    TAXES_TOTALS: string;
};
export const bookingTax: {
    RATE: number;
    IS_PASS_THROUGH_TO_OWNER: boolean;
    AMOUNT: string;
    ID: number;
    NAME: string;
};
export const BOOKING_GUEST_EXISTS: {
    IS_EXISTING_GUEST: boolean;
};
export enum OfferTypeId {
    PERCENTAGE = 1,
    DOLLAR = 2,
    FREE_NIGHTS = 3,
    GIFT_CERTIFICATE = 4
}
export enum OfferAvailabilityId {
    AllGuests = 1,
    RepeatGuests = 2,
    SpecificGuest = 3
}
export enum OfferDistributionId {
    WITHPROPERTYGUIDEBOOK = 1,
    WHENNONREFUNDABLE = 2
}
interface OfferCommon {
    BLACKOUT_PERIODS: {
        START: string;
        END: string;
    }[];
    CODE: string;
    DESCRIPTION: string;
    DISTRIBUTION: string;
    DISTRIBUTION_ID: number;
    DOLLAR: string;
    GIFT_CERTIFICATE_URL: string;
    GUEST_EMAIL: string;
    GUEST_ID: number;
    INSTRUCTIONS: string;
    IS_ALL_PROPERTIES: boolean;
    IS_EDITABLE: boolean;
    IS_ENABLED: boolean;
    IS_PROMOTED: boolean;
    IS_PUBLIC: boolean;
    MAX_USAGE_COUNT: number;
    MIN_NIGHTS: string;
    NIGHTS_FREE: number;
    NIGHTS_REQUIRED: number;
    OFFER_AVAILABILITY_ID: number;
    OFFER_AVAILABLE_END: string;
    OFFER_AVAILABLE_START: string;
    OFFER_CATEGORY: string;
    OFFER_CATEGORY_ID: number;
    OFFER_END: string;
    OFFER_ID: number;
    OFFER_START: string;
    OFFER_TYPE: string;
    OFFER_TYPE_ID: number;
    OFFER_URL: string;
    PERCENTAGE: number;
    PROPERTY_IDS: string;
    STATUS: string;
    TITLE: string;
    USAGE_COUNT: number;
    USER_ID: number;
}
export interface OfferPercent extends OfferCommon {
    OFFER_TYPE_ID: OfferTypeId.PERCENTAGE;
}
export interface OfferDollar extends OfferCommon {
    OFFER_TYPE_ID: OfferTypeId.DOLLAR;
}
export interface OfferNights extends OfferCommon {
    OFFER_TYPE_ID: OfferTypeId.FREE_NIGHTS;
}
export interface OfferGiftCertificate extends OfferCommon {
    OFFER_TYPE_ID: OfferTypeId.GIFT_CERTIFICATE;
}
export type Offer = OfferPercent | OfferDollar | OfferNights | OfferGiftCertificate | undefined | '';
type FullBookingRoot = typeof FULL_BOOKING;
export type Offers = {
    OWNER: {
        OFFER: Offer;
        TOTAL: '';
    };
    ALLURA: {
        OFFER: Offer;
        TOTAL: '';
    };
};
export type GiftCertificates = {
    OWNER: {
        OFFER: Offer;
        TOTAL: '';
    };
    ALLURA: {
        OFFER: Offer;
        TOTAL: '';
    };
};
export interface iFullBookingRoot extends FullBookingRoot {
    OFFERS: Offers;
    GIFT_CERTIFICATES: GiftCertificates;
}
interface InflatedFullBooking extends iFullBookingRoot {
    /** This is the value of the commission fee that will be paid to a partner.
     * This is useful for an owner when they want to know how much commission a guest has paid on their reservation.
     * For instance, an owner may receive $100 for a booking, but the guest would have paid $120.
     * In this case, the commission is $20 */
    PARTNER_COMMISSION_FEE_TOTAL: number;
}
export interface FullBooking extends iFullBookingRoot {
    INFLATED_BOOKING?: InflatedFullBooking;
}
export type SparseBooking = typeof SPARSE_BOOKING;
export type Booking = SparseBooking | FullBooking;
export type Review = typeof REVIEW;
export type EligibleReview = typeof ELIGIBLE_REVIEW;
export type BookingStatus = typeof bookingStatus;
export type BookingSurcharge = typeof bookingSurcharge;
export type BookingTax = typeof bookingTax;
export type BookingTaxes = BookingTax[];
export type BookingSurchargesTotal = typeof bookingSurchargesTotal;
export type BookingInfo = typeof bookingInfo;
export type BookingProperty = typeof BOOKING_PROPERTY;
export type BookingGuestExists = typeof BOOKING_GUEST_EXISTS;
export type CustomMessage = typeof CUSTOM_MESSAGE;
export type RatingRange = 0 | 1 | 2 | 3 | 4 | 5;
export enum BookingSourceNameEnum {
    directVacations = "DirectVacations.com",
    directVacationsLabel = "Emails and logos will be sent and branded with DirectVacations.com",
    alluraDirect = "alluraDirect Vacation Rentals",
    alluraDirectLabel = "*Recommended (Trusted Brand) - Emails and logos will be sent and branded with alluraDirect"
}
export enum BookingStatusId {
    ReservationRequest = 1,
    DepositPaidDue = 2,
    BalancePaid = 3,
    Cancelled = 4,
    ReservationRequestDeclined = 5
}
export enum BookingStatusMessage {
    ReservationRequested = "Reservation Requested",
    DepositDue = "Deposit Due",
    PaymentDue = "Payment Due",
    Confirmed = "Confirmed",
    Cancelled = "Cancelled",
    ReservationDeclined = "Reservation Declined",
    LatePayment = "Late Payment",
    Completed = "Completed",
    UnknownStatusId = "Unknown Status"
}
export enum ReviewStatusId {
    ADD_REVIEW = 0,
    SUBMITTED = 1,
    AD_APPROVED = 2,
    AD_REJECTED = 3,
    PUBLISHED = 4,
    OWNER_HIDDEN = 5,
    OWNER_DISPUTED = 6
}
export interface ReviewResponse {
    ID: number;
    RESPONSE: string;
    RESPONSE_DATE: string;
    TITLE: string;
    USER_ROLE: 'owner' | 'guest';
}
export interface RatingItem {
    QUESTION: string;
    MAX_SCORE: number;
    ID: number;
    TITLE: string;
    SCORE: RatingRange;
}
export interface CreateBookingBody {
    ALLURA_GIFT_CERTIFICATE_ID?: number | string;
    ALLURA_GIFT_CERTIFICATE_CODE?: string;
    ALLURA_OFFER_ID?: number | string;
    ALLURA_OFFER_CODE?: string;
    ARRIVAL: string;
    BALANCE_DUE_DATE: string;
    BOOKING_NET: string;
    DAMAGE_DEPOSIT_AMOUNT: string;
    DAMAGE_DEPOSIT_MODE_ID: number | string;
    DEPOSIT_DUE_DATE: string;
    DEPOSIT_PERCENTAGE: number;
    GUEST_EMAIL: string;
    GUEST_FIRST_NAME?: string;
    GUEST_LAST_NAME?: string;
    GUEST_PHONE?: string;
    IS_DIRECT_VACATIONS: boolean;
    NIGHTS: number;
    NOTES_OWNER: string;
    OWNER_GIFT_CERTIFICATE_ID?: number | string;
    OWNER_GIFT_CERTIFICATE_CODE?: string;
    OWNER_OFFER_ID?: number | string;
    OWNER_OFFER_CODE?: string;
    PARTY_SIZE_ADULTS: number;
    PARTY_SIZE_KIDS: number;
    PRICE_PER_NIGHT: number;
    PROPERTY_ID: number;
    SURCHARGE_AMOUNT_CLEANING: number | string;
    SURCHARGE_AMOUNT_PETS: number | string;
    SURCHARGE_IDS: string;
}
export interface EditBookingBody extends CreateBookingBody {
    ID: number;
}
export interface QuoteParams {
    ARRIVAL: string;
    NIGHTS: number;
    ALLURA_GIFT_CERTIFICATE_ID?: number | string;
    ALLURA_GIFT_CERTIFICATE_CODE?: string;
    ALLURA_OFFER_ID?: number | string;
    ALLURA_OFFER_CODE?: string;
    BALANCE_DUE_DATE?: string;
    BOOKING_NET?: string;
    DAMAGE_DEPOSIT_AMOUNT?: number;
    DAMAGE_DEPOSIT_MODE_ID?: number;
    DEPOSIT_DUE_DATE?: string;
    DEPOSIT_PERCENTAGE?: number;
    GUEST_EMAIL?: string;
    GUEST_FIRST_NAME?: string;
    GUEST_LAST_NAME?: string;
    ID?: number;
    IS_DIRECT_VACATIONS?: boolean;
    NOTES_OWNER?: string;
    OWNER_GIFT_CERTIFICATE_ID?: number | string;
    OWNER_GIFT_CERTIFICATE_CODE?: string;
    OWNER_OFFER_ID?: number | string;
    OWNER_OFFER_CODE?: string;
    PARTY_SIZE_ADULTS?: number;
    PARTY_SIZE_KIDS?: number;
    PRICE_PER_NIGHT?: number;
    SURCHARGE_AMOUNT_CLEANING?: number;
    SURCHARGE_AMOUNT_PETS?: number;
    SURCHARGE_IDS?: string;
}
export enum MessageRecipientIdEnum {
    guestToOwner = 1,
    ownerToGuest = 2,
    guestToAllura = 3,
    ownerToAllura = 4,
    alluraToOwner = 5,
    alluraToGuest = 6
}
/** Endpoint:    `/booking/cancellationDetails/?id=${bookingId}`;*/
export interface CancellationDetails {
    /** The total amount of money that allura has collected from the guest*/
    AMOUNTS_COLLECTED: {
        /** The value of the accommodation, does not include taxes or fees */
        ACCOMMODATION_NET: string;
        /** The total amount that the owner received */
        BANK_DEPOSIT_TOTAL: string;
        /** allura booking subscription commission (paid by Owner) */
        BOOKING_COMMISSION: string;
        /** Currently 3% of all AMOUNTS_COLLECTED minus GUEST_SERVICE_FEE */
        CREDIT_CARD_FEES: string;
        /** Only applicable when Property requires a payment upfront  */
        DAMAGE_DEPOSIT: string;
        /** allura Booking Service Fee (paid by Guest) */
        GUEST_SERVICE_FEE: string;
        /** Only applies to Non Resident Owners - the amount that allura holds */
        NON_RESIDENT_WITHHELD: string;
        /** Net value of surcharges, Pets and Cleaning fee for example */
        SURCHARGES_NET: string;
        TAXES: {
            /** allura can manage taxes for an owner and remit them to the government */
            ALLURA_REMITTED: string;
            /** the owner can manage their own taxes */
            OWNER_RECEIVED: string;
            /** Combined value of owner received and allura remitted */
            TOTAL: string;
        };
        /** The total amount that the guest was charged */
        TOTAL_GUEST_CHARGE: string;
    };
    /** The status of booking at this time (Deposit Paid/Due||Balance Paid) */
    BOOKING_STATUS: BookingStatusId;
    /** The amount that the guest will receive*/
    CANCELLATION_AMOUNT: {
        /** If the Guest Cancels the booking, this is how much the owner must e-transfer to Allura */
        BY_GUEST: string;
        /** If the Owner Cancels the booking, this is how much the owner must e-transfer to Allura */
        BY_OWNER: string;
    };
    CANCELLATION_POLICY: {
        NAME: string;
        HTML: string;
    };
}
interface _Args2 {
    guestEmail: string;
}
export const useBookingGuestExistsQuery: ({ guestEmail, enabled, ...rest }: _Args2 & ConfigurableAppQueryArgs) => UseQueryResult<APIResponse<{
    IS_EXISTING_GUEST: boolean;
}>, Error>;
export const GUEST_FORM_INPUTS: {
    GUEST_ID: number;
    REVIEW: {
        RATINGS: GuestRatingQuestion[];
        RESPONSES: {
            GUEST_MAXIMUM_NUMBER: number;
            OWNER_MAXIMUM_NUMBER: number;
        };
        STATUSES: never[];
    };
};
export const GUEST_RATING_QUESTION: {
    QUESTION: string;
    MAX_SCORE: number;
    ID: number;
    TITLE: string;
    SCORE: RatingRange;
    SORT_ORDER: number;
};
export const GUEST_REVIEWS: {
    REVIEWS: Review[];
    RECOMMENDATIONS: GuestRecommendation[];
};
export const GUEST_RECOMMENDATION: {
    ARRIVAL: string;
    COMMENTS: string;
    CONFIRMED: string;
    DEPARTURE: string;
    HAS_COMMENTS_ENABLED: boolean;
    HOST_NAME: string;
    ID: number;
    IS_RECOMMENDED: boolean;
    REFERENCE: string;
    BOOKING_ID: number;
};
export const GUEST_PAYMENT: {
    ID: number;
    BOOKING_ID: number;
    BOOKING: GuestBooking;
    BOOKING_TYPE: GuestBookingType;
    PAYMENT_RECEIPT: string;
};
export const GUEST_PAYMENT_INFORMATION: {
    ID: number;
    PAYMENT_DUE: {
        BOOKING: {
            AMOUNT_DUE: number;
            ARRIVAL: string;
            BOOKING_NET: number;
            BOOKING_TOTAL: number;
            DAMAGE_DEPOSIT: number;
            DEPARTURE: string;
            ID: number;
            NIGHTLY_RATE: number;
            NIGHTS: number;
            PAID_TO_DATE: number;
            PARTY_SIZE: number;
            TAXES_AND_FEES_TOTAL: number;
        };
        FEES: GuestPaymentFee[];
        TAXES: GuestPaymentTaxes[];
    };
};
export const subSection: {
    ID: number;
    HTML: string[] | string;
    DETAILS: {
        NAME: string;
        VALUE: string;
    }[];
};
export const propertyGuidebook: Readonly<{
    PROPERTY_GUIDEBOOK: {
        BOOKING: {
            CUSTOM_MESSAGE: {
                MESSAGE: string;
                ENTRY_CODE: string;
            };
            STATUS: {
                ID: BookingStatusId;
                NAME: string;
            };
        };
        PROPERTY: {
            ID: number;
            IS_SKI_IN_SKI_OUT: boolean;
            THUMBNAIL: string;
            IS_COMPANY: string;
            ARRIVAL: string;
            DEPARTURE: string;
            CHECK_IN_TIME: string;
            CHECK_OUT_TIME: string;
            QUIET_TIME: string;
            BATHROOMS: Bathroom[];
            BEDROOMS: Bedroom[];
            LOGO: string;
            COVER_PHOTO: string;
            LISTING_PAGE: string;
            ACCESS_TO_UNIT: {
                CODE: {
                    NAME: string;
                    ID: _AccessCodeIdEnum1;
                };
                METHOD: {
                    NAME: string;
                    ID: _AccessMethodIdEnum1;
                };
                STANDARD_CODE: string;
                TYPE: {
                    NAME: string;
                    ID: _AccessCodeTypeIDEnum1;
                };
            };
            ADDRESS: {
                AREA: string;
                AREA_ID: number;
                CITY: string;
                COUNTRY: string;
                COUNTRY_CODE: string;
                COUNTRY_ID: number;
                DEVELOPMENT: string;
                DEVELOPMENT_ID: number;
                ID: number;
                LATITUDE: number;
                LONGITUDE: number;
                POSTAL: string;
                REGION: string;
                REGION_ID: number;
                RESORT: string;
                RESORT_ID: number;
                STREET_NAME: string;
                STREET_NUMBER: string;
                UNIT: string;
            };
            OWNER: WithRequiredProperty<User, "OWNER_PROFILE">;
            CODES: {
                BIKE_LOCKER_CODE: string;
                DEVELOPMENT_DOOR_CODE: string;
                DEVELOPMENT_GYM_CODE: string;
                DEVELOPMENT_HOT_TUB_CODE: string;
                DEVELOPMENT_POOL_CODE: string;
                DEVELOPMENT_SAUNA_CODE: string;
                DEVELOPMENT_STEAM_ROOM_CODE: string;
                FRONT_DOOR_CODE: string;
                GAMES_REC_ROOM_CODE: string;
                GARAGE_DOOR_CODE: string;
                GARBAGE_RECYCLING_CODE: string;
                ID: number;
                INTERNET_NETWORK_NAME: string;
                INTERNET_PASSWORD: string;
                PHONE_NUMBER: string;
                PROPERTY_ID: string;
                SKI_LOCKER_CODE: string;
                DATE_LAST_UPDATED: string;
            };
            EMERGENCY_CONTACTS: {
                DESCRIPTION: string;
                CONTACTS: {
                    OTHERS: EmergencyContact[];
                    PRIMARY: EmergencyContact;
                };
            };
            PHOTOS: Photo[];
            PRIMARY_CONTACT: User;
        };
        SECTIONS: {
            WELCOME: {
                DESCRIPTION_PER_GUEST: string;
                TITLE: string;
                DESCRIPTION_PER_PROPERTY: string;
            };
            ARRIVAL: {
                ACCESS_DETAILS: {
                    DATA: {
                        ID: number;
                        HTML: string[] | string;
                        DETAILS: {
                            NAME: string;
                            VALUE: string;
                        }[];
                    };
                    ICON: string;
                    DESCRIPTION: string;
                    TITLE: string;
                };
                DIRECTIONS_TO_PROPERTY: {
                    DATA: {
                        ID: number;
                        HTML: string[] | string;
                        DETAILS: {
                            NAME: string;
                            VALUE: string;
                        }[];
                    };
                    ICON: string;
                    DESCRIPTION: string;
                    TITLE: string;
                };
                PARKING: {
                    DATA: {
                        ID: number;
                        HTML: string[] | string;
                        DETAILS: {
                            NAME: string;
                            VALUE: string;
                        }[];
                    };
                    ICON: string;
                    DESCRIPTION: string;
                    TITLE: string;
                };
                CHECK_IN_PROCESS: {
                    DATA: {
                        ID: number;
                        HTML: string[] | string;
                        DETAILS: {
                            NAME: string;
                            VALUE: string;
                        }[];
                    };
                    ICON: string;
                    DESCRIPTION: string;
                    TITLE: string;
                };
            };
            DEPARTURE: {
                CHECK_OUT_PROCESS: {
                    DATA: {
                        ID: number;
                        HTML: string[] | string;
                        DETAILS: {
                            NAME: string;
                            VALUE: string;
                        }[];
                    };
                    ICON: string;
                    DESCRIPTION: string;
                    TITLE: string;
                };
                GARBAGE_REMOVAL: {
                    DATA: {
                        ID: number;
                        HTML: string[] | string;
                        DETAILS: {
                            NAME: string;
                            VALUE: string;
                        }[];
                    };
                    ICON: string;
                    DESCRIPTION: string;
                    TITLE: string;
                };
            };
            PROPERTY_AMENITIES: {
                PRIVATE: {
                    DATA: {
                        ID: number;
                        NAME: string;
                        INSTRUCTIONS: string;
                        DESCRIPTION: string;
                        PROPERTY_AMENITY_ID: number;
                        ACCESS_CODE: string;
                        INTERNET_PASSWORD: string;
                        INTERNET_NETWORK_NAME: string;
                    }[];
                    ICON: string;
                    DESCRIPTION: string;
                    TITLE: string;
                };
                ESSENTIALS: {
                    DATA: {
                        ID: number;
                        NAME: string;
                        INSTRUCTIONS: string;
                        DESCRIPTION: string;
                        PROPERTY_AMENITY_ID: number;
                        ACCESS_CODE: string;
                        INTERNET_PASSWORD: string;
                        INTERNET_NETWORK_NAME: string;
                    }[];
                    ICON: string;
                    DESCRIPTION: string;
                    TITLE: string;
                };
                KITCHEN: {
                    DATA: {
                        ID: number;
                        NAME: string;
                        INSTRUCTIONS: string;
                        DESCRIPTION: string;
                        PROPERTY_AMENITY_ID: number;
                        ACCESS_CODE: string;
                        INTERNET_PASSWORD: string;
                        INTERNET_NETWORK_NAME: string;
                    }[];
                    ICON: string;
                    DESCRIPTION: string;
                    TITLE: string;
                };
                SAFETY: {
                    DATA: {
                        ID: number;
                        NAME: string;
                        INSTRUCTIONS: string;
                        DESCRIPTION: string;
                        PROPERTY_AMENITY_ID: number;
                        ACCESS_CODE: string;
                        INTERNET_PASSWORD: string;
                        INTERNET_NETWORK_NAME: string;
                    }[];
                    ICON: string;
                    DESCRIPTION: string;
                    TITLE: string;
                };
                HEATING_INSTRUCTIONS: {
                    DATA: string[] | string;
                    ICON: string;
                    DESCRIPTION: string;
                    TITLE: string;
                };
                LINENS_TOWELS: {
                    DATA: string[] | string;
                    ICON: string;
                    DESCRIPTION: string;
                    TITLE: string;
                };
            };
            BUILDING_FACILITIES: {
                ABOUT_BUILDING: {
                    DATA: {
                        ID: number;
                        HTML: string[] | string;
                        DETAILS: {
                            NAME: string;
                            VALUE: string;
                        }[];
                    };
                    ICON: string;
                    DESCRIPTION: string;
                    TITLE: string;
                };
                FRONT_DESK: {
                    DATA: {
                        ID: number;
                        HTML: string[] | string;
                        DETAILS: {
                            NAME: string;
                            VALUE: string;
                        }[];
                    };
                    ICON: string;
                    DESCRIPTION: string;
                    TITLE: string;
                };
                BUILDING_AMENITIES: {
                    DATA: {
                        ID: number;
                        NAME: string;
                        INSTRUCTIONS: string;
                        DESCRIPTION: string;
                        PROPERTY_AMENITY_ID: number;
                        ACCESS_CODE: string;
                        INTERNET_PASSWORD: string;
                        INTERNET_NETWORK_NAME: string;
                    }[];
                    ICON: string;
                    DESCRIPTION: string;
                    TITLE: string;
                };
            };
            EQUIPMENT_STORAGE: {
                SKI_STORAGE: {
                    DATA: {
                        PRIVATE: {
                            ID: number;
                            NAME: string;
                            INSTRUCTIONS: string;
                            DESCRIPTION: string;
                            PROPERTY_AMENITY_ID: number;
                            ACCESS_CODE: string;
                            INTERNET_PASSWORD: string;
                            INTERNET_NETWORK_NAME: string;
                        };
                        BUILDING: {
                            ID: number;
                            NAME: string;
                            INSTRUCTIONS: string;
                            DESCRIPTION: string;
                            PROPERTY_AMENITY_ID: number;
                            ACCESS_CODE: string;
                            INTERNET_PASSWORD: string;
                            INTERNET_NETWORK_NAME: string;
                        };
                    };
                    ICON: string;
                    DESCRIPTION: string;
                    TITLE: string;
                };
                BIKE_STORAGE: {
                    DATA: {
                        PRIVATE: {
                            ID: number;
                            NAME: string;
                            INSTRUCTIONS: string;
                            DESCRIPTION: string;
                            PROPERTY_AMENITY_ID: number;
                            ACCESS_CODE: string;
                            INTERNET_PASSWORD: string;
                            INTERNET_NETWORK_NAME: string;
                        };
                        BUILDING: {
                            ID: number;
                            NAME: string;
                            INSTRUCTIONS: string;
                            DESCRIPTION: string;
                            PROPERTY_AMENITY_ID: number;
                            ACCESS_CODE: string;
                            INTERNET_PASSWORD: string;
                            INTERNET_NETWORK_NAME: string;
                        };
                    };
                    ICON: string;
                    DESCRIPTION: string;
                    TITLE: string;
                };
            };
            GETTING_AROUND: {
                SKI_IN_OUT: {
                    DATA: {
                        ID: number;
                        HTML: string[] | string;
                        DETAILS: {
                            NAME: string;
                            VALUE: string;
                        }[];
                    };
                    ICON: string;
                    DESCRIPTION: string;
                    TITLE: string;
                };
                DIRECTIONS_TO_LIFTS: {
                    DATA: {
                        ID: number;
                        HTML: string[] | string;
                        DETAILS: {
                            NAME: string;
                            VALUE: string;
                        }[];
                    };
                    ICON: string;
                    DESCRIPTION: string;
                    TITLE: string;
                };
                GETTING_AROUND: {
                    DATA: {
                        ID: number;
                        HTML: string[] | string;
                        DETAILS: {
                            NAME: string;
                            VALUE: string;
                        }[];
                    };
                    ICON: string;
                    DESCRIPTION: string;
                    TITLE: string;
                };
            };
            RECOMMENDATIONS: {
                WHAT_TO_BRING: {
                    DATA: {
                        ID: number;
                        HTML: string[] | string;
                        DETAILS: {
                            NAME: string;
                            VALUE: string;
                        }[];
                    };
                    ICON: string;
                    DESCRIPTION: string;
                    TITLE: string;
                };
                RESTAURANTS: {
                    DATA: {
                        ID: number;
                        HTML: string[] | string;
                        DETAILS: {
                            NAME: string;
                            VALUE: string;
                        }[];
                    };
                    ICON: string;
                    DESCRIPTION: string;
                    TITLE: string;
                };
            };
            SERVICES_OTHER: {
                AVAILABLE_SERVICES: {
                    DATA: {
                        ID: number;
                        HTML: string[] | string;
                        DETAILS: {
                            NAME: string;
                            VALUE: string;
                        }[];
                    };
                    ICON: string;
                    DESCRIPTION: string;
                    TITLE: string;
                };
                HOUSEKEEPING: {
                    DATA: {
                        ID: number;
                        HTML: string[] | string;
                        DETAILS: {
                            NAME: string;
                            VALUE: string;
                        }[];
                    };
                    ICON: string;
                    DESCRIPTION: string;
                    TITLE: string;
                };
                OTHER: {
                    DATA: {
                        ID: number;
                        HTML: string[] | string;
                        DETAILS: {
                            NAME: string;
                            VALUE: string;
                        }[];
                    };
                    ICON: string;
                    DESCRIPTION: string;
                    TITLE: string;
                };
            };
        };
    };
    BOOKING_ID: 0;
    ID: 0;
}>;
export const B64_PROPERTY_GUIDEBOOK: {
    PROPERTY_GUIDEBOOK_PDF: string;
};
export type PropertyGuidebook = typeof propertyGuidebook;
export type B64PropertyGuidebook = typeof B64_PROPERTY_GUIDEBOOK;
export type GuestFormInputs = typeof GUEST_FORM_INPUTS;
export type GuestPayment = typeof GUEST_PAYMENT;
export type GuestPaymentInformation = typeof GUEST_PAYMENT_INFORMATION;
export type GuestReviews = typeof GUEST_REVIEWS;
export type GuestBooking = SparseBooking | FullBooking;
export enum GuestBookingType {
    SPARSE = "sparse",
    FULL = "full"
}
export interface GuestPaymentFee {
    AMOUNT: number;
    NAME: string;
}
export interface GuestPaymentTaxes {
    BREAKDOWN: GuestPaymentFee[];
    NAME: string;
    PERCENT: number;
    TOTAL: number;
}
export type ContactTracing = {
    BOOKING_ID: string;
    GUESTS: ContactTracingGuest[];
};
export type GuestRatingQuestion = typeof GUEST_RATING_QUESTION;
export type GuestRecommendation = typeof GUEST_RECOMMENDATION;
type _Offer1 = {
    code: string;
    id: string;
};
export const guestEndpoint = "/RESTAUTH/guest/";
export const guestBookingAlertsEndpoint = "/RESTAUTH/guest/alerts/";
export const generateGuestAlertsEndpoint: (userId: number) => string;
export const guestBookingEndpoint = "/RESTAUTH/guest/booking/";
export const generateGuestBookingEndpoint: (bookingId: number, guestId: number, includeTimeline?: boolean, ownerOffer?: _Offer1, alluraOffer?: _Offer1, alluraGiftCertificate?: _Offer1, ownerGiftCertificate?: _Offer1) => string;
export const guestBookingCancelEndpoint = "/RESTAUTH/guest/booking/cancel/";
export const generateGuestBookingCancelEndpoint: (userId: number, bookingId: number) => string;
export const guestBookingEditEndpoint = "/RESTAUTH/guest/booking/edit/";
export const generateGuestBookingEditEndpoint: (userId: number, bookingId: number) => string;
export const guestCancellationPolicyEndpoint = "/RESTAUTH/guest/booking/cancellationpolicy/";
export const generateGuestCancellationPolicyEndpoint: (bookingId: number, guestId: number, isHTML?: boolean) => string;
export const guestContactTracingEndpoint = "/RESTAUTH/guest/booking/contacttracing/";
export const guestBookingDateChangeEndpoint = "RESTAUTH/guest/booking/date-change/";
export const generateGuestMakePaymentEndpoint: ({ bookingId, bookingType, guestId, isFullPayment, }: {
    bookingId: number;
    bookingType: GuestBookingType;
    guestId: number;
    isFullPayment: 0 | 1;
}) => string;
export const guestBookingPaymentDueEndpoint = "/RESTAUTH/guest/booking/paymentdue/";
export const generateGuestBookingPaymentDueEndpoint: (bookingId: number, guestId: number) => string;
export const generateGuestBookingPropertyEndpoint: (bookingId: number, guestId: number) => string;
export const guestBookingPropertyGuidebook = "/RESTAUTH/guest/booking/propertyguidebook/";
export const generateGuestPropertyGuidebookEndpoint: (bookingId: number, guestId: number) => string;
/** Returns a base64 encoded pdf */
export const generateGuestPropertyGuidebookPDFEndpoint: (bookingId: number, guestId: number) => string;
/** Returns a binary encoded pdf */
export const generateGuestPropertyGuidebookBinaryPDFEndpoint: ({ guestId, bookingId, }: {
    guestId: number;
    bookingId: number;
}) => string;
export const guestBookingReceiptEndpoint = "/RESTAUTH/guest/booking/receipt/";
export const generateGuestBookingReceiptEndpoint: (bookingId: number, userId: number) => string;
export const guestRentalAgreementSummaryEndpoint = "/RESTAUTH/guest/booking/rentalagreement/";
export const generateGuestRentalAgreementSummaryEndpoint: (bookingId: number, guestId: number) => string;
export const guestBookingReviewEndpoint = "/RESTAUTH/guest/booking/review/";
export const guestBookingReviewResponseEndpoint = "/RESTAUTH/guest/booking/review/response/";
export const generateGuestResponseEndPoint: (reviewId: number, guestId: number) => string;
export const guestBookingUnavailableDatesEndpoint = "/RESTAUTH/guest/booking/unavailability/";
export const generateGuestUnavailableDatesEndpoint: (bookingId: number, guestId: number) => string;
export const guestBookingsEndpoint = "/RESTAUTH/guest/bookings/";
export const generateGuestBookingsEndpoint: ({ amount, direction, guestId, page, statusIdFilter, }: {
    amount?: number;
    direction?: "future" | "past" | "all";
    guestId: number;
    page?: number;
    statusIdFilter?: BookingStatusId;
}) => string;
export const guestCredentialsEndpoint = "/RESTAUTH/guest/credentials/";
export const guestInquiryEndpoint = "/RESTAUTH/guest/inquiry/";
export const guestFormInputEndpoint = "/RESTAUTH/guest/formInput/";
export const generateGuestFormInputEndPoint: (guestId: number) => string;
export const guestOfferCodeEndpoint = "/RESTAUTH/guest/offer/code/";
export const generateGuestOfferCodeEndpoint: (userId: number | undefined, propertyId: string | undefined, arrival: string | undefined, departure: string | undefined) => string;
export const guestOffersEndpoint = "/RESTAUTH/guest/offers/";
export const generateGuestOffersEndpoint: (userId: number | undefined, propertyId: string | undefined, arrival: string | undefined, departure: string | undefined) => string;
export const guestLoginEndpoint = "/RESTAUTH/guest/login/";
export const guestLogoutEndpoint = "/RESTAUTH/guest/logout/";
export const generateGuestNotificationsEndpoint: ({ amountPerPage, page, guestId, category, status, }: {
    amountPerPage: number;
    page: number;
    guestId: number;
    category: NotificationEndpointFilterCategory;
    status: NotificationEndpointFilterStatus;
}) => string;
export const guestDismissNotificationsEndpoint = "/RESTAUTH/guest/notifications/dismiss/";
export const guestPrivacyEndpoint = "/RESTAUTH/guest/privacy/";
export const guestReferralEndpoint = "/RESTAUTH/guest/referral/";
export const guestReviewEndpoint = "/RESTAUTH/guest/review/";
export const generateGuestNewReviewEndpoint: (bookingId: number, reviewId: number, guestId: number) => string;
export const generateGuestReviewEndpoint: (reviewId: number, guestId: number) => string;
export const guestReviewsEndpoint = "/RESTAUTH/guest/reviews/";
export const generateGuestReviewsEndpoint: (guestId: number) => string;
export const generateGuestEligibleReviewsEndpoint: (guestId: number) => string;
export interface QueryKeys {
    all: [string];
    lists: () => [string, 'list'];
    list: (filters: string) => [string, 'list', {
        [key: string]: string;
    }];
    details: () => [string, 'detail'];
    detail: (id: string) => [string, 'detail', string];
}
export function queryKeyFactory(keyName: string): QueryKeys;
interface _Args3 {
    bookingId: number;
    guestId: number;
    includeTimeline?: boolean;
    isEnabled?: boolean;
    onSuccess?: (booking: FullBooking) => void;
    ownerOffer?: {
        code: string;
        id: string;
    };
    alluraOffer?: {
        code: string;
        id: string;
    };
    alluraGiftCertificate?: {
        code: string;
        id: string;
    };
    ownerGiftCertificate?: {
        code: string;
        id: string;
    };
}
export const guestBookingQueryKey: QueryKeys;
/** TODO - Remove the Reservation timeline from this query. It needs to be it's own endpoint.
 * It has caused too many issues since the query key is dependent on the URL.
 * We should also examine the idea of using the URL as the method to generate the query key.
 * In the case of a reservation, it is very straight forward in that I have a reservation ID that needs to
 * be used to generate the query key. The reservation ID can handle every use case for this query key as we already know
 * the query key is a GUEST_BOOKING, so we do not  need to include the guestId.
 */
export const useGuestBookingQuery: ({ bookingId, guestId, includeTimeline, isEnabled, onSuccess, alluraOffer, ownerOffer, alluraGiftCertificate, ownerGiftCertificate, }: _Args3) => UseQueryResult<FullBooking, Error>;
export const additionalContactEndpoint = "/RESTAUTH/property/emergencycontact/";
export const bookingsFilteredEndPoint = "/RESTAUTH/property/bookings/filtered/";
export const bookingsPaginatedEndPoint = "/RESTAUTH/property/bookings/paginated/";
export const calendarDatesEndpoint = "/RESTAUTH/property/calendardates/";
export const cancellationPoliciesEndpoint = "/RESTAUTH/property/cancellationpolicy/";
export const checkinEmailPreviewSendEndpoint = "/RESTAUTH/property/checkinemail/";
export const contentEndpoint = "/RESTAUTH/property/content/";
export const directVacationLogoEndpoint = "/RESTAUTH/property/directvacationslogo/";
export const directVacationSubdomainEndpoint = "/RESTAUTH/property/directvacationssubdomain/";
export const externalUrlsEndpoint = "/RESTAUTH/property/externalurls/";
export const formEndpoint = "/RESTAUTH/property/forminput/";
export const instructionsEndpoint = "/RESTAUTH/property/instructions/";
export const photoSortEndpoint = "/RESTAUTH/property/photo/sort/";
export const photosEndpoint = "/RESTAUTH/property/photo/";
export const propertyAmenityEndpoint = "/RESTAUTH/property/amenity/";
export const propertyBlockoffEndpoint = "/RESTAUTH/property/blockoff/";
export const propertyDefaultContentEndpoint = "/RESTAUTH/property/defaultcontent/";
export const propertyWalkthroughGuidebookEndpoint = "/RESTAUTH/property/walkthrough/propertyguidebook/";
export const propertyICalEndpoint = "/RESTAUTH/property/ical/";
export const propertyNonResidentEmail = "/RESTAUTH/property/nonresidentsubscription/";
export const propertyPoliciesEndpoint = "/RESTAUTH/property/policies/";
export const propertyRateGroupEndpoint = "/RESTAUTH/property/rategroup/";
export const propertyRatesScheduleGenerateEndpoint = "/RESTAUTH/property/rateschedule/generate/";
export const propertyTransactionsEndpoint = "/RESTAUTH/property/transactions/";
export const propertyVideosEndpoint = "/RESTAUTH/property/video/";
export const rateScheduleEndpoint = "/RESTAUTH/property/rateschedule/";
export const rentalAgreementSummaryEndpoint = "/RESTAUTH/property/rentalagreement/";
export const resendSubscriptionReceiptEndPoint = "/RESTAUTH/property/resendreceipt/";
export const reservationRequestEndpoint = "/RESTAUTH/property/reservationrequest/";
export const reservationSettings = "/RESTAUTH/property/reservationsettings/";
export const subformEndpoint = "/RESTAUTH/property/subform/";
export const generateBookingsFilteredEndpoint: ({ propertyId, startDate, endDate, status, sort, source, }: {
    propertyId: number;
    startDate: string;
    endDate: string;
    status: any;
    sort: any;
    source: any;
}) => string;
export const generatePropertyGuidebookEndpoint: (propertyId: number) => string;
export const generatePropertyGuidebookPDFEndpoint: (propertyId: number) => string;
export const generateLegacyCheckInHTML: (propertyId: number) => string;
export const generateBookingReservationEndpoint: (bookingId: number, includeTimeline?: boolean) => string;
/** Extend or Replace Rate Schedule using rate group data */
export const generateRateScheduleRateGroup: ({ propertyId, num_months, start_date, is_replace, }: {
    propertyId: number;
    num_months: number;
    start_date: string;
    is_replace?: boolean;
}) => string;
/** Extend or Replace Rate Schedule using pricing insight data */
export const generateRateScheduleInsight: ({ propertyId, num_months, start_date, rate_insights_level_id, is_preview, is_replace, }: {
    propertyId: number;
    num_months: number;
    start_date: string;
    rate_insights_level_id: RateInsightLevelIdEnum;
    is_preview?: boolean;
    is_replace?: boolean;
}) => string;
/** generate a property rate schedule with AirDNA daily insights, using existing date ranges
 * PUT
 */
export const rateScheduleOptimizeEndpoint = "/RESTAUTH/property/rateschedule/generate/optimize/";
export const generatePropertyCodesEndpoint: (propertyId: number) => string;
export const generatePropertyRatesScheduleGenerateEndpoint: ({ propertyId, mode, }: {
    propertyId: number;
    mode: GenerateRateMode;
}) => string;
export const generatePhotosEndPoint: (propertyId: number) => string;
export const generateFormInputEndpoint: (propertyId: number) => string;
export const generateBookingsPaginatedEndPoint: ({ amount, direction, page, status_id, propertyId, }: {
    amount: number;
    direction: "past" | "future" | "all";
    propertyId: number;
    /** This value must always be greater than 0 */
    page: number;
    status_id?: BookingStatusId | undefined;
}) => string;
export const generateExternalEventsEndPoint: (propertyId: number) => string;
export const generateResyncICalEndPoint: (propertyId: number) => string;
export const generatePropertyEndPoint: (propertyId: number) => string;
export const generatePropertyEndPointQuery: (propertyId: number) => string;
export const generatePropertyNotificationsEndPoint: ({ amountPerPage, status, category, propertyId, page, }: {
    amountPerPage: number;
    status: NotificationEndpointFilterStatus;
    category: NotificationEndpointFilterCategory;
    propertyId: number;
    page: number;
}) => string;
export const propertyDismissNotificationsEndpoint = "/RESTAUTH/property/notifications/dismiss/";
export const generatePropertyDismissNotificationEndpoint: (propertyId: number, notificationIds: number[] | "all") => string;
export const generateReviewsEndPoint: ({ propertyId, page, amountPerPage, pageDirection, }: {
    propertyId: number;
    page: number;
    amountPerPage: number;
    pageDirection: InfiniteQueryPageDirections;
}) => string;
export const generateActivationEndPoint: (propertyId: number) => string;
export const generateUnavailabilityEndpoint: ({ bookingId, propertyId, }: {
    bookingId?: number | null;
    propertyId: number;
}) => string;
export const generateLastAndNextGuestEndpoint: (propertyId: number) => string;
export const generateBankDepositsEndPoint: (propertyId: number) => string;
export const generatePropertyDefaultContentEndpoint: (propertyId: number, contentType: PropertyDefaultContentTypes) => string;
export const generateExternalUrlsEndpoint: (propertyId: number) => string;
export const generateCheckInEmailPreviewEndpoint: ({ propertyId }: {
    propertyId: number;
}) => string;
export const generateRentalAgreementSummaryEndpoint: (propertyId: number) => string;
export const generateCalendarEventsEndpoint: ({ propertyId, startDate, endDate, }: {
    propertyId: number;
    startDate: string;
    endDate: string;
}) => string;
export const generateCalendarDatesEndpoint: ({ propertyId, startDate, endDate, }: {
    propertyId: number;
    startDate: string;
    endDate: string;
}) => string;
export const generateReservationRequest: (propertyId: number) => string;
export const generateRateSuggestionEndpoint: ({ propertyId }: {
    propertyId: number;
}) => string;
export const generatePropertyBlockoffsEndpoint: (propertyId: number) => string;
interface _Args4 {
    bookingId: number;
    isEnabled?: boolean;
    onSuccess?: (booking: FullBooking) => void;
    onError?: () => void;
    includeTimeline?: boolean;
}
export const propertyBookingQueryKey: QueryKeys;
export const usePropertyBookingQuery: ({ isEnabled, bookingId, includeTimeline, onSuccess, onError, }: _Args4) => UseQueryResult<FullBooking, Error>;
interface _Args5 {
    isOwnerRole: boolean;
    isGuestRole: boolean;
    bookingId: number;
    guestId?: number;
    isEnabled?: boolean;
    onSuccess?: (booking: FullBooking) => void;
    includeTimeline?: boolean;
    ownerOffer?: {
        code: string;
        id: string;
    };
    alluraOffer?: {
        code: string;
        id: string;
    };
    alluraGiftCertificate?: {
        code: string;
        id: string;
    };
    ownerGiftCertificate?: {
        code: string;
        id: string;
    };
}
export const useBookingQuery: ({ bookingId, isOwnerRole, isGuestRole, guestId, isEnabled, onSuccess, includeTimeline, ownerOffer, alluraOffer, alluraGiftCertificate, ownerGiftCertificate, }: _Args5) => UseQueryResult<FullBooking, Error>;
interface _Args6 {
    direction?: 'future' | 'past' | 'all';
    statusId?: BookingStatusId;
    enabled?: boolean;
    guestId: number;
}
/** For use in the useGuestBookingsQuery hook (not the infinite query) */
export const guestBookingsQueryKeys: QueryKeys;
export const useGuestBookingsQuery: ({ direction, statusId, enabled, guestId, }: _Args6) => UseQueryResult<{
    CUSTOM_MESSAGE: {
        MESSAGE: string;
        ENTRY_CODE: string;
    };
    DATES: {
        ARRIVAL: string;
        BOOKING: string;
        BOOKING_TIME: string;
        CHECK_IN_SENT: string;
        DEPARTURE: string;
        SERVER_TIMESTAMP: string;
    };
    FLAGS: {
        IS_PAST_DUE: boolean;
    };
    GUEST: {
        AGE: string;
        EMAIL: string;
        FIRST_NAME: string;
        GUEST_PROFILE: {
            MEMBER_SINCE: string;
            PERMISSIONS: {
                SHOW_NUM_REVIEWS: boolean;
                SHOW_MEMBER_SINCE: boolean;
                SHOW_NUM_RECOMMENDS: boolean;
            };
            NUM_BOOKINGS: number;
            NUM_RECOMMENDATIONS: number;
            NUM_REVIEWS: number;
        };
        ID: number;
        IS_AGE_VERIFIED: boolean;
        IS_EMAIL_VERIFIED: boolean;
        IS_SMS_VERIFIED: boolean;
        LAST_NAME: string;
        PHONE: string;
        THUMBNAIL: string;
    };
    GUEST_COMMENT: string;
    GUEST_REQUESTS: string;
    ID: number;
    NIGHTS: number;
    NIGHTLY_RATES: {
        DATE: string;
        DAY: string;
        RATE: string;
        BASE_RATE: string;
        LOS_DISCOUNT: string;
        OFFER_DISCOUNT: string;
    }[];
    NOTES_OWNER: string;
    PARTY_SIZE: {
        ADULTS: number;
        KIDS: number;
    };
    PAYMENT: {
        AMOUNT_OUTSTANDING: string;
        AMOUNT_REFUNDED: string;
        BALANCE: {
            DUE_DATE: string;
            PAYMENT_DATE: string;
            TOTAL: string;
        };
        BOOKING_NET: string;
        DAMAGE_DEPOSIT: {
            MODE: string;
            MODE_ID: _DamageDepositModeId1;
        };
        DEPOSIT: {
            DUE_DATE: string;
            PAYMENT_DATE: string;
            TOTAL: string;
        };
        NEXT_PAYMENT: {
            DUE_DATE: string;
            IS_PAST_DUE: boolean;
            NAME: string;
            TOTAL: string;
        };
        PAID_TO_DATE: string;
    };
    PAYMENT_INFORMATION: {
        ACCOMMODATION_SUBTOTAL: string;
        ALLURA_OFFER_DISCOUNT: string;
        BOOKING_NET_BASE_RATE: string;
        BOOKING_NET_BASE_RATE_MINUS_LOS: string;
        LENGTH_OF_STAY_DISCOUNT: string;
        OWNER_OFFER_DISCOUNT: string;
    };
    PROPERTY: {
        RULES: {
            CHECK_IN: string;
            CHECK_OUT: string;
            MAX_GUESTS: string;
            MIN_AGE_TO_BOOK: number;
            MAX_BOOKABLE_DAYS: number;
            QUIET_TIME: number;
        };
        ADDRESS: {
            UNIT: string;
            RESORT: string;
            DEVELOPMENT: string;
            STREET_NAME: string;
            STREET_NUMBER: string;
        };
        JOIN_STATUS: {
            STATUS_ID: _JoinStatusIDEnum1;
        };
        ID: number;
        THUMBNAIL_URL: string;
        ACCESS_TO_UNIT: {
            CODE: {
                NAME: string;
                ID: _AccessCodeIdEnum1;
            };
            METHOD: {
                NAME: string;
                ID: _AccessMethodIdEnum1;
            };
            STANDARD_CODE: string;
            TYPE: {
                NAME: string;
                ID: _AccessCodeTypeIDEnum1;
            };
        };
        CODES: {
            BIKE_LOCKER_CODE: string;
            DEVELOPMENT_DOOR_CODE: string;
            DEVELOPMENT_GYM_CODE: string;
            DEVELOPMENT_HOT_TUB_CODE: string;
            DEVELOPMENT_POOL_CODE: string;
            DEVELOPMENT_SAUNA_CODE: string;
            DEVELOPMENT_STEAM_ROOM_CODE: string;
            FRONT_DOOR_CODE: string;
            GAMES_REC_ROOM_CODE: string;
            GARAGE_DOOR_CODE: string;
            GARBAGE_RECYCLING_CODE: string;
            ID: number;
            INTERNET_NETWORK_NAME: string;
            INTERNET_PASSWORD: string;
            PHONE_NUMBER: string;
            PROPERTY_ID: string;
            SKI_LOCKER_CODE: string;
            DATE_LAST_UPDATED: string;
        };
        PRIMARY_CONTACT: _EmergencyContact1 & {
            THUMBNAIL_URL: string;
        };
    };
    REFERENCE: string;
    REVIEW: {
        ID: number;
    };
    SOURCE: string;
    STATUS: {
        ID: BookingStatusId;
        NAME: string;
    };
    STATUSES: {
        DATE: string;
        IS_DONE: boolean;
        LABEL: string;
    }[];
    SURCHARGES: {
        NET: string;
        TAXES_TOTAL: string;
    };
    TAX: {
        TOTAL: string;
    };
    TOTAL: string;
}[], Error>;
export const guestPaymentDueQueryKey: QueryKeys;
export const useGuestPaymentDueQuery: ({ bookingId, guestId, isEnabled, }: {
    bookingId: number;
    guestId: number;
    isEnabled: boolean;
}) => UseQueryResult<{
    ID: number;
    PAYMENT_DUE: {
        BOOKING: {
            AMOUNT_DUE: number;
            ARRIVAL: string;
            BOOKING_NET: number;
            BOOKING_TOTAL: number;
            DAMAGE_DEPOSIT: number;
            DEPARTURE: string;
            ID: number;
            NIGHTLY_RATE: number;
            NIGHTS: number;
            PAID_TO_DATE: number;
            PARTY_SIZE: number;
            TAXES_AND_FEES_TOTAL: number;
        };
        FEES: GuestPaymentFee[];
        TAXES: GuestPaymentTaxes[];
    };
}, Error>;
export const rentalAgreementSummaryQueryKey: QueryKeys;
export const useRentalAgreementSummaryQuery: ({ enabled, bookingId, guestId, }: {
    enabled?: boolean;
    bookingId: number;
    guestId: number;
}) => UseQueryResult<string, Error>;
export function arrayMove<T>(arr: T[], oldIndex: number, newIndex: number): T[];
export function createEmptyArray(length: number): any[];
/** https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/flat
 *
 * Flattens the array with a depth of 1. Use this instead of .flat for browser compatability
 * https://caniuse.com/array-flat
 * */
export function flattenArray<T = any>(arr: T[]): any[];
export const encodeParams: (params: {
    [key: string]: unknown;
}) => string;
export const generateFormData: (params: {
    [key: string]: unknown | [];
}) => FormData;
export const generateBodyParams: (params: any) => URLSearchParams;
/** In React Native UrlSearchParams will not work. We use FormData instead */
export const generateFormDataBodyParams: (params: any) => FormData;
export const generateURLParams: (params: any) => string;
export const generateParamsString: (params: any) => string;
export function flattenApiPages(data: any, key: string): any[];
export type BookingQuoteResponse = APIKeyResponse<FullBooking, 'BOOKING'>;
export const generateBookingQuoteEndpoint: (quoteParams: CreateBookingBody | Pick<CreateBookingBody, "ARRIVAL" | "NIGHTS" | "PROPERTY_ID">) => string;
type CreateRateQuote = Pick<CreateBookingBody, 'ARRIVAL' | 'NIGHTS' | 'PROPERTY_ID'>;
type EditRateQuote = Pick<EditBookingBody, 'ARRIVAL' | 'NIGHTS' | 'PROPERTY_ID' | 'ID'>;
type _QuoteParams1 = CreateBookingBody | EditBookingBody | CreateRateQuote | EditRateQuote;
export const generateBookingQuoteQueryKeyDetail: (quoteParams: _QuoteParams1) => [string, "detail", string];
export const bookingQuoteQueryKey: QueryKeys;
interface _Args7 {
    quoteParams: _QuoteParams1;
    isEnabled: boolean;
    onSuccess?: (response: any) => void;
    onError?: (error: any) => void;
    onSettled?: () => void;
}
export const useBookingQuoteQuery: ({ quoteParams, isEnabled, onSuccess, onError, onSettled, }: _Args7) => UseQueryResult<BookingQuoteResponse, Error>;
export const useBookingCancellationQuery: ({ bookingId }: {
    bookingId: number | string;
}) => UseQueryResult<APIKeyResponse<CancellationDetails, "CANCELLATION_DETAILS">, Error>;
export const generateCreditsOverviewEndpoint: (userId: number) => string;
export const CREDITS_OVERVIEW: {
    total_credits: string;
    pending_credits: string;
    remaining_credits: string;
    credit_expiry_date: string;
    refer_guest_link: string;
    refer_owner_link: string;
    offer_amounts: {
        user_referred_owner: string;
        user_referred_guest: string;
        guest_referred_by_user: string;
        owner_referred_by_user: string;
    };
    credit_history: {
        id: number;
        amount_total: string;
        amount_remaining: string;
        sender: {
            id: number;
            first_name: string;
            last_name: string;
            company_name: string;
            is_company: boolean;
            email: string;
        };
        status: {
            status: string;
            id: CreditStatusEnum;
        };
        reason_given: {
            reason: string;
            id: CreditReasonGivenEnum;
        };
        detail: string;
        expiry_date: string;
        created_at: string;
    }[];
};
export type CreditsOverview = typeof CREDITS_OVERVIEW;
export enum CreditStatusEnum {
    PENDING = 1,
    APPROVED = 2,
    CANCELLED = 3,
    SPENT = 4
}
export enum CreditReasonGivenEnum {
    OWNER_RECOMMENDATION = 1,
    GUEST_RECOMMENDATION = 2,
    ALLURA_CREDIT = 3
}
interface _Args8 {
    userId: number;
}
export const useGetCreditsOverviewQuery: ({ userId, ...rest }: _Args8 & ConfigurableAppQueryArgs) => UseQueryResult<APIResponse<{
    total_credits: string;
    pending_credits: string;
    remaining_credits: string;
    credit_expiry_date: string;
    refer_guest_link: string;
    refer_owner_link: string;
    offer_amounts: {
        user_referred_owner: string;
        user_referred_guest: string;
        guest_referred_by_user: string;
        owner_referred_by_user: string;
    };
    credit_history: {
        id: number;
        amount_total: string;
        amount_remaining: string;
        sender: {
            id: number;
            first_name: string;
            last_name: string;
            company_name: string;
            is_company: boolean;
            email: string;
        };
        status: {
            status: string;
            id: CreditStatusEnum;
        };
        reason_given: {
            reason: string;
            id: CreditReasonGivenEnum;
        };
        detail: string;
        expiry_date: string;
        created_at: string;
    }[];
}>, Error>;
interface BaseArgs {
    queryKey: string | any[];
    urlFn: (pageParam: number) => string;
    initialPageParam: number;
    amountPerPage: number;
    enabled?: boolean;
    refetchOnWindowFocus?: boolean;
    refetchInterval?: number | false;
    staleTime?: number;
    cacheTime?: number;
    useErrorBoundary?: boolean;
    onSuccess?: (data: any) => void;
    onError?: (error: any, variables?: any, context?: void) => void;
    onSettled?: (data: any, error?: unknown) => void;
}
interface NextPageArgs extends BaseArgs {
    /** Returns initialPageParam if lastPage is undefined,
     *
     * Returns undefined if last page had less than total expected amountPerPage (ran out of data to query),
     *
     * Returns pages.length + 1 otherwise (or equivalent next page value)
     * */
    nextPageFn: (lastPage: any, pages: any[]) => number | undefined;
}
interface DefaultNextPageArgs extends BaseArgs {
    nextPageKey: string;
    defaultSelect?: boolean;
}
export type AppInfiniteQueryArgs = NextPageArgs | DefaultNextPageArgs;
export type ConfigurableAppInfiniteQueryArgs = Omit<AppInfiniteQueryArgs, 'nextPageFn' | 'nextPageKey' | 'defaultSelect' | 'queryKey' | 'urlFn' | 'initialPageParam' | 'amountPerPage'>;
export type PageDirection = 'past' | 'future' | 'all';
export const useAppInfiniteQuery: <TReturnValues = any>(args: AppInfiniteQueryArgs & UseInfiniteQueryOptions<any, any, any, any, any>) => UseInfiniteQueryResult<InfiniteData<any, unknown>, any>;
interface _Args9 {
    guestId: number;
    direction: PageDirection;
    amountPerPage?: number;
    statusIdFilter?: BookingStatusId;
    enabled?: boolean;
    refetchInterval?: number;
}
export const guestBookingsInfiniteQueryKeys: QueryKeys;
export const useGuestBookingsInfiniteQuery: ({ guestId, amountPerPage, enabled, refetchInterval, statusIdFilter, direction, }: _Args9) => UseInfiniteQueryResult<_InfiniteData1<any, unknown>, any>;
interface _Args10 {
    guestId: number;
    category: NotificationEndpointFilterCategory;
    status: NotificationEndpointFilterStatus;
    refetchInterval?: number;
    enabled?: boolean;
}
export const useGuestNotificationsQueryKeys: QueryKeys;
export const useGuestNotificationsInfiniteQuery: ({ guestId, category, status, enabled, refetchInterval, }: _Args10) => UseInfiniteQueryResult<_InfiniteData1<any, unknown>, any>;
interface _Values1 {
    /** Guest Id */
    id: number;
    notification_ids: number[] | 'all';
}
export const useGuestDismissNotificationsMutation: (args: ConfigurableAppMutationArgs) => UseMutationResult<any, Error, _Values1, void>;
/** This will return the entire Cancellation Policy Object. To use the HTML
 version, use useGuestCancellationPolicyHTML
 */
export const useGuestBookingCancellationPolicyObject: (bookingId: number, guestId: number) => UseQueryResult<{
    ADMIN_PENALTY: number;
    ADMIN_PENALTY_UNIT: string;
    BOOKING_GRACE_PERIOD: string;
    DATE_ACTIVATED: string;
    DATE_LAST_UPDATED: string;
    DATE_RANGES: {
        DATE_ACTIVATED: string;
        DESCRIPTION: string;
        FROM_DAYS: string;
        ID: number;
        LABEL: string;
        REFUND_PERCENTAGE: string;
        TO_DAYS: string;
    }[];
    DESCRIPTION: string;
    ID: number;
    IS_CREDIT_ONLY_REFUND: boolean;
    IS_REFUND_REBOOKED_DATES: boolean;
    IS_SPECIAL_CIRCUMSTANCE: boolean;
    NAME: string;
    POLICY_ID: number;
    SERVICE_FEE_REFUND: string;
    SPECIAL_CIRCUMSTANCE_DESCRIPTION: string;
    SPECIAL_CIRCUMSTANCE_ID: number;
    SPECIAL_CIRCUMSTANCE_NAME: string;
    SURCHARGE_REFUND: string;
}, Error>;
/** This will return the entire Cancellation Policy HTML. To use the Object
 version, use useGuestCancellationPolicyObject
 */
export const useGuestBookingCancellationPolicyHTML: (bookingId: number, guestId: number) => UseQueryResult<string, Error>;
export const guestPropertyQueryKey: QueryKeys;
export const useGuestPropertyQuery: ({ bookingId, guestId, isEnabled, }: {
    bookingId: number;
    guestId: number;
    isEnabled: boolean;
}) => UseQueryResult<{
    ID: number;
    ACCESS_TO_UNIT: {
        CODE: {
            NAME: string;
            ID: _AccessCodeIdEnum1;
        };
        METHOD: {
            NAME: string;
            ID: _AccessMethodIdEnum1;
        };
        STANDARD_CODE: string;
        TYPE: {
            NAME: string;
            ID: _AccessCodeTypeIDEnum1;
        };
    };
    ADDRESS: {
        AREA: string;
        AREA_ID: number;
        CITY: string;
        COUNTRY: string;
        COUNTRY_CODE: string;
        COUNTRY_ID: number;
        DEVELOPMENT: string;
        DEVELOPMENT_ID: number;
        ID: number;
        LATITUDE: number;
        LONGITUDE: number;
        POSTAL: string;
        REGION: string;
        REGION_ID: number;
        RESORT: string;
        RESORT_ID: number;
        STREET_NAME: string;
        STREET_NUMBER: string;
        UNIT: string;
    };
    AMENITIES: {
        BUILDING: {
            TYPE: string;
            LIST: _Amenity1[];
        };
        ESSENTIAL: {
            TYPE: string;
            LIST: _Amenity1[];
        };
        KITCHEN: {
            TYPE: string;
            LIST: _Amenity1[];
        };
        PRIVATE: {
            TYPE: string;
            LIST: _Amenity1[];
        };
        SAFETY: {
            TYPE: string;
            LIST: _Amenity1[];
        };
    };
    BANKING: {
        ACCOUNTHOLDER: {
            ADDRESS: {
                AREA: string;
                AREA_ID: number;
                CITY: string;
                COUNTRY: string;
                COUNTRY_CODE: string;
                COUNTRY_ID: number;
                DEVELOPMENT: string;
                DEVELOPMENT_ID: number;
                ID: number;
                LATITUDE: number;
                LONGITUDE: number;
                POSTAL: string;
                REGION: string;
                REGION_ID: number;
                RESORT: string;
                RESORT_ID: number;
                STREET_NAME: string;
                STREET_NUMBER: string;
                UNIT: string;
            };
            COMPANY_NAME: string;
            FIRST_NAME: string;
            IS_COMPANY: boolean;
            LAST_NAME: string;
        };
        BANK: {
            ACCOUNT_NUMBER: string;
            INSTITUTION: string;
            NAME: string;
            TRANSIT: string;
            ID: number;
        };
    };
    BATHROOMS: Bathroom[];
    BEDROOMS: Bedroom[];
    BLOCKOFFS: never[];
    CANCELLATION_POLICY: {
        ADMIN_PENALTY: number;
        ADMIN_PENALTY_UNIT: string;
        BOOKING_GRACE_PERIOD: string;
        DATE_ACTIVATED: string;
        DATE_LAST_UPDATED: string;
        DATE_RANGES: {
            DATE_ACTIVATED: string;
            DESCRIPTION: string;
            FROM_DAYS: string;
            ID: number;
            LABEL: string;
            REFUND_PERCENTAGE: string;
            TO_DAYS: string;
        }[];
        DESCRIPTION: string;
        ID: number;
        IS_CREDIT_ONLY_REFUND: boolean;
        IS_REFUND_REBOOKED_DATES: boolean;
        IS_SPECIAL_CIRCUMSTANCE: boolean;
        NAME: string;
        POLICY_ID: number;
        SERVICE_FEE_REFUND: string;
        SPECIAL_CIRCUMSTANCE_DESCRIPTION: string;
        SPECIAL_CIRCUMSTANCE_ID: number;
        SPECIAL_CIRCUMSTANCE_NAME: string;
        SURCHARGE_REFUND: string;
    };
    CLEANING_PROTOCOL: {
        HAS_AUTOMATIC_BUFFER_DAYS: boolean;
        IS_APPLY_TO_EXISTING_BOOKINGS: boolean;
        NUMBER_OF_BLOCKOFF_DAYS: number;
    };
    CODES: {
        BIKE_LOCKER_CODE: string;
        DEVELOPMENT_DOOR_CODE: string;
        DEVELOPMENT_GYM_CODE: string;
        DEVELOPMENT_HOT_TUB_CODE: string;
        DEVELOPMENT_POOL_CODE: string;
        DEVELOPMENT_SAUNA_CODE: string;
        DEVELOPMENT_STEAM_ROOM_CODE: string;
        FRONT_DOOR_CODE: string;
        GAMES_REC_ROOM_CODE: string;
        GARAGE_DOOR_CODE: string;
        GARBAGE_RECYCLING_CODE: string;
        ID: number;
        INTERNET_NETWORK_NAME: string;
        INTERNET_PASSWORD: string;
        PHONE_NUMBER: string;
        PROPERTY_ID: string;
        SKI_LOCKER_CODE: string;
        DATE_LAST_UPDATED: string;
    };
    CO_HOST: {
        COHOST_PROFILE: {
            PERMISSIONS: Omit<_PropertyPermission1, "PROPERTY_ID">;
            PROPERTY_IDS: never[];
        };
        ID: number;
        FIRST_NAME: string;
        LAST_NAME: string;
        IS_COMPANY: boolean;
        COMPANY_NAME: string;
        THUMBNAIL: string;
        PHONE: string;
        EMAIL: string;
        CREATED_DATE: string;
        DATE_LAST_LOGIN: string;
        DATE_UPDATED: string;
        ADDRESS: {
            AREA: string;
            AREA_ID: number;
            CITY: string;
            COUNTRY: string;
            COUNTRY_CODE: string;
            COUNTRY_ID: number;
            DEVELOPMENT: string;
            DEVELOPMENT_ID: number;
            ID: number;
            LATITUDE: number;
            LONGITUDE: number;
            POSTAL: string;
            REGION: string;
            REGION_ID: number;
            RESORT: string;
            RESORT_ID: number;
            STREET_NAME: string;
            STREET_NUMBER: string;
            UNIT: string;
        };
        IS_SMS_VERIFIED: boolean;
        IS_EMAIL_VERIFIED: boolean;
        DATE_EMAIL_VERIFIED: string;
        DATE_SMS_VERIFIED: string;
        DATE_OF_BIRTH: string;
        IS_ACTIVE: boolean;
        IS_STAFF: boolean;
        IS_SUPERUSER: boolean;
        IS_DUE_DILIGENCE_REQUIRED: boolean;
    };
    CONTENT: {
        ABOUT_THE_BUILDING: string;
        DESCRIPTION: string;
        KITCHEN: string;
        LOCATION: string;
        SUMMARY: string;
        TITLE: string;
    };
    DAMAGE_DEPOSIT: {
        AMOUNT: string;
        TYPE: {
            ID: _DamageDepositModeId1;
            NAME: string;
        };
    };
    DAYS_TO_EXPIRY: number;
    DIRECT_VACATIONS: {
        ID: number;
        IS_ACTIVE: boolean;
        LOGO: string;
        NAME: string;
        URL: string;
    };
    EMERGENCY_CONTACTS: {
        PRIMARY: EmergencyContact;
        OTHERS: EmergencyContact[];
    };
    EXTERNAL_URLS: {
        URL_AIRBNB: string;
        URL_OTHER: string;
        URL_VRBO: string;
    };
    ICALS: {
        HAS_ICALS: boolean;
        PRIMARY: {
            ALLURA_URL: string;
            AVAILABILITY_WINDOW: number;
            IS_AVAILABILITY_WINDOW: boolean;
            IS_BLOCK_RATELESS: boolean;
        };
        SECONDARY: {
            ALLURA_URL: string;
            AVAILABILITY_WINDOW: number;
            IS_ACTIVE: boolean;
            IS_AVAILABILITY_WINDOW: boolean;
            IS_BLOCK_RATELESS: boolean;
        };
        EXTERNAL: {
            ID: number;
            LISTING_URL: string;
            NAME: string;
            URL: string;
        }[];
    };
    INSTRUCTIONS: {
        ABOUT_THE_BUILDING: string;
        ACTIVITIES: string;
        BUILDING_COMMON_AREAS: string;
        CHECK_IN: string;
        CHECK_OUT: string;
        EMERGENCY_CONTACTS: string;
        FRONT_DESK: string;
        GARBAGE_RECYCLING: string;
        GETTING_AROUND: string;
        GETTING_TO_UNIT: string;
        HEATING: string;
        HOUSEKEEPING: string;
        ID: number;
        INFANT_SUPPLIES: string;
        KITCHEN: string;
        LATE_CHECK_IN: string;
        LINENS_AND_TOWELS: string;
        OTHER: string;
        PARKING: string;
        RESTAURANTS: string;
        SERVICES: string;
        SKI_IN_SKI_OUT: string;
        TO_FROM_LIFTS: string;
        WELCOME: string;
        WHAT_TO_BRING: string;
    };
    IS_ALLURA_RATES: boolean;
    IS_CO_HOST_MANAGER_ENABLED: string;
    IS_ENABLED: boolean;
    IS_SKI_IN_SKI_OUT: boolean;
    JOIN_STATUS: {
        COMPLETION_PERCENTAGE_REQUIRED: number;
        COMPLETION_PERCENTAGE_OPTIONAL: number;
        DATES: {
            CREATED: string;
            LAST_UPDATED: string;
            ACTIVATED: string;
            ACTIVATION_REQUEST: string;
        };
        HAS_COMPLETED_ONBOARDING: boolean;
        STATUS: string;
        STATUS_ID: JoinStatusIDEnum;
        SUBFORMS_COMPLETED: _RequiredSubformsEnum1[];
        SUBFORMS_OPTIONAL_COMPLETED: _OptionalSubformsEnum1[];
    };
    LISTING_QUALITY: {
        MESSAGE: string;
        RATES_AVAILABILITY: {
            MESSAGE: string;
            PROPERTY_COUNT: number;
            RECOMMENDED_COUNT: number;
            SCORE: number;
        };
        PROPERTY_GUIDEBOOK: {
            MESSAGE: string;
            PROPERTY_COUNT: number;
            RECOMMENDED_COUNT: number;
            SCORE: number;
        };
        STAR_RATING: number;
        PHOTOS: {
            MESSAGE: string;
            PROPERTY_COUNT: number;
            RECOMMENDED_COUNT: number;
            SCORE: number;
        };
    };
    NAME: string;
    NON_RESIDENT: {
        ITN_INFO: {
            ID: number;
            ITN: number;
            PERCENTAGE_OWNERSHIP: number;
            DOB: string;
            FIRST_NAME: string;
            LAST_NAME: string;
        }[];
        IS_NON_RESIDENT: boolean;
        WITHHOLDING_PERCENTAGE: number;
    };
    OFFERS: {
        IS_NEW_LISTING_OFFER_ENABLED: boolean;
        IS_NEW_LISTING_OFFER_BLACKOUT_ENABLED: boolean;
    };
    OWNER: _WithRequiredProperty1<_User1, "OWNER_PROFILE">;
    PARKING: {
        DESCRIPTION: string;
        HAS_ADDITIONAL_FREE_SPOTS: string;
        HAS_ADDITIONAL_PAID_SPOTS: string;
        INSTRUCTIONS: string;
        IS_DEFAULT_DESCRIPTION: boolean;
        NUM_SPOTS_PROVIDED: string;
    };
    PARTNERS: never[];
    PHOTOS: Photo[];
    POLICIES: {
        ACCOUNT: Policy[];
        GENERAL: Policy[];
        GUEST_STAY: Policy[];
        HOUSE_RULES: Policy[];
        PROPERTY: Policy[];
        RESERVATION: Policy[];
    };
    PRIMARY_CONTACT: _User1;
    PROPERTY_CONTACT: {
        PROPERTY_MANAGER_PROFILE: {
            PERMISSIONS: Omit<_PropertyPermission1, "PROPERTY_ID">;
            PROPERTY_IDS: never[];
        };
        ID: number;
        FIRST_NAME: string;
        LAST_NAME: string;
        IS_COMPANY: boolean;
        COMPANY_NAME: string;
        THUMBNAIL: string;
        PHONE: string;
        EMAIL: string;
        CREATED_DATE: string;
        DATE_LAST_LOGIN: string;
        DATE_UPDATED: string;
        ADDRESS: {
            AREA: string;
            AREA_ID: number;
            CITY: string;
            COUNTRY: string;
            COUNTRY_CODE: string;
            COUNTRY_ID: number;
            DEVELOPMENT: string;
            DEVELOPMENT_ID: number;
            ID: number;
            LATITUDE: number;
            LONGITUDE: number;
            POSTAL: string;
            REGION: string;
            REGION_ID: number;
            RESORT: string;
            RESORT_ID: number;
            STREET_NAME: string;
            STREET_NUMBER: string;
            UNIT: string;
        };
        IS_SMS_VERIFIED: boolean;
        IS_EMAIL_VERIFIED: boolean;
        DATE_EMAIL_VERIFIED: string;
        DATE_SMS_VERIFIED: string;
        DATE_OF_BIRTH: string;
        IS_ACTIVE: boolean;
        IS_STAFF: boolean;
        IS_SUPERUSER: boolean;
        IS_DUE_DILIGENCE_REQUIRED: boolean;
    };
    RATES_SCHEDULE: ServerRateSchedule[];
    RATES_SETTINGS: {
        IS_AVAILABILITY_AUTOMATION_ENABLED: boolean;
        HAS_RATE_INSIGHTS_DATA: boolean;
        IS_OPTIMIZED_PRICING_ENABLED: boolean;
        NO_RATES_DATES: NoRatesDate[];
        PRICING_STRATEGY: {
            ID: PricingStrategyEnum;
            RATE_INSIGHTS_LEVEL_ID: RateInsightLevelIdEnum;
        };
        WEEKEND_PREMIUM: {
            ID: RatesSettingsWeekendPremiumId;
            DOLLAR_AMOUNT: number;
            PERCENTAGE_AMOUNT: number;
        };
        AVAILABILITY_WINDOW: {
            ID: RateAvailabilityIdEnum;
        };
        DATE_LAST_SAVED: string;
        RATE_GROUPS: {
            HIGH: RateGroup;
            LOW: RateGroup;
            PRIME: RateGroup;
            MID: RateGroup;
        };
        DISCOUNT_GROUP: {
            TEN_DAY: number;
            SEVEN_DAY: number;
            FIVE_DAY: number;
            ID: number;
        };
        ID: number;
    };
    RESERVATION_SETTINGS: {
        DEPOSIT_PERCENTAGE: number;
        BALANCE_DAYS_BEFORE_ARRIVAL: number;
        BOOKING_GATEWAY_MODE_ID: number;
    };
    RULES: {
        ID: number;
        ADVANCED_BOOKING: {
            NAME: string;
            ID: number;
        };
        CHECK_IN: string;
        CHECK_OUT: string;
        MAX_BOOKABLE_DAYS: number;
        MAX_GUESTS: number;
        MIN_AGE_TO_BOOK: number;
        QUIET_TIME: string;
    };
    SETUP_QUESTIONS: {
        NUM_PROPERTIES: number;
        PLATFORMS_LISTED: {
            ID: number;
            URL: string;
        }[];
        ID: number;
    };
    SIZE_CATEGORY: {
        NAME: string;
        ID: number;
    };
    SQUARE_FEET: string;
    STYLE: {
        NAME: string;
        ID: number;
    };
    SURCHARGES: {
        CLEANING: {
            AMOUNT: string;
            ID: number;
            IS_ENABLED: boolean;
            NAME: string;
        };
        PETS: {
            AMOUNT: string;
            ID: number;
            IS_ENABLED: boolean;
            NAME: string;
        };
    };
    SUBSCRIPTION: {
        COMMISSION_PERCENTAGE: number;
        CREDIT_CARD_PERCENTAGE: number;
        DESCRIPTION: string;
        DURATION: string;
        FEE: string;
        GST: string;
        GST_RATE: number;
        ID: number;
        NAME: string;
        NUMBER_OF_DAYS: number;
        RESORT_ID: number;
        SUBSCRIPTION_TIER_ID: PropertySubscriptionTierIdEnum;
    };
    SUITABILITIES: {
        LONG_TERM_RENTALS: {
            ID: number;
            DESCRIPTION: string;
            IS_SUITABLE: boolean;
            NAME: string;
        };
        PARTIES_EVENTS: {
            ID: number;
            DESCRIPTION: string;
            IS_SUITABLE: boolean;
            NAME: string;
        };
        PETS: {
            ID: number;
            DESCRIPTION: string;
            IS_SUITABLE: boolean;
            NAME: string;
        };
        SMOKING: {
            ID: number;
            DESCRIPTION: string;
            IS_SUITABLE: boolean;
            NAME: string;
        };
        TRAVEL_RESELLERS: {
            ID: number;
            DESCRIPTION: string;
            IS_SUITABLE: boolean;
            NAME: string;
        };
        WHEELCHAIR_ACCESSIBLE: {
            ID: number;
            DESCRIPTION: string;
            IS_SUITABLE: boolean;
            NAME: string;
        };
    };
    TAXES: {
        IS_MANDATORY: boolean;
        IS_PASS_THROUGH_TO_OWNER: boolean;
        NAME: string;
        ID: number;
        RATE: number;
        REGISTRATION_NUMBER: string;
        DESCRIPTION: string;
    }[];
    TAX_NUMBERS: {
        BC_SHORT_TERM_REGISTRY_NUMBER: string;
        BUSINESS_LICENCE_NUMBER: string;
        GST_NUMBER: string;
        PST_NUMBER: string;
    };
    THUMBNAIL_URL: string;
    URL: string;
    VIDEOS: {
        THREESIXTY: {
            DATA: string;
            ID: number;
        };
        YOUTUBE: {
            DATA: string;
            ID: number;
        }[];
        FEATURED: {
            DATA: string;
            ID: number;
        };
    };
    WALKTHROUGH: {
        PROPERTY_GUIDEBOOK: GuidebookWalkthrough;
    };
}, Error>;
interface _UnavailableDatesResponse1 {
    CANNOT_ARRIVE: string[];
    CANNOT_DEPART: string[];
    UNAVAILABILITY_ARRIVAL: string[];
    UNAVAILABILITY_DEPARTURE: string[];
}
interface _Args11 {
    onSuccess?: () => void;
    isEnabled: boolean;
    bookingId?: number;
    propertyId: number;
    isOwnerRole?: boolean;
    guestId?: number;
}
export interface UnavailableDatesResponse {
    CANNOT_ARRIVE: string[];
    CANNOT_DEPART: string[];
    UNAVAILABILITY_ARRIVAL: string[];
    UNAVAILABILITY_DEPARTURE: string[];
}
interface GuestArgs extends Omit<_Args11, 'propertyId'> {
    guestId: number;
}
export const useGuestUnavailableDates: ({ isEnabled, bookingId, guestId, onSuccess, }: GuestArgs) => UseQueryResult<APIResponse<UnavailableDatesResponse>, Error>;
export const OWNER_PROPERTY: {
    ACTIVE_SINCE: string;
    ADDRESS: {
        AREA: string;
        AREA_ID: number;
        CITY: string;
        COUNTRY: string;
        COUNTRY_CODE: string;
        COUNTRY_ID: number;
        DEVELOPMENT: string;
        DEVELOPMENT_ID: number;
        ID: number;
        LATITUDE: number;
        LONGITUDE: number;
        POSTAL: string;
        REGION: string;
        REGION_ID: number;
        RESORT: string;
        RESORT_ID: number;
        STREET_NAME: string;
        STREET_NUMBER: string;
        UNIT: string;
    };
    CAN_RENEW: boolean;
    COMPLETION_PERCENTAGE: number;
    DAYS_TO_EXPIRY: number;
    DAMAGE_DEPOSIT_MODE_ID: number;
    EXPIRY_DATE: string;
    HAS_COMPLETED_ONBOARDING: boolean;
    HAS_SUBSCRIPTION_RECEIPT: boolean;
    ID: number;
    IS_ENABLED: boolean;
    JOIN_STATUS: string;
    JOIN_STATUS_ID: JoinStatusIDEnum;
    NAME: string;
    NUM_BATHROOMS: number;
    NUM_BEDROOMS: number;
    SIZE_CATEGORY: string;
    THUMBNAIL: string;
    SUBSCRIPTION_TIER: {
        NAME: string;
        ID: PropertySubscriptionTierIdEnum;
        DESCRIPTION: string;
    };
    LISTING_QUALITY: {
        MESSAGE: string;
        STAR_RATING: number;
    };
    SURCHARGES: PropertySurcharge[];
    RESERVATION_SETTINGS: {
        DEPOSIT_PERCENTAGE: number;
        BALANCE_DAYS_BEFORE_ARRIVAL: number;
        BOOKING_GATEWAY_MODE_ID: number;
    };
};
export const OWNER_MEMBERSHIP_RENEWAL_INFO: {
    IS_ACTIVATION: boolean;
    IS_ALLURA_ADMIN: boolean;
    RENEWAL_TYPE: string;
    OWNER: WithRequiredProperty<User, "OWNER_PROFILE">;
    OWNER_ID: string;
    PROPERTY_ID: string;
    PROPERTY_NAME: string;
    RENEWAL_DURATION: string;
    RENEWAL_EXPIRY_DATE: string;
    RENEWAL_FEES: RenewalFeesItem;
    RENEWAL_PAYMENT_OPTIONS: RenewalTypeItem[];
    STRIPE_PUBLISHABLE_KEY: string;
    STRIPE_CUSTOMER: {};
    SUBSCRIPTION_TIERS: SubscriptionTier[];
    RENEWAL_PAYMENT_TYPE: string;
};
export const FINANCES_SUMMARY: {
    PROPERTY_ID: number;
    PROPERTY_ADDRESS: string;
    PROPERTY_THUMBNAIL_URL: string;
    UPCOMING: {
        NON_RESIDENT_WITHHELD: string;
        TAXES: {
            OWNER_REMIT_AMOUNT: string;
            NAME: string;
            ID: number;
            AMOUNT: string;
        }[];
        CREDIT_CARD_FEES: string;
        COMMISSION: string;
        RESERVATIONS_COUNT: number;
        SURCHARGES_AMOUNT: string;
        RESERVATIONS_AMOUNT: string;
    };
    TOTAL: {
        NON_RESIDENT_WITHHELD: string;
        TAXES: {
            OWNER_REMIT_AMOUNT: string;
            NAME: string;
            ID: number;
            AMOUNT: string;
        }[];
        CREDIT_CARD_FEES: string;
        COMMISSION: string;
        RESERVATIONS_COUNT: number;
        SURCHARGES_AMOUNT: string;
        RESERVATIONS_AMOUNT: string;
    };
    PAID: {
        NON_RESIDENT_WITHHELD: string;
        TAXES: {
            OWNER_REMIT_AMOUNT: string;
            NAME: string;
            ID: number;
            AMOUNT: string;
        }[];
        CREDIT_CARD_FEES: string;
        COMMISSION: string;
        RESERVATIONS_COUNT: number;
        SURCHARGES_AMOUNT: string;
        RESERVATIONS_AMOUNT: string;
    };
};
export const OWNER_FINANCES_SUMMARY: {
    OWNER_ID: number;
    PROPERTIES: {
        PROPERTY_ID: number;
        PROPERTY_ADDRESS: string;
        PROPERTY_THUMBNAIL_URL: string;
        UPCOMING: {
            NON_RESIDENT_WITHHELD: string;
            TAXES: {
                OWNER_REMIT_AMOUNT: string;
                NAME: string;
                ID: number;
                AMOUNT: string;
            }[];
            CREDIT_CARD_FEES: string;
            COMMISSION: string;
            RESERVATIONS_COUNT: number;
            SURCHARGES_AMOUNT: string;
            RESERVATIONS_AMOUNT: string;
        };
        TOTAL: {
            NON_RESIDENT_WITHHELD: string;
            TAXES: {
                OWNER_REMIT_AMOUNT: string;
                NAME: string;
                ID: number;
                AMOUNT: string;
            }[];
            CREDIT_CARD_FEES: string;
            COMMISSION: string;
            RESERVATIONS_COUNT: number;
            SURCHARGES_AMOUNT: string;
            RESERVATIONS_AMOUNT: string;
        };
        PAID: {
            NON_RESIDENT_WITHHELD: string;
            TAXES: {
                OWNER_REMIT_AMOUNT: string;
                NAME: string;
                ID: number;
                AMOUNT: string;
            }[];
            CREDIT_CARD_FEES: string;
            COMMISSION: string;
            RESERVATIONS_COUNT: number;
            SURCHARGES_AMOUNT: string;
            RESERVATIONS_AMOUNT: string;
        };
    }[];
    GROSS_VALUES: {
        UPCOMING: string;
        TOTAL: string;
        PAID: string;
    };
};
export const OWNER_FINANCES_TRANSACTION: {
    BOOKING_DATES: string;
    BOOKING_ID: number;
    BOOKING_REFERENCE: string;
    DETAIL_ID: number;
    GUEST_NAME: string;
    PROPERTY_ID: number;
    TRANSFER_AMOUNT: string;
    TRANSFER_DATE: string;
    TRANSFER_DETAILS: string;
};
export const OWNER_FINANCES_TRANSACTIONS: {
    OWNER_ID: number;
    TRANSACTIONS: {
        BOOKING_DATES: string;
        BOOKING_ID: number;
        BOOKING_REFERENCE: string;
        DETAIL_ID: number;
        GUEST_NAME: string;
        PROPERTY_ID: number;
        TRANSFER_AMOUNT: string;
        TRANSFER_DATE: string;
        TRANSFER_DETAILS: string;
    }[];
};
export const OWNER_FINANCES_RESERVATIONS_COLUMN: {
    NAME: string;
    KEY: string;
};
export const OWNER_FINANCES_RESERVATIONS_TRANSACTION: {
    arrival_date: string;
    bank_deposit: string;
    booking_id: number;
    booking_ref: string;
    booking_status: string;
    commission_gst: string;
    commission_net: string;
    credit_card_fee: string;
    damage_deposit: string;
    gst: string;
    guest_name: string;
    mrdt: string;
    non_resident_withheld: string;
    number_of_nights: number;
    payment_category: string;
    property_id: number;
    property_manager_service_fee: string;
    property_manager_service_fee_tax: string;
    pst: string;
    qst: string;
    service_fee_total: string;
    surcharge_gst: string;
    surcharge_mrdt: string;
    surcharge_net: string;
    surcharge_pst: string;
    surcharge_qst: string;
    transaction_amount: string;
    transaction_date: string;
    transaction_id: number;
    transfer_date: string;
};
export const OWNER_FINANCES_RESERVATIONS: {
    PROPERTY_ID: string;
    OWNER_ID: number;
    COLUMNS: {
        NAME: string;
        KEY: string;
    }[];
    TRANSACTIONS: {
        arrival_date: string;
        bank_deposit: string;
        booking_id: number;
        booking_ref: string;
        booking_status: string;
        commission_gst: string;
        commission_net: string;
        credit_card_fee: string;
        damage_deposit: string;
        gst: string;
        guest_name: string;
        mrdt: string;
        non_resident_withheld: string;
        number_of_nights: number;
        payment_category: string;
        property_id: number;
        property_manager_service_fee: string;
        property_manager_service_fee_tax: string;
        pst: string;
        qst: string;
        service_fee_total: string;
        surcharge_gst: string;
        surcharge_mrdt: string;
        surcharge_net: string;
        surcharge_pst: string;
        surcharge_qst: string;
        transaction_amount: string;
        transaction_date: string;
        transaction_id: number;
        transfer_date: string;
    }[];
};
export const OWNER_MINIMAL_PROPERTY: {
    ID: number;
    TITLE: string;
    THUMBNAIL: string;
};
export const OWNER_EXTERNAL_EVENTS: {
    PROPERTIES: {
        PROPERTY: {
            ID: number;
            TITLE: string;
            THUMBNAIL: string;
        };
        EXTERNAL_BOOKINGS: {
            SOURCE: string;
            NIGHTS: number;
            ARRIVAL: string;
            DEPARTURE: string;
            ID: number;
            SUMMARY: string;
        }[];
    }[];
    OWNER_ID: string;
};
export const OWNER_BLOCKED_DATE: {
    ARRIVAL: string;
    DEPARTURE: string;
    BOOKING_ID: number;
    TITLE: string;
    DESCRIPTION: string;
};
export const OWNER_MIN_NIGHT_GAP: {
    PROPERTY_ID: number;
    START: string;
    MIN_NIGHTS: number;
    AVAILABLE_NIGHTS: number;
    END: string;
};
export const OWNER_UNBOOKABLE_DATES: {
    OWNER_ID: string;
    PROPERTIES: {
        PROPERTY: {
            ID: number;
            TITLE: string;
            THUMBNAIL: string;
        };
        BLOCKED_DATES: {
            ARRIVAL: string;
            DEPARTURE: string;
            BOOKING_ID: number;
            TITLE: string;
            DESCRIPTION: string;
        }[];
        MIN_NIGHT_GAPS: {
            PROPERTY_ID: number;
            START: string;
            MIN_NIGHTS: number;
            AVAILABLE_NIGHTS: number;
            END: string;
        }[];
        LAST_AVAILABLE_DATE: string;
    }[];
};
export const OWNER_MOBILE_WALKTHROUGH: {
    WALKTHROUGH_MOBILE: {
        COMPLETED_STEPS: MobileWalkThroughNameEnum[];
        COMPLETION_PERCENTAGE: number;
        NUM_STEPS: number;
        STEPS: MobileWalkThroughNameEnum[];
    };
};
export type OwnerFinancesSummary = typeof OWNER_FINANCES_SUMMARY;
export type OwnerFinancesTransactions = typeof OWNER_FINANCES_TRANSACTIONS;
export type OwnerFinancesReservations = typeof OWNER_FINANCES_RESERVATIONS;
/** From /owner/externalbookings */
export type OwnerExternalEvents = typeof OWNER_EXTERNAL_EVENTS;
/** From /owner/unbookabledates */
export type OwnerUnbookableDates = typeof OWNER_UNBOOKABLE_DATES;
export type OwnerMobileWalkthrough = typeof OWNER_MOBILE_WALKTHROUGH;
export type OwnerProperty = typeof OWNER_PROPERTY;
export type OwnerMembershipRenewalInfo = typeof OWNER_MEMBERSHIP_RENEWAL_INFO;
export type FinancesSummary = typeof FINANCES_SUMMARY;
export type OwnerFinancesTransaction = typeof OWNER_FINANCES_TRANSACTION;
export type OwnerFinancesReservationsTransaction = typeof OWNER_FINANCES_RESERVATIONS_TRANSACTION;
export type OwnerMinimalProperty = typeof OWNER_MINIMAL_PROPERTY;
export type OwnerBlockedDate = typeof OWNER_BLOCKED_DATE;
export type OwnerMinNightGap = typeof OWNER_MIN_NIGHT_GAP;
interface TaxItem {
    NAME: string;
    RATE: string;
    AMOUNT: string;
}
export interface RenewalFeesItem {
    TAX_TOTAL: string;
    RENEWAL_FEE: string;
    TOTAL: string;
    OWNER_CREDIT: string;
    SUBTOTAL_LESS_OWNER_CREDIT: string;
    TAXES: TaxItem[];
}
export interface RenewalTypeItem {
    TITLE: string;
    TYPE: string;
    PAYMENTS?: {
        DATE: string;
        AMOUNT: string;
    }[];
}
export interface OwnerGuest {
    EMAIL: string;
    FIRST_NAME: string;
    LAST_NAME: string;
    ID: number;
}
export type OwnerFinancesSort = 'arrival_date' | 'transaction_date';
export enum MobileWalkThroughNameEnum {
    /** The user has viewed the download link */
    download = "DownloadApp",
    /** The user has viewed the mobile app introduction app */
    introduction = "Introduction",
    /** The user has installed the mobile app and entered the confirmation code */
    installation = "InstallationConfirmation"
}
export const ownerContactAlluraEndpoint = "/RESTAUTH/owner/contact/allura/";
export const ownerCredentialsEndpoint = "/RESTAUTH/owner/credentials/";
export const ownerLoginEndpoint = "/RESTAUTH/owner/login/";
export const ownerLogoutEndpoint = "/RESTAUTH/owner/logout/";
export const ownerMobileWalkthroughEndpoint = "/RESTAUTH/owner/walkthrough/mobile/complete/";
export const ownerPutEndpoint = "/RESTAUTH/owner/";
export const ownerReferalEndpoint = "/RESTAUTH/owner/referral/";
export const requestPropertyDeactivationEndPoint = "/RESTAUTH/owner/property/requestdeactivation/";
export const ownerPropertyLoginEndpoint = "/RESTAUTH/owner/property/login/";
export const ownerPropertyCreateEndpoint = "/RESTAUTH/owner/property/create/";
export const generateOwnerGuestsEndpoint: (ownerId: number) => string;
export const generateOwnerMobileWalkthroughEndpoint: (id: number) => string;
export const generatePriorityBookingsEndpoint: (ownerId: number) => string;
export const membershipRenewalInfo: (propertyId: number, ownerId: number) => string;
export const renewalTransaction: (propertyId: number, ownerId: number) => string;
export const generateOwnerNotificationsEndPoint: ({ amountPerPage, page, category, ownerId, status, propertyId, }: {
    amountPerPage: number;
    page: number;
    ownerId: number;
    category: NotificationEndpointFilterCategory;
    status: NotificationEndpointFilterStatus;
    propertyId?: number;
}) => string;
export const ownerDismissNotificationsEndpoint = "/RESTAUTH/owner/notifications/dismiss/";
export const generateOwnerPropertiesEndPoint: (ownerId: number) => string;
export const generateOwnerBookingsEndpoint: ({ page, ownerId, status_id, amountPerPage, direction, propertyIds, }: {
    page: number;
    ownerId: number;
    direction?: "future" | "past" | "all";
    amountPerPage?: number;
    propertyIds: number[];
    status_id?: BookingStatusId | undefined;
}) => string;
export interface FinancesArgs {
    ownerId: number;
    year: number;
    fromMonth: number;
    toMonth: number;
    sortOrder: OwnerFinancesSort;
    propertyId?: number;
}
export const generateOwnerFinancesSummaryEndpoint: ({ ownerId, year, fromMonth, toMonth, sortOrder, propertyId, }: FinancesArgs) => string;
export interface TransactionsArgs extends FinancesArgs {
    filter: 'completed' | 'upcoming';
}
export const generateOwnerFinancesTransactionsEndpoint: ({ ownerId, year, fromMonth, toMonth, sortOrder, propertyId, filter, }: TransactionsArgs) => string;
export const generateOwnerFinancesReservationsEndpoint: ({ ownerId, year, fromMonth, toMonth, sortOrder, propertyId, }: FinancesArgs) => string;
export const generateOwnerFinancesReservationsCsvEndpoint: ({ ownerId, year, fromMonth, toMonth, sortOrder, propertyId, }: FinancesArgs) => string;
export const generateOwnerFinancesTransactionsCsvEndpoint: ({ ownerId, year, fromMonth, toMonth, sortOrder, propertyId, }: FinancesArgs) => string;
interface OwnerUnbookableProps {
    ownerId: number;
    propertyId?: number;
    numMonths: number;
}
/** Despite what the name might suggest, this endpoint returns all external events from synced iCals */
export const generateOwnerExternalBookingsEndpoint: ({ ownerId, propertyId, numMonths, }: OwnerUnbookableProps) => string;
export const generateOwnerUnbookableDates: ({ ownerId, numMonths, propertyId }: OwnerUnbookableProps) => string;
interface _Args12 {
    ownerId: number;
    category: NotificationEndpointFilterCategory;
    status: NotificationEndpointFilterStatus;
    propertyId?: number;
    refetchInterval?: number;
    enabled?: boolean;
}
export const useOwnerNotificationsQueryKeys: QueryKeys;
export const useOwnerNotificationsInfiniteQuery: ({ ownerId, category, status, enabled, refetchInterval, propertyId, }: _Args12) => UseInfiniteQueryResult<_InfiniteData1<any, unknown>, any>;
export const useOwnerMobileWalkthroughMutation: () => UseMutationResult<any, Error, {
    id: number;
    step_name: MobileWalkThroughNameEnum;
}, void>;
interface _Values2 {
    /** Owner Id */
    id: number;
    notification_ids: number[] | 'all';
}
export const useOwnerDismissNotificationsMutation: (args: ConfigurableAppMutationArgs) => UseMutationResult<any, Error, _Values2, void>;
export const useOwnerPropertyLoginMutation: (reactQueryOptions?: ConfigurableAppMutationArgs) => UseMutationResult<APIResponse<{
    PROPERTY_ID: number;
}>, Error, {
    id: number;
    property_id: number;
}, void>;
export const useOwnerUnavailableDates: ({ isEnabled, bookingId, propertyId, onSuccess, }: _Args11) => UseQueryResult<APIResponse<_UnavailableDatesResponse1>, Error>;
interface _Args13 {
    ownerId: number;
}
export const usePropertiesQuery: ({ ownerId, ...rest }: _Args13 & ConfigurableAppQueryArgs<any>) => UseQueryResult<APIResponse<{
    PROPERTIES: OwnerProperty[];
    OWNER_ID: number;
}>, Error>;
export const useOwnerFinancesSummaryQuery: ({ ownerId, year, fromMonth, toMonth, sortOrder, propertyId, ...rest }: FinancesArgs & ConfigurableAppQueryArgs) => UseQueryResult<APIResponse<{
    OWNER_ID: number;
    PROPERTIES: {
        PROPERTY_ID: number;
        PROPERTY_ADDRESS: string;
        PROPERTY_THUMBNAIL_URL: string;
        UPCOMING: {
            NON_RESIDENT_WITHHELD: string;
            TAXES: {
                OWNER_REMIT_AMOUNT: string;
                NAME: string;
                ID: number;
                AMOUNT: string;
            }[];
            CREDIT_CARD_FEES: string;
            COMMISSION: string;
            RESERVATIONS_COUNT: number;
            SURCHARGES_AMOUNT: string;
            RESERVATIONS_AMOUNT: string;
        };
        TOTAL: {
            NON_RESIDENT_WITHHELD: string;
            TAXES: {
                OWNER_REMIT_AMOUNT: string;
                NAME: string;
                ID: number;
                AMOUNT: string;
            }[];
            CREDIT_CARD_FEES: string;
            COMMISSION: string;
            RESERVATIONS_COUNT: number;
            SURCHARGES_AMOUNT: string;
            RESERVATIONS_AMOUNT: string;
        };
        PAID: {
            NON_RESIDENT_WITHHELD: string;
            TAXES: {
                OWNER_REMIT_AMOUNT: string;
                NAME: string;
                ID: number;
                AMOUNT: string;
            }[];
            CREDIT_CARD_FEES: string;
            COMMISSION: string;
            RESERVATIONS_COUNT: number;
            SURCHARGES_AMOUNT: string;
            RESERVATIONS_AMOUNT: string;
        };
    }[];
    GROSS_VALUES: {
        UPCOMING: string;
        TOTAL: string;
        PAID: string;
    };
}>, Error>;
export const useOwnerFinancesTransactionsQuery: ({ ownerId, year, toMonth, fromMonth, propertyId, sortOrder, filter, ...rest }: TransactionsArgs & ConfigurableAppQueryArgs) => UseQueryResult<APIResponse<{
    OWNER_ID: number;
    TRANSACTIONS: {
        BOOKING_DATES: string;
        BOOKING_ID: number;
        BOOKING_REFERENCE: string;
        DETAIL_ID: number;
        GUEST_NAME: string;
        PROPERTY_ID: number;
        TRANSFER_AMOUNT: string;
        TRANSFER_DATE: string;
        TRANSFER_DETAILS: string;
    }[];
}>, Error>;
export const useOwnerFinancesReservationsQuery: ({ ownerId, year, fromMonth, toMonth, sortOrder, propertyId, ...rest }: FinancesArgs & ConfigurableAppQueryArgs) => UseQueryResult<APIResponse<{
    PROPERTY_ID: string;
    OWNER_ID: number;
    COLUMNS: {
        NAME: string;
        KEY: string;
    }[];
    TRANSACTIONS: {
        arrival_date: string;
        bank_deposit: string;
        booking_id: number;
        booking_ref: string;
        booking_status: string;
        commission_gst: string;
        commission_net: string;
        credit_card_fee: string;
        damage_deposit: string;
        gst: string;
        guest_name: string;
        mrdt: string;
        non_resident_withheld: string;
        number_of_nights: number;
        payment_category: string;
        property_id: number;
        property_manager_service_fee: string;
        property_manager_service_fee_tax: string;
        pst: string;
        qst: string;
        service_fee_total: string;
        surcharge_gst: string;
        surcharge_mrdt: string;
        surcharge_net: string;
        surcharge_pst: string;
        surcharge_qst: string;
        transaction_amount: string;
        transaction_date: string;
        transaction_id: number;
        transfer_date: string;
    }[];
}>, Error>;
interface _Args14 {
    ownerId: number;
    propertyId?: number;
    numMonths: number;
}
export const ownerExternalEventsQueryKey: QueryKeys;
export const useOwnerExternalEventsQuery: ({ ownerId, propertyId, numMonths, ...rest }: _Args14 & ConfigurableAppQueryArgs) => UseQueryResult<APIResponse<{
    PROPERTIES: {
        PROPERTY: {
            ID: number;
            TITLE: string;
            THUMBNAIL: string;
        };
        EXTERNAL_BOOKINGS: {
            SOURCE: string;
            NIGHTS: number;
            ARRIVAL: string;
            DEPARTURE: string;
            ID: number;
            SUMMARY: string;
        }[];
    }[];
    OWNER_ID: string;
}>, Error>;
interface _Args15 {
    ownerId: number;
    propertyId?: number;
    numMonths: number;
}
export const ownerUnbookableDatesQueryKey: QueryKeys;
export const useOwnerUnbookableDatesQuery: ({ ownerId, propertyId, numMonths, ...rest }: _Args15 & ConfigurableAppQueryArgs) => UseQueryResult<APIResponse<{
    OWNER_ID: string;
    PROPERTIES: {
        PROPERTY: {
            ID: number;
            TITLE: string;
            THUMBNAIL: string;
        };
        BLOCKED_DATES: {
            ARRIVAL: string;
            DEPARTURE: string;
            BOOKING_ID: number;
            TITLE: string;
            DESCRIPTION: string;
        }[];
        MIN_NIGHT_GAPS: {
            PROPERTY_ID: number;
            START: string;
            MIN_NIGHTS: number;
            AVAILABLE_NIGHTS: number;
            END: string;
        }[];
        LAST_AVAILABLE_DATE: string;
    }[];
}>, Error>;
interface _Args16 {
    id: number;
}
export const useOwnerMobileWalkthroughQuery: ({ id }: _Args16 & ConfigurableAppQueryArgs) => UseQueryResult<APIResponse<{
    WALKTHROUGH_MOBILE: {
        COMPLETED_STEPS: MobileWalkThroughNameEnum[];
        COMPLETION_PERCENTAGE: number;
        NUM_STEPS: number;
        STEPS: MobileWalkThroughNameEnum[];
    };
}>, Error>;
interface _Args17 {
    propertyId: number;
    pageDirection?: InfiniteQueryPageDirections;
    amountPerPage?: number;
    initialPageParam?: number;
}
export const propertyReviewsInfiniteQueryKey: QueryKeys;
export const usePropertyReviewsInfiniteQuery: ({ propertyId, pageDirection, amountPerPage, initialPageParam, ...rest }: _Args17 & ConfigurableAppInfiniteQueryArgs) => UseInfiniteQueryResult<_InfiniteData1<any, unknown>, any>;
export interface DateOfBirth {
    year: string;
    month: string;
    day: string;
}
/** dayjs needs to be initialized in every project it is used in
 *  importing this file should setup dayjs with the required extensions + timezone
 */
export function dayjsInitializer(): void;
type DateLike = Dayjs | Date | string;
export const convertDateToGMTDate: (date: Date) => Date;
export const handleAddDay: (date: string | Date | Dayjs) => Dayjs;
export const handleAddDays: (date: string | Date | Dayjs, daysToAdd: number) => Dayjs;
export const handleRemoveDay: (date: string | Date | Dayjs) => Dayjs;
export const daysInCurrentMonth: (year: number, month: number) => number;
export const calculateIsDateInPast: (date: string | Date | Dayjs) => boolean;
export const calculateIsDateBeforeMandatoryGST: () => boolean;
export const convertDateStringToDate: (dateString: string) => Date;
export function isValidDate(d: any): boolean;
export const checkIsValidDate: (date: dayjs.ConfigType) => boolean;
export const calculateIsFinalMonthOfData: (date: dayjs.ConfigType, finalMonth: dayjs.ConfigType) => boolean;
export const hourOrDayDifferenceString: ({ fromDateTime, toDateTime }: {
    fromDateTime: Dayjs;
    toDateTime: Dayjs;
}) => string;
export const calculateDayDifference: (start: DateLike, end: DateLike) => number;
/** Will return a negative number if the start is before the end, positive otherwise
 *  When start and end differ by a year, dayjs correctly calculates the month difference as +/- 12
 * */
export const calculateMonthDifference: (start: DateLike, end: DateLike) => number;
export const calculateNights: ({ date1, date2 }: {
    date1: DateLike;
    date2: DateLike;
}) => number;
/**  Number of days difference between selected date and today (negative if date is in past) */
export const numberOfDaysUntil: (date: DateLike) => number;
export const calculateDifferenceInDays: (start: Date, end: Date) => number;
export function serverDaysFromToday(numDays: number): string;
/** time param format: <number><number>:<number><number>.  */
export const convert24HourTo12Hour: (time: string) => string;
export const parseDOB: (dob: string) => DateOfBirth;
export const convertDateToUTCSeconds: (date: Date) => number;
export const isDayWithinRange: ({ day, start, end }: {
    day: Dayjs;
    start: Dayjs;
    end: Dayjs;
}) => boolean;
/** Returns true if checked range is infact inside the range of the comparator range */
interface RangeWithinRange {
    checked: {
        start: Dayjs;
        end: Dayjs;
    };
    comparator: {
        start: Dayjs;
        end: Dayjs;
    };
}
export const isRangeWithinRange: ({ checked, comparator }: RangeWithinRange) => boolean;
export const isWeekendDate: (date: Dayjs) => boolean;
/** dateSent is a YYYY-MM-DD formatted UTC string
 *  timeSent is an HH:MM formatted 24-hour string
 */
export function getRelativeTime(dateSent: string, timeSent: string, now?: dayjs.Dayjs): string;
/** Given date and time, returns a Dayjs object corresponding to the server's timezone (PDT)
 * @param date is a YYYY-MM-DD formatted PDT string
 * @param time is an HH:MM formatted 24-hour string (also PDT time)
 * @returns Returns a dayjs object in the PDT timezone
 */
export function getDateTime(date: string, time: string): Dayjs;
export function getDateWithNoHoursMinutesSeconds(): Dayjs;
export function convertDateWithNoHoursMinutesSeconds(date: DateLike): Dayjs;
export const serverStringFormat = "YYYY-MM-DD";
export const shortMonthDayFormat = "MMM D";
export const shortMonthFormat = "MMM D, YYYY";
export const longMonthYearFormat = "MMMM YYYY";
export const longMonthFormat = "MMMM D, YYYY";
export const longMonthOrdinalFormat = "MMMM Do, YYYY";
export const shortMonthOrdinalFormat = "MMM Do, YYYY";
export const longStringFormat = "dddd, MMMM D, YYYY";
export const handleDateObjToStringYYYMMDD: (date: Date) => string;
export const dateFormatShortMonthDay: (date: Dayjs) => string;
export const dateFormatDialog: (date: Date | Dayjs) => string;
export const dateFormatLong: (date: Date | string | Dayjs) => string;
export const dateFormatLongMonth: (date: Date | string | Dayjs) => string;
export const dateFormatLongString: (date: Date | string | Dayjs) => string;
export const dateFormatMontDay: (date: string) => string;
export const dateFormatMonthDayYearDayOfWeek: (date: string) => string;
export const dateFormatMonthYear: (date: string) => string;
export const dateFormatServer: (date: Date | Dayjs) => string;
export const dayjsFormatServer: (date: Dayjs) => string;
export const dayjsFormatLongOrdinal: (date: Dayjs | string | Date) => string;
export const dayjsFormatShortOrdinal: (date: Dayjs) => string;
export const getYearsDifferenceExact: (date1: Date, date2: Date) => number;
export const generateUpdatedSendValues: (pid: any) => (values: any) => any;
export const useWalkthroughGuidebookMutation: () => UseMutationResult<any, Error, {
    id: number;
    form_data: string;
}, void>;
interface _Args18 {
    onSuccess?: (data: any) => void;
    propertyId: number;
}
type ConfigurableArgs = Omit<ConfigurableAppMutationArgs, 'onSuccess' | 'modifySendData'>;
export const usePropertySubformMutation: ({ onSuccess, propertyId, ...rest }: _Args18 & ConfigurableArgs) => UseMutationResult<any, Error, any, void>;
export const defaultLocationURLParams: any[];
export const generateOwnerLocationEndPoint: (requirements?: LocationURLParamsEnum[]) => string;
export const generateGuestLocationEndPoint: (userId: number, requirements?: LocationURLParamsEnum[]) => string;
export const errorsEndPoint = "/RESTAUTH/error/";
export const generateCancellationPolicyEndpoint: ({ policy_id, is_credit_only_refund, is_refund_rebooked_dates, is_special_circumstance, special_circumstance_id, special_circumstance_description, admin_penalty, admin_penalty_unit, }: {
    policy_id: any;
    is_credit_only_refund: any;
    is_refund_rebooked_dates: any;
    is_special_circumstance: any;
    special_circumstance_id: any;
    special_circumstance_description: string;
    admin_penalty: any;
    admin_penalty_unit: any;
}) => string;
export const generateTermsOfServiceAgreementEndpoint: (userTypeId: UserRoleIDEnum) => string;
interface _Values3 {
    client_ip: number;
    user_id: number;
    user_type_id: number;
    stack_trace: string;
    message: string;
}
export const useErrorMutation: () => UseMutationResult<any, Error, _Values3, void>;
interface _Args19 {
    userTypeId: UserRoleIDEnum;
}
/** Returns html Terms of service agreement for guests or hosts */
export const useTermsOfServiceQuery: ({ userTypeId, ...rest }: _Args19 & ConfigurableAppQueryArgs) => UseQueryResult<APIResponse<{
    TOSSA: string;
}>, Error>;
/** This is the standard user endpoint for Lucee now. It will also return
 * the auth state of the current client's session in that it will return the user object
 * or an empty object if the user is not logged in.
 */
export const userPutEndpoint = "/RESTAUTH/user/";
export const userEndpoint = "/RESTAUTH/user/checklogin/";
export const userCredentialsEndpoint = "/RESTAUTH/user/credentials/";
export const userLoginEndpoint = "/RESTAUTH/user/login/";
export const userPasswordSyncEndpoint = "/RESTAUTH/user/accountsync/";
export const userProfilePhotoEndpoint = "/RESTAUTH/user/profilephoto/";
export const userMessageEndpoint = "/RESTAUTH/user/message/";
export const twilioSendCodeEndpoint = "/RESTAUTH/user/verification/";
export const twilioSendCodeEndpointCheck = "/RESTAUTH/user/verification/check/";
/** POST: accepts an email */
export const userPasswordResetEndpoint = "/RESTAUTH/user/passwordreset/";
export const generateUserProfilePhotoEndpoint: (userId: number, userTypeId: UserRoleIDEnum) => string;
/** Get number of unread messages */
export const generateUserMessageUnreadEndpoint: (id: number, userTypeId: UserRoleIDEnum) => string;
/** Mark all messages in the contact thread as read for the current user */
export const userMessageMarkAsReadEndpoint = "/RESTAUTH/user/message/thread/markasread/";
/** Get detailed information about a specific user
 * Send a propertyId when contactUserTypeId is not guest
 */
export type UserMessageContactArgs = {
    contactUserTypeId: UserRoleIDEnum;
    contactUserId: number;
    propertyId?: number;
};
export const generateUserMessageContactEndpoint: ({ contactUserTypeId, contactUserId, propertyId, }: UserMessageContactArgs) => string;
/** Gets UserMessageSubject information from a reservation. One of bookingId or messageId is required */
export const generateUserMessageSubjectEndpoint: ({ id, userTypeId, bookingId, messageId, }: {
    id: number;
    userTypeId: UserRoleIDEnum;
    bookingId?: number;
    messageId?: number;
}) => string;
export const generateUserMessageSubjectsEndpoint: ({ id, userTypeId, page, page_direction, amountPerPage, subjectType, filterUserId, filterUserTypeId, searchFilter, }: {
    id: number;
    userTypeId: UserRoleIDEnum;
    page: number;
    page_direction: InfiniteQueryPageDirections;
    amountPerPage: number;
    subjectType: "past_bookings" | "future_bookings" | "inquiries";
    searchFilter?: string;
    filterUserId?: number;
    filterUserTypeId?: UserRoleIDEnum;
}) => string;
export const generateUserMessageOverviewEndpoint: ({ id, userTypeId, page, amountPerPage, propertyId, }: {
    id: number;
    userTypeId: UserRoleIDEnum;
    page: number;
    amountPerPage: number;
    propertyId?: number;
}) => string;
export const generateUserMessageThreadEndpoint: ({ id, userTypeId, page, amountPerPage, contactUserId, contactUserTypeId, }: {
    id: number;
    userTypeId: UserRoleIDEnum;
    page: number;
    amountPerPage: number;
    contactUserId: number;
    contactUserTypeId: UserRoleIDEnum;
}) => string;
export const userExpoTokenEndpoint = "/RESTAUTH/user/expopushtoken/";
export const generateUserCheckEmailTaken: (email: string) => string;
export const generateUserCheckEmailExists: (email: string) => string;
interface _Args20 {
    id: number;
    userTypeId: UserRoleIDEnum;
    subjectType: 'past_bookings' | 'future_bookings' | 'inquiries';
    filterUserId?: number;
    filterUserTypeId?: UserRoleIDEnum;
    searchFilter?: string;
    pageDirection?: InfiniteQueryPageDirections;
    enabled?: boolean;
}
export const userMessageSubjectsQueryKeys: QueryKeys;
export const useUserMessageSubjectsInfiniteQuery: ({ id, userTypeId, subjectType, searchFilter, filterUserId, filterUserTypeId, pageDirection, enabled, }: _Args20) => UseInfiniteQueryResult<_InfiniteData1<any, unknown>, any>;
interface _Args21 {
    userId: number;
    userTypeId: UserRoleIDEnum;
    contactId: number | undefined;
    contactUserTypeId: UserRoleIDEnum | undefined;
}
/** When a user selects a subject they can  */
export const useMessageSubjectInfiniteQuery: ({ userId, userTypeId, contactId, contactUserTypeId }: _Args21) => {
    upcomingBookings: {
        ID: number;
        CONTACT: {
            ID: number;
            THUMBNAIL: string;
            NAME: string;
            USER_TYPE_ID: UserRoleIDEnum;
            EMAIL: string;
        };
        BOOKING: {
            ID: number;
            ARRIVAL_DATE: string;
            DEPARTURE_DATE: string;
            CREATED_DATE: string;
            REFERENCE: string;
        };
        PROPERTY: {
            ID: number;
            THUMBNAIL: string;
            NAME: string;
            SIZE_CATEGORY: string;
        };
        MESSAGE: {
            MESSAGE: string;
            SUBJECT: string;
            TO_EMAILS: string;
            DATE_SENT: string;
            FROM_EMAIL: string;
            RECIPIENT: string;
            THUMBNAIL: string;
            TIME_SENT: string;
            ID: number;
            RECIPIENT_ID: number;
            IS_READ: boolean;
            READ_DATE: string;
            READ_TIME: string;
            NUM_UNREAD: number;
            ARRIVAL_DATE: string;
            DEPARTURE_DATE: string;
            CREATED_DATE: string;
            NUM_BEDS: number;
            NUM_GUESTS: number;
            IS_INQUIRY: boolean;
        };
    }[];
    pastBookings: {
        ID: number;
        CONTACT: {
            ID: number;
            THUMBNAIL: string;
            NAME: string;
            USER_TYPE_ID: UserRoleIDEnum;
            EMAIL: string;
        };
        BOOKING: {
            ID: number;
            ARRIVAL_DATE: string;
            DEPARTURE_DATE: string;
            CREATED_DATE: string;
            REFERENCE: string;
        };
        PROPERTY: {
            ID: number;
            THUMBNAIL: string;
            NAME: string;
            SIZE_CATEGORY: string;
        };
        MESSAGE: {
            MESSAGE: string;
            SUBJECT: string;
            TO_EMAILS: string;
            DATE_SENT: string;
            FROM_EMAIL: string;
            RECIPIENT: string;
            THUMBNAIL: string;
            TIME_SENT: string;
            ID: number;
            RECIPIENT_ID: number;
            IS_READ: boolean;
            READ_DATE: string;
            READ_TIME: string;
            NUM_UNREAD: number;
            ARRIVAL_DATE: string;
            DEPARTURE_DATE: string;
            CREATED_DATE: string;
            NUM_BEDS: number;
            NUM_GUESTS: number;
            IS_INQUIRY: boolean;
        };
    }[];
    isLoading: boolean;
    upcomingBookingsQuery: UseInfiniteQueryResult<_InfiniteData1<any, unknown>, any>;
    pastBookingsQuery: UseInfiniteQueryResult<_InfiniteData1<any, unknown>, any>;
};
interface _Args22 {
    id: number;
    userTypeId: UserRoleIDEnum;
    /** Optional: filter by a specific property id */
    propertyId?: number;
    enabled?: boolean;
    refetchInterval?: number;
}
export const userMessageOverviewQueryKeys: QueryKeys;
export const useUserMessageOverviewInfiniteQuery: ({ id, userTypeId, propertyId, refetchInterval, enabled, }: _Args22) => UseInfiniteQueryResult<_InfiniteData1<any, unknown>, any>;
interface _Args23 {
    id: number;
    userTypeId: UserRoleIDEnum;
    contactUserId: number;
    contactUserTypeId: UserRoleIDEnum;
}
export const userMessageThreadQueryKeys: QueryKeys;
export const useUserMessageThreadInfiniteQuery: ({ id, userTypeId, contactUserId, contactUserTypeId, ...rest }: _Args23 & ConfigurableAppInfiniteQueryArgs) => UseInfiniteQueryResult<_InfiniteData1<any, unknown>, any>;
export const generateEditReservationMessage: ({ guestId, propertyOwnerId, message, booking_id, start, end, }: {
    guestId: number;
    propertyOwnerId: number;
    message: string;
    booking_id: number;
    start: string;
    end: string;
}) => UserMessage;
export const generateCancelReservationMessage: ({ guestId, propertyOwnerId, message, booking_id, }: {
    guestId: number;
    propertyOwnerId: number;
    message: string;
    booking_id: number;
}) => UserMessage;
export const useUserCreateMessageMutation: () => UseMutationResult<any, Error, UserMessage, void>;
interface MessageMarkAsReadSendData {
    id: number;
    user_type_id: UserRoleIDEnum;
    contact_user_id: number;
    contact_user_type_id: UserRoleIDEnum;
}
export const useUserMessageMarkAsReadMutation: (args: ConfigurableAppMutationArgs) => UseMutationResult<any, Error, MessageMarkAsReadSendData, void>;
export interface UploadProfilePhotoSendValues {
    /** base64 version of the image being uploaded */
    file: string;
    id: number;
    user_type_id: UserRoleIDEnum;
    /** x axis point for crop; note if cropped then x,y,width,height,rotation are all required */
    x?: number;
    y?: number;
    width?: number;
    height?: number;
    rotation?: number;
}
export const useUserUploadProfilePhotoMutation: (props: ConfigurableAppMutationArgs) => UseMutationResult<any, Error, UploadProfilePhotoSendValues, void>;
interface _Values4 {
    email: string;
    password: string;
}
interface Response {
    USER: User;
    JSESSIONID: string;
}
export const useUserLoginMutation: (args?: ConfigurableAppMutationArgs) => UseMutationResult<APIResponse<Response>, Error, _Values4, void>;
export const useUserLogoutLuceeMutation: (args?: ConfigurableAppMutationArgs) => UseMutationResult<any, Error, any, void>;
interface SendValues {
    id: number;
    token: string;
}
/** Create a new user <-> token link in db */
export const useUserCreateExpoToken: (args?: ConfigurableAppMutationArgs) => UseMutationResult<any, Error, SendValues, void>;
interface _SendValues1 {
    id: number;
    token: string;
    is_enabled: boolean;
}
/** Update existing user <-> token link, enable or disable */
export const useUserUpdateExpoToken: (args?: ConfigurableAppMutationArgs) => UseMutationResult<any, Error, _SendValues1, void>;
export const userQueryKey = "USER";
interface _Args24 {
    /** Force Luccee to reload the user from the db
     * If a django endpoint modifies the user object then Luccee will not get the changes unless this is set to true
     */
    isReloadUser?: boolean;
}
/** This query will return the user object is the user is logged in.
 * It essentially will act as an auth_state query in addition to fetching the user object.
 */
export const useUserQuery: ({ isReloadUser, ...useQueryOptions }?: _Args24 & ConfigurableAppQueryArgs) => UseQueryResult<APIResponse<{
    USER: User | false;
}>, Error>;
/** FIRST_NAME, LAST_NAME are empty strings when IS_COMPANY is true
 * COMPANY is empty string when IS_COMPANY is false
 */
interface SendData extends Pick<User, 'ID' | 'EMAIL' | 'PHONE' | 'FIRST_NAME' | 'LAST_NAME' | 'COMPANY_NAME' | 'IS_COMPANY' | 'DATE_OF_BIRTH'> {
    CITY: string;
    COUNTRY: string;
    POSTAL: string;
    REGION: string;
    STREET_NUMBER: string;
    STREET_NAME: string;
    /** empty string for no unit number */
    UNIT: string;
}
export const useUserPutMutation: (args?: ConfigurableAppMutationArgs) => UseMutationResult<APIResponse<{
    USER: User;
}>, Error, SendData, void>;
interface SendValue {
    id: number;
    email: string;
    password: string;
}
export const useUserCredentialsPutMutation: (args?: ConfigurableAppMutationArgs) => UseMutationResult<APIResponse<User>, Error, SendValue, void>;
export enum TwilioVerificationChannelEnum {
    email = "email",
    sms = "sms",
    call = "call"
}
interface _SendValues2 {
    value: string;
    channel: TwilioVerificationChannelEnum;
}
/** Can be used if user is authenticated or unauthenticated */
export const useTwilioSendCodeMutation: (args?: ConfigurableAppMutationArgs) => UseMutationResult<any, Error, _SendValues2, void>;
export interface TwilioCheckCodeMutationArgs {
    value: string;
    code: string;
    channel: TwilioVerificationChannelEnum;
    auto_login_user?: boolean;
}
export interface TwilioCheckCodeCreateAccountValues extends TwilioCheckCodeMutationArgs {
    /**  Only required if creating a new account */
    first_name: string;
    /**  Only required if creating a new account */
    last_name: string;
    /**  Only required if creating a new account */
    password: string;
    /**  guest account created by default, can specify to create a host account */
    user_type_id?: UserRoleIDEnum;
}
export type TwilioCheckCodeSendValues = TwilioCheckCodeMutationArgs | TwilioCheckCodeCreateAccountValues;
/** Can be used if user is authenticated or unauthenticated */
export const useTwilioCheckCodeMutation: (args?: ConfigurableAppMutationArgs) => UseMutationResult<any, Error, TwilioCheckCodeSendValues, void>;
interface _Values5 {
    email: string;
}
export const useUserPasswordResetMutation: () => UseMutationResult<any, Error, _Values5, void>;
interface _Values6 {
    urlArgs: string[];
}
export const useUserCheckEmailExistsMutation: (props?: ConfigurableAppMutationArgs) => UseMutationResult<APIResponse<{
    IS_EMAIL_TAKEN: boolean;
}>, Error, _Values6, void>;
interface _Values7 {
    urlArgs: string[];
}
export const useUserCheckEmailTakenMutation: (props?: ConfigurableAppMutationArgs) => UseMutationResult<APIResponse<{
    is_email_taken: boolean;
}>, Error, _Values7, void>;
interface _Props1 {
    /** The bookingId is not required when editing a booking
     *  since we want to allow the dates that the booking is on to be available */
    bookingId?: number;
    isGuestRole: boolean;
    isOwnerRole: boolean;
    propertyId?: number;
    guestId?: number;
    isEnabled?: boolean;
    onSuccess?: () => void;
}
export const useUnavailableDates: ({ isOwnerRole, isGuestRole, bookingId, propertyId, guestId, isEnabled, onSuccess, }: _Props1) => QueryObserverRefetchErrorResult<_APIResponse1<UnavailableDatesResponse>, Error> | QueryObserverSuccessResult<_APIResponse1<UnavailableDatesResponse>, Error> | QueryObserverLoadingErrorResult<_APIResponse1<UnavailableDatesResponse>, Error> | QueryObserverPendingResult<_APIResponse1<UnavailableDatesResponse>, Error> | QueryObserverPlaceholderResult<_APIResponse1<UnavailableDatesResponse>, Error>;
export const useUserMessageContactQuery: ({ contactUserId, contactUserTypeId, propertyId, enabled, ...rest }: UserMessageContactArgs & ConfigurableAppQueryArgs<any>) => UseQueryResult<APIResponse<{
    CONTACT: User;
    LAST_RESERVATION_DATE: string;
    NEXT_RESERVATION_DATE: string;
    STATUS: string;
}>, Error>;
interface _Args25 {
    userId: number;
    userTypeId: UserRoleIDEnum;
    bookingId?: number;
    messageId?: number;
    enabled?: boolean;
    onSuccess?: (data?: any) => void;
}
export const useUserMessageSubject: ({ userId, userTypeId, bookingId, messageId, enabled, onSuccess, }: _Args25) => UseQueryResult<APIResponse<{
    SUBJECT: UserMessageSubject;
}>, Error>;
interface _Args26 {
    id: number;
    userTypeId: UserRoleIDEnum;
}
export const useUserMessageUnreadQuery: ({ id, userTypeId, enabled, ...rest }: _Args26 & ConfigurableAppQueryArgs<any>) => UseQueryResult<APIResponse<{
    USER_MESSAGE_COUNT: number;
}>, Error>;
interface _Args27 {
    email: string;
}
export const useUserCheckEmailTaken: ({ email, ...rest }: _Args27 & ConfigurableAppQueryArgs) => UseQueryResult<APIResponse<{
    IS_EMAIL_TAKEN: boolean;
}>, Error>;
interface QueryObject {
    queryKey: string | string[];
    endpoint: string;
    enabled?: boolean;
    select?: (data: any) => any;
    onSuccess?: (data: any) => void;
    onError?: (err: any) => void;
    onSettled?: (data: any | undefined, err: any) => void;
    retry?: boolean | number | ((failureCount: number, error: Error) => boolean) | undefined;
    staleTime?: number | undefined;
    cacheTime?: number | undefined;
    refetchOnWindowFocus?: boolean;
    refetchInterval?: number | false;
    hasToastsEnabled?: boolean;
}
interface _Args28 {
    queries: QueryObject[];
}
export const useAppQueries: ({ queries }: _Args28) => UseQueryResult<unknown, Error>[];
/** Use this function to create a new context with initial data, a context provider, and a hook that will consume the context  */
export function contextFactory<TProviderValue>(): {
    Context: React.Context<TProviderValue | null>;
    useContext: () => TProviderValue & ({} | undefined);
    ContextProvider: ({ children, value }: {
        children: React.ReactNode;
        value: TProviderValue;
    }) => React.ReactElement;
};
export interface UseToggleType {
    isOpen: boolean;
    toggle: () => void;
    close: () => void;
    open: () => void;
}
export const useToggle: (defaultState?: {
    isOpen: boolean;
}) => UseToggleType;
export interface UseSelectedToggleType<T> {
    isOpen: boolean;
    openWith: (val: T) => void;
    close: () => void;
    selectedValue: T | null;
}
export function useSelectedToggle<T>(initialValue?: T): UseSelectedToggleType<T>;
/** Use this function if the user cannot 'skip' over the next unbookable dates when selecting end
 * For example, there are a set of bookable dates which start and end are within.
 * The end date can be moved to the end of these set of dates but cannot select the next unavailable departure date or anything past that
 */
export const calculateDisabledAfterDateSelectingEnd: (unavailabilityDepartureDates: Date[], selectedEndDate: Date) => Date | undefined;
/** If the start date has moved and there is now an unbookable gap between the start and end date
 * Client needs to figure out how to handle this scenario.
 * Simple solution is to set departure to arrival when this occurs
 */
export const isUnbookableGapBetweenStartAndEnd: ({ arrival, departure, unavailabilityDepartureDates, }: {
    arrival: string;
    departure: string;
    unavailabilityDepartureDates: Date[];
}) => boolean;
export interface HandleDayClickArgs {
    day: Date;
    currentlySelecting: 'start' | 'end';
    setStartDate: (date: Date) => void;
    endDate: Date | undefined;
    setEndDate: (date: Date) => void;
    setCurrentlySelecting: (selecting: 'start' | 'end') => void;
    callback?: (selecting: 'start' | 'end', day: Date) => void;
    unavailabilityDeparture: Date[];
    onClickStart?: (day: Date, hasUnbookableGap: boolean) => void;
    onClickEnd?: (day: Date) => void;
}
export const handleDayClick: ({ day, currentlySelecting, setStartDate, endDate, setEndDate, callback, setCurrentlySelecting, unavailabilityDeparture, onClickEnd, onClickStart, }: HandleDayClickArgs) => void;
export interface CalculateDisabledDatesArgs {
    currentlySelecting: 'start' | 'end';
    unavailabilityDeparture: Date[];
    unavailabilityArrival: Date[];
    canSelectPastDates: boolean;
    endDate: Date | undefined;
    startDate: Date | undefined;
}
export interface CalculateDisabledDatesReturn {
    disabledDays: Date[];
    before?: Date;
    after?: Date;
}
export const calculateDisabledDates: ({ currentlySelecting, unavailabilityArrival, unavailabilityDeparture, canSelectPastDates, endDate, startDate, }: CalculateDisabledDatesArgs) => CalculateDisabledDatesReturn;
interface CalculateMinNightsDatesArgs {
    minNightsDates: {
        [key: string]: number;
    }[];
    startDate: Date | undefined;
}
export const calculateMinNightsDates: ({ startDate, minNightsDates }: CalculateMinNightsDatesArgs) => Date[];
export const calculateModifiers: ({ startDate, minNightsDates, endDate, }: CalculateMinNightsDatesArgs & {
    endDate: Date | undefined;
}) => {
    start: Date | undefined;
    end: Date | undefined;
    minNight: Date[];
};
export interface UseDateRangePickerArgs {
    initialStart?: Date;
    initialEnd?: Date;
    initialMonth?: Date;
    initialCurrentlySelecting?: 'start' | 'end';
    /** Formatted key: YYYY-MM-DD, value: <num_nights> */
    minNightsDates?: {
        [key: string]: number;
    }[];
    unavailabilityArrival?: Date[];
    unavailabilityDeparture?: Date[];
    canSelectPastDates?: boolean;
    onClickStart?: (day: Date, hasUnbookableGap: boolean) => void;
    onClickEnd?: (day: Date) => void;
}
export const useDateRangePicker: ({ initialStart, initialEnd, initialMonth, initialCurrentlySelecting, minNightsDates, unavailabilityDeparture, unavailabilityArrival, canSelectPastDates, onClickStart, onClickEnd, }: UseDateRangePickerArgs) => {
    startDate: Date | undefined;
    setStartDate: Dispatch<SetStateAction<Date | undefined>>;
    endDate: Date | undefined;
    setEndDate: Dispatch<SetStateAction<Date | undefined>>;
    currentlySelecting: "start" | "end";
    setCurrentlySelecting: Dispatch<SetStateAction<"start" | "end">>;
    onDayClick: (day: Date, callback?: (selecting: "start" | "end", day: Date) => void) => void;
    disabledDates: CalculateDisabledDatesReturn;
    modifiers: {
        start: Date | undefined;
        end: Date | undefined;
        minNight: Date[];
    };
    initialMonth: Date;
    nights: number;
    /** Re-export so we can pass the return of this hook to the component */
    unavailabilityArrival: Date[];
    unavailabilityDeparture: Date[];
    canSelectPastDates: boolean;
};
export type UseDateRangePickerReturn = ReturnType<typeof useDateRangePicker>;
interface _Props2 {
    children: React.ReactNode;
}
export const AccessToUnitFormikForm: ({ children }: _Props2) => JSX.Element;
export const accessToUnitFields: {
    /** Main access to unit settings */
    type: {
        label: string;
        field: string;
    };
    method: {
        label: string;
        field: string;
    };
    code: {
        label: string;
        field: string;
    };
    standardCode: {
        label: string;
        field: string;
    };
    /** Additional access codes */
    bike: {
        label: string;
        field: string;
    };
    /** building/development are used interchangeably here */
    building: {
        label: string;
        field: string;
    };
    gym: {
        label: string;
        field: string;
    };
    hottub: {
        label: string;
        field: string;
    };
    pool: {
        label: string;
        field: string;
    };
    sauna: {
        label: string;
        field: string;
    };
    steamroom: {
        label: string;
        field: string;
    };
    recRoom: {
        label: string;
        field: string;
    };
    garage: {
        label: string;
        field: string;
    };
    garbage: {
        label: string;
        field: string;
    };
    ski: {
        label: string;
        field: string;
    };
    /** Internet codes */
    internetName: {
        label: string;
        field: string;
    };
    internetPassword: {
        label: string;
        field: string;
    };
};
export const generateAccessToUnitValues: (property: Property) => {
    AccessToUnitForm: {
        ACCESS_TO_UNIT: {
            CODES: {
                BIKE_LOCKER_CODE: string;
                DEVELOPMENT_DOOR_CODE: string;
                DEVELOPMENT_GYM_CODE: string;
                DEVELOPMENT_HOT_TUB_CODE: string;
                DEVELOPMENT_POOL_CODE: string;
                DEVELOPMENT_SAUNA_CODE: string;
                DEVELOPMENT_STEAM_ROOM_CODE: string;
                FRONT_DOOR_CODE: string;
                GAMES_REC_ROOM_CODE: string;
                GARAGE_DOOR_CODE: string;
                GARBAGE_RECYCLING_CODE: string;
                ID: number;
                INTERNET_NETWORK_NAME: string;
                INTERNET_PASSWORD: string;
                PHONE_NUMBER: string;
                PROPERTY_ID: string;
                SKI_LOCKER_CODE: string;
                DATE_LAST_UPDATED: string;
            };
            CHECK_IN_PROCEDURE: string;
            CODE: {
                NAME: string;
                ID: _AccessCodeIdEnum1;
            };
            METHOD: {
                NAME: string;
                ID: _AccessMethodIdEnum1;
            };
            STANDARD_CODE: string;
            TYPE: {
                NAME: string;
                ID: _AccessCodeTypeIDEnum1;
            };
        };
    };
};
export type AccessToUnitFormikValues = ReturnType<typeof generateAccessToUnitValues>;
export const amenityEditFields: {
    wifiName: {
        label: string;
        field: string;
    };
    wifiPassword: {
        label: string;
        field: string;
    };
};
export const generateCheckInOutFields: (subformName: RequiredSubformsEnum.CheckInOutForm | OptionalSubformsEnum.CheckInOutFormOptional) => {
    buildingCode: {
        label: string;
        field: string;
    };
    garbageCode: {
        label: string;
        field: string;
    };
    checkIn: {
        label: string;
        field: string;
    };
    checkOut: {
        label: string;
        field: string;
    };
    /** RTE fields */
    checkInProcedure: {
        label: string;
        field: string;
    };
    lateCheckInProcedure: {
        label: string;
        field: string;
    };
    checkOutProcedure: {
        label: string;
        field: string;
    };
    garbageRecyclingInstructions: {
        label: string;
        field: string;
    };
};
export const generateCheckInOutValues: (propertyObject: Property, subformName: RequiredSubformsEnum.CheckInOutForm | OptionalSubformsEnum.CheckInOutFormOptional) => {
    [x: string]: {
        RULES: {
            ID: number;
            ADVANCED_BOOKING: {
                NAME: string;
                ID: number;
            };
            CHECK_IN: string;
            CHECK_OUT: string;
            MAX_BOOKABLE_DAYS: number;
            MAX_GUESTS: number;
            MIN_AGE_TO_BOOK: number;
            QUIET_TIME: string;
        };
        INSTRUCTIONS: {
            LATE_CHECK_IN: string;
            CHECK_IN: string;
            CHECK_OUT: string;
            GARBAGE_RECYCLING: string;
        };
        CODES: {
            DEVELOPMENT_DOOR_CODE: string;
            GARBAGE_RECYCLING_CODE: string;
        };
    };
};
export const messages: {
    requiredValue: string;
    requiredNumber: string;
    shortNumber: string;
    longNumber: string;
    longString: string;
    shortString: string;
    invalidTime: string;
    invalidPhone: string;
    invalidEmail: string;
    unselectedOption: string;
    maxString: string;
    /** You must only provide 500 characters */
    maxStringDefined: (length: number) => string;
    maxString2500: string;
    maxString5000: string;
    minNumber: string;
    maxNumber: string;
};
export const stringNewlinesToBrTags: (text: string) => string;
export function toDecimal(text: string, decimalPlaces?: number): string;
export function hasContent(str: string): boolean;
export const truncate: (text: string, length: number) => string;
export const handleStripHTML: (str: string) => string;
export const isStringHTMLString: (str: string) => boolean;
export const handleStripHTMLAndSpaces: (string: string) => string;
/**  Turn a string into first-letter of each word capitalized, rest lowercase form
 *  Example: "TEST" -> "Test", "abc" -> "Abc", "all right" -> "All Right"
 */
export function capitalize(str: string): string;
export const snakeCaseToSpace: (s: string) => string;
export function pluralize(count: number, text: string, pluralizationAffix?: string): string;
/** This is used when looking to provide a singular or plural display. For instance 1 Bathroom vs 2 Bathrooms */
export function generateCountString(count: number, text: string, pluralizationAffix?: string): string;
export const email: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
export const boolean: RequiredBooleanSchema<boolean | null | undefined, AnyObject>;
export const MAX_ACCESS_CODE_LENGTH = 50;
export const accessCode: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
export const streetName: RequiredStringSchema<string | undefined, AnyObject>;
export const streetNumber: RequiredStringSchema<string | undefined, AnyObject>;
export const city: RequiredStringSchema<string | undefined, AnyObject>;
export const country: RequiredStringSchema<string | undefined, AnyObject>;
export const unit: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
export const htmlNotRequired: (maxLength?: number) => yup.StringSchema<string | undefined, AnyObject, string | undefined>;
export const htmlRequired: (maxLength?: number) => yup.StringSchema<string | undefined, AnyObject, string | undefined>;
export const name: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
export const instruction: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
export const description: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
export const phone: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
export const messageSchema: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
export const currency: RequiredNumberSchema<number | undefined, AnyObject>;
export const squareFeet: RequiredNumberSchema<number | undefined, AnyObject>;
export const requiredString: RequiredStringSchema<string | undefined, AnyObject>;
export const id: yup.NumberSchema<number | undefined, AnyObject, number | undefined>;
export const stringID: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
export const maxString2500: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
export const maxString5000: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
export const taxString: RequiredStringSchema<string | undefined, AnyObject>;
export const time: RequiredStringSchema<string | undefined, AnyObject>;
export const twentyFourHourTime: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
export const positiveNumber: RequiredNumberSchema<number | undefined, AnyObject>;
export const number: RequiredNumberSchema<number | undefined, AnyObject>;
export const minAge: RequiredNumberSchema<number | undefined, AnyObject>;
export const url: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
export const addressValidation: {
    STREET_NAME: RequiredStringSchema<string | undefined, AnyObject>;
    STREET_NUMBER: RequiredStringSchema<string | undefined, AnyObject>;
    UNIT: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
    CITY: RequiredStringSchema<string | undefined, AnyObject>;
    POSTAL: RequiredStringSchema<string | undefined, AnyObject>;
    REGION: RequiredStringSchema<string | undefined, AnyObject>;
    COUNTRY: RequiredStringSchema<string | undefined, AnyObject>;
};
export const buttonGroupValidation: {
    ID: yup.NumberSchema<number | undefined, AnyObject, number | undefined>;
    NAME: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
};
export const buttonGroupValidationNotRequired: {
    ID: yup.NumberSchema<number | undefined, AnyObject, number | undefined>;
    NAME: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
};
export const idNameValidation: {
    ID: RequiredStringSchema<string | undefined, AnyObject>;
    NAME: RequiredStringSchema<string | undefined, AnyObject>;
};
export const numberRegExp: RegExp;
export const rateGroup: {
    BASE_RATE: RequiredNumberSchema<number | undefined, AnyObject>;
    MIN_NIGHTS: RequiredNumberSchema<number | undefined, AnyObject>;
};
export const suitability: yup.ObjectSchema<Assign<ObjectShape, {
    IS_SUITABLE: RequiredBooleanSchema<boolean | undefined, AnyObject>;
    NAME: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
    DESCRIPTION: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
    ID: RequiredNumberSchema<number | undefined, AnyObject>;
}>, _AnyObject1, TypeOfShape<Assign<ObjectShape, {
    IS_SUITABLE: RequiredBooleanSchema<boolean | undefined, AnyObject>;
    NAME: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
    DESCRIPTION: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
    ID: RequiredNumberSchema<number | undefined, AnyObject>;
}>>, AssertsShape<Assign<ObjectShape, {
    IS_SUITABLE: RequiredBooleanSchema<boolean | undefined, AnyObject>;
    NAME: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
    DESCRIPTION: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
    ID: RequiredNumberSchema<number | undefined, AnyObject>;
}>>>;
export const amenityDescription: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
export const amenityInstructions: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
export const amenitySchema: yup.ObjectSchema<Assign<ObjectShape, {
    INSTRUCTIONS: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
    DESCRIPTION: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
    ACCESS_CODE: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
    INTERNET_NETWORK_NAME: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
    INTERNET_PASSWORD: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
}>, _AnyObject1, TypeOfShape<Assign<ObjectShape, {
    INSTRUCTIONS: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
    DESCRIPTION: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
    ACCESS_CODE: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
    INTERNET_NETWORK_NAME: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
    INTERNET_PASSWORD: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
}>>, AssertsShape<Assign<ObjectShape, {
    INSTRUCTIONS: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
    DESCRIPTION: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
    ACCESS_CODE: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
    INTERNET_NETWORK_NAME: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
    INTERNET_PASSWORD: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
}>>>;
export const numericValidationRegex: RegExp;
export const accountOwner: {
    AccountOwnerForm: yup.ObjectSchema<Assign<ObjectShape, {
        USER: yup.ObjectSchema<Assign<ObjectShape, {
            IS_COMPANY: RequiredBooleanSchema<boolean | null | undefined, AnyObject>;
            COMPANY_NAME: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            FIRST_NAME: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            LAST_NAME: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            EMAIL: RequiredStringSchema<string | undefined, AnyObject>;
            PHONE: RequiredStringSchema<string | undefined, AnyObject>;
            IS_SMS_VERIFIED: RequiredBooleanSchema<boolean | undefined, AnyObject>;
            IS_EMAIL_VERIFIED: RequiredBooleanSchema<boolean | undefined, AnyObject>;
            ADDRESS: yup.ObjectSchema<Assign<ObjectShape, {
                STREET_NAME: RequiredStringSchema<string | undefined, AnyObject>;
                STREET_NUMBER: RequiredStringSchema<string | undefined, AnyObject>;
                UNIT: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
                CITY: RequiredStringSchema<string | undefined, AnyObject>;
                POSTAL: RequiredStringSchema<string | undefined, AnyObject>;
                REGION: RequiredStringSchema<string | undefined, AnyObject>;
                COUNTRY: RequiredStringSchema<string | undefined, AnyObject>;
            }>, _AnyObject1, TypeOfShape<Assign<ObjectShape, {
                STREET_NAME: RequiredStringSchema<string | undefined, AnyObject>;
                STREET_NUMBER: RequiredStringSchema<string | undefined, AnyObject>;
                UNIT: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
                CITY: RequiredStringSchema<string | undefined, AnyObject>;
                POSTAL: RequiredStringSchema<string | undefined, AnyObject>;
                REGION: RequiredStringSchema<string | undefined, AnyObject>;
                COUNTRY: RequiredStringSchema<string | undefined, AnyObject>;
            }>>, AssertsShape<Assign<ObjectShape, {
                STREET_NAME: RequiredStringSchema<string | undefined, AnyObject>;
                STREET_NUMBER: RequiredStringSchema<string | undefined, AnyObject>;
                UNIT: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
                CITY: RequiredStringSchema<string | undefined, AnyObject>;
                POSTAL: RequiredStringSchema<string | undefined, AnyObject>;
                REGION: RequiredStringSchema<string | undefined, AnyObject>;
                COUNTRY: RequiredStringSchema<string | undefined, AnyObject>;
            }>>>;
        }>, _AnyObject1, TypeOfShape<Assign<ObjectShape, {
            IS_COMPANY: RequiredBooleanSchema<boolean | null | undefined, AnyObject>;
            COMPANY_NAME: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            FIRST_NAME: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            LAST_NAME: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            EMAIL: RequiredStringSchema<string | undefined, AnyObject>;
            PHONE: RequiredStringSchema<string | undefined, AnyObject>;
            IS_SMS_VERIFIED: RequiredBooleanSchema<boolean | undefined, AnyObject>;
            IS_EMAIL_VERIFIED: RequiredBooleanSchema<boolean | undefined, AnyObject>;
            ADDRESS: yup.ObjectSchema<Assign<ObjectShape, {
                STREET_NAME: RequiredStringSchema<string | undefined, AnyObject>;
                STREET_NUMBER: RequiredStringSchema<string | undefined, AnyObject>;
                UNIT: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
                CITY: RequiredStringSchema<string | undefined, AnyObject>;
                POSTAL: RequiredStringSchema<string | undefined, AnyObject>;
                REGION: RequiredStringSchema<string | undefined, AnyObject>;
                COUNTRY: RequiredStringSchema<string | undefined, AnyObject>;
            }>, _AnyObject1, TypeOfShape<Assign<ObjectShape, {
                STREET_NAME: RequiredStringSchema<string | undefined, AnyObject>;
                STREET_NUMBER: RequiredStringSchema<string | undefined, AnyObject>;
                UNIT: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
                CITY: RequiredStringSchema<string | undefined, AnyObject>;
                POSTAL: RequiredStringSchema<string | undefined, AnyObject>;
                REGION: RequiredStringSchema<string | undefined, AnyObject>;
                COUNTRY: RequiredStringSchema<string | undefined, AnyObject>;
            }>>, AssertsShape<Assign<ObjectShape, {
                STREET_NAME: RequiredStringSchema<string | undefined, AnyObject>;
                STREET_NUMBER: RequiredStringSchema<string | undefined, AnyObject>;
                UNIT: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
                CITY: RequiredStringSchema<string | undefined, AnyObject>;
                POSTAL: RequiredStringSchema<string | undefined, AnyObject>;
                REGION: RequiredStringSchema<string | undefined, AnyObject>;
                COUNTRY: RequiredStringSchema<string | undefined, AnyObject>;
            }>>>;
        }>>, AssertsShape<Assign<ObjectShape, {
            IS_COMPANY: RequiredBooleanSchema<boolean | null | undefined, AnyObject>;
            COMPANY_NAME: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            FIRST_NAME: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            LAST_NAME: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            EMAIL: RequiredStringSchema<string | undefined, AnyObject>;
            PHONE: RequiredStringSchema<string | undefined, AnyObject>;
            IS_SMS_VERIFIED: RequiredBooleanSchema<boolean | undefined, AnyObject>;
            IS_EMAIL_VERIFIED: RequiredBooleanSchema<boolean | undefined, AnyObject>;
            ADDRESS: yup.ObjectSchema<Assign<ObjectShape, {
                STREET_NAME: RequiredStringSchema<string | undefined, AnyObject>;
                STREET_NUMBER: RequiredStringSchema<string | undefined, AnyObject>;
                UNIT: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
                CITY: RequiredStringSchema<string | undefined, AnyObject>;
                POSTAL: RequiredStringSchema<string | undefined, AnyObject>;
                REGION: RequiredStringSchema<string | undefined, AnyObject>;
                COUNTRY: RequiredStringSchema<string | undefined, AnyObject>;
            }>, _AnyObject1, TypeOfShape<Assign<ObjectShape, {
                STREET_NAME: RequiredStringSchema<string | undefined, AnyObject>;
                STREET_NUMBER: RequiredStringSchema<string | undefined, AnyObject>;
                UNIT: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
                CITY: RequiredStringSchema<string | undefined, AnyObject>;
                POSTAL: RequiredStringSchema<string | undefined, AnyObject>;
                REGION: RequiredStringSchema<string | undefined, AnyObject>;
                COUNTRY: RequiredStringSchema<string | undefined, AnyObject>;
            }>>, AssertsShape<Assign<ObjectShape, {
                STREET_NAME: RequiredStringSchema<string | undefined, AnyObject>;
                STREET_NUMBER: RequiredStringSchema<string | undefined, AnyObject>;
                UNIT: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
                CITY: RequiredStringSchema<string | undefined, AnyObject>;
                POSTAL: RequiredStringSchema<string | undefined, AnyObject>;
                REGION: RequiredStringSchema<string | undefined, AnyObject>;
                COUNTRY: RequiredStringSchema<string | undefined, AnyObject>;
            }>>>;
        }>>>;
    }>, _AnyObject1, TypeOfShape<Assign<ObjectShape, {
        USER: yup.ObjectSchema<Assign<ObjectShape, {
            IS_COMPANY: RequiredBooleanSchema<boolean | null | undefined, AnyObject>;
            COMPANY_NAME: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            FIRST_NAME: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            LAST_NAME: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            EMAIL: RequiredStringSchema<string | undefined, AnyObject>;
            PHONE: RequiredStringSchema<string | undefined, AnyObject>;
            IS_SMS_VERIFIED: RequiredBooleanSchema<boolean | undefined, AnyObject>;
            IS_EMAIL_VERIFIED: RequiredBooleanSchema<boolean | undefined, AnyObject>;
            ADDRESS: yup.ObjectSchema<Assign<ObjectShape, {
                STREET_NAME: RequiredStringSchema<string | undefined, AnyObject>;
                STREET_NUMBER: RequiredStringSchema<string | undefined, AnyObject>;
                UNIT: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
                CITY: RequiredStringSchema<string | undefined, AnyObject>;
                POSTAL: RequiredStringSchema<string | undefined, AnyObject>;
                REGION: RequiredStringSchema<string | undefined, AnyObject>;
                COUNTRY: RequiredStringSchema<string | undefined, AnyObject>;
            }>, _AnyObject1, TypeOfShape<Assign<ObjectShape, {
                STREET_NAME: RequiredStringSchema<string | undefined, AnyObject>;
                STREET_NUMBER: RequiredStringSchema<string | undefined, AnyObject>;
                UNIT: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
                CITY: RequiredStringSchema<string | undefined, AnyObject>;
                POSTAL: RequiredStringSchema<string | undefined, AnyObject>;
                REGION: RequiredStringSchema<string | undefined, AnyObject>;
                COUNTRY: RequiredStringSchema<string | undefined, AnyObject>;
            }>>, AssertsShape<Assign<ObjectShape, {
                STREET_NAME: RequiredStringSchema<string | undefined, AnyObject>;
                STREET_NUMBER: RequiredStringSchema<string | undefined, AnyObject>;
                UNIT: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
                CITY: RequiredStringSchema<string | undefined, AnyObject>;
                POSTAL: RequiredStringSchema<string | undefined, AnyObject>;
                REGION: RequiredStringSchema<string | undefined, AnyObject>;
                COUNTRY: RequiredStringSchema<string | undefined, AnyObject>;
            }>>>;
        }>, _AnyObject1, TypeOfShape<Assign<ObjectShape, {
            IS_COMPANY: RequiredBooleanSchema<boolean | null | undefined, AnyObject>;
            COMPANY_NAME: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            FIRST_NAME: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            LAST_NAME: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            EMAIL: RequiredStringSchema<string | undefined, AnyObject>;
            PHONE: RequiredStringSchema<string | undefined, AnyObject>;
            IS_SMS_VERIFIED: RequiredBooleanSchema<boolean | undefined, AnyObject>;
            IS_EMAIL_VERIFIED: RequiredBooleanSchema<boolean | undefined, AnyObject>;
            ADDRESS: yup.ObjectSchema<Assign<ObjectShape, {
                STREET_NAME: RequiredStringSchema<string | undefined, AnyObject>;
                STREET_NUMBER: RequiredStringSchema<string | undefined, AnyObject>;
                UNIT: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
                CITY: RequiredStringSchema<string | undefined, AnyObject>;
                POSTAL: RequiredStringSchema<string | undefined, AnyObject>;
                REGION: RequiredStringSchema<string | undefined, AnyObject>;
                COUNTRY: RequiredStringSchema<string | undefined, AnyObject>;
            }>, _AnyObject1, TypeOfShape<Assign<ObjectShape, {
                STREET_NAME: RequiredStringSchema<string | undefined, AnyObject>;
                STREET_NUMBER: RequiredStringSchema<string | undefined, AnyObject>;
                UNIT: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
                CITY: RequiredStringSchema<string | undefined, AnyObject>;
                POSTAL: RequiredStringSchema<string | undefined, AnyObject>;
                REGION: RequiredStringSchema<string | undefined, AnyObject>;
                COUNTRY: RequiredStringSchema<string | undefined, AnyObject>;
            }>>, AssertsShape<Assign<ObjectShape, {
                STREET_NAME: RequiredStringSchema<string | undefined, AnyObject>;
                STREET_NUMBER: RequiredStringSchema<string | undefined, AnyObject>;
                UNIT: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
                CITY: RequiredStringSchema<string | undefined, AnyObject>;
                POSTAL: RequiredStringSchema<string | undefined, AnyObject>;
                REGION: RequiredStringSchema<string | undefined, AnyObject>;
                COUNTRY: RequiredStringSchema<string | undefined, AnyObject>;
            }>>>;
        }>>, AssertsShape<Assign<ObjectShape, {
            IS_COMPANY: RequiredBooleanSchema<boolean | null | undefined, AnyObject>;
            COMPANY_NAME: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            FIRST_NAME: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            LAST_NAME: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            EMAIL: RequiredStringSchema<string | undefined, AnyObject>;
            PHONE: RequiredStringSchema<string | undefined, AnyObject>;
            IS_SMS_VERIFIED: RequiredBooleanSchema<boolean | undefined, AnyObject>;
            IS_EMAIL_VERIFIED: RequiredBooleanSchema<boolean | undefined, AnyObject>;
            ADDRESS: yup.ObjectSchema<Assign<ObjectShape, {
                STREET_NAME: RequiredStringSchema<string | undefined, AnyObject>;
                STREET_NUMBER: RequiredStringSchema<string | undefined, AnyObject>;
                UNIT: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
                CITY: RequiredStringSchema<string | undefined, AnyObject>;
                POSTAL: RequiredStringSchema<string | undefined, AnyObject>;
                REGION: RequiredStringSchema<string | undefined, AnyObject>;
                COUNTRY: RequiredStringSchema<string | undefined, AnyObject>;
            }>, _AnyObject1, TypeOfShape<Assign<ObjectShape, {
                STREET_NAME: RequiredStringSchema<string | undefined, AnyObject>;
                STREET_NUMBER: RequiredStringSchema<string | undefined, AnyObject>;
                UNIT: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
                CITY: RequiredStringSchema<string | undefined, AnyObject>;
                POSTAL: RequiredStringSchema<string | undefined, AnyObject>;
                REGION: RequiredStringSchema<string | undefined, AnyObject>;
                COUNTRY: RequiredStringSchema<string | undefined, AnyObject>;
            }>>, AssertsShape<Assign<ObjectShape, {
                STREET_NAME: RequiredStringSchema<string | undefined, AnyObject>;
                STREET_NUMBER: RequiredStringSchema<string | undefined, AnyObject>;
                UNIT: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
                CITY: RequiredStringSchema<string | undefined, AnyObject>;
                POSTAL: RequiredStringSchema<string | undefined, AnyObject>;
                REGION: RequiredStringSchema<string | undefined, AnyObject>;
                COUNTRY: RequiredStringSchema<string | undefined, AnyObject>;
            }>>>;
        }>>>;
    }>>, AssertsShape<Assign<ObjectShape, {
        USER: yup.ObjectSchema<Assign<ObjectShape, {
            IS_COMPANY: RequiredBooleanSchema<boolean | null | undefined, AnyObject>;
            COMPANY_NAME: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            FIRST_NAME: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            LAST_NAME: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            EMAIL: RequiredStringSchema<string | undefined, AnyObject>;
            PHONE: RequiredStringSchema<string | undefined, AnyObject>;
            IS_SMS_VERIFIED: RequiredBooleanSchema<boolean | undefined, AnyObject>;
            IS_EMAIL_VERIFIED: RequiredBooleanSchema<boolean | undefined, AnyObject>;
            ADDRESS: yup.ObjectSchema<Assign<ObjectShape, {
                STREET_NAME: RequiredStringSchema<string | undefined, AnyObject>;
                STREET_NUMBER: RequiredStringSchema<string | undefined, AnyObject>;
                UNIT: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
                CITY: RequiredStringSchema<string | undefined, AnyObject>;
                POSTAL: RequiredStringSchema<string | undefined, AnyObject>;
                REGION: RequiredStringSchema<string | undefined, AnyObject>;
                COUNTRY: RequiredStringSchema<string | undefined, AnyObject>;
            }>, _AnyObject1, TypeOfShape<Assign<ObjectShape, {
                STREET_NAME: RequiredStringSchema<string | undefined, AnyObject>;
                STREET_NUMBER: RequiredStringSchema<string | undefined, AnyObject>;
                UNIT: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
                CITY: RequiredStringSchema<string | undefined, AnyObject>;
                POSTAL: RequiredStringSchema<string | undefined, AnyObject>;
                REGION: RequiredStringSchema<string | undefined, AnyObject>;
                COUNTRY: RequiredStringSchema<string | undefined, AnyObject>;
            }>>, AssertsShape<Assign<ObjectShape, {
                STREET_NAME: RequiredStringSchema<string | undefined, AnyObject>;
                STREET_NUMBER: RequiredStringSchema<string | undefined, AnyObject>;
                UNIT: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
                CITY: RequiredStringSchema<string | undefined, AnyObject>;
                POSTAL: RequiredStringSchema<string | undefined, AnyObject>;
                REGION: RequiredStringSchema<string | undefined, AnyObject>;
                COUNTRY: RequiredStringSchema<string | undefined, AnyObject>;
            }>>>;
        }>, _AnyObject1, TypeOfShape<Assign<ObjectShape, {
            IS_COMPANY: RequiredBooleanSchema<boolean | null | undefined, AnyObject>;
            COMPANY_NAME: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            FIRST_NAME: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            LAST_NAME: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            EMAIL: RequiredStringSchema<string | undefined, AnyObject>;
            PHONE: RequiredStringSchema<string | undefined, AnyObject>;
            IS_SMS_VERIFIED: RequiredBooleanSchema<boolean | undefined, AnyObject>;
            IS_EMAIL_VERIFIED: RequiredBooleanSchema<boolean | undefined, AnyObject>;
            ADDRESS: yup.ObjectSchema<Assign<ObjectShape, {
                STREET_NAME: RequiredStringSchema<string | undefined, AnyObject>;
                STREET_NUMBER: RequiredStringSchema<string | undefined, AnyObject>;
                UNIT: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
                CITY: RequiredStringSchema<string | undefined, AnyObject>;
                POSTAL: RequiredStringSchema<string | undefined, AnyObject>;
                REGION: RequiredStringSchema<string | undefined, AnyObject>;
                COUNTRY: RequiredStringSchema<string | undefined, AnyObject>;
            }>, _AnyObject1, TypeOfShape<Assign<ObjectShape, {
                STREET_NAME: RequiredStringSchema<string | undefined, AnyObject>;
                STREET_NUMBER: RequiredStringSchema<string | undefined, AnyObject>;
                UNIT: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
                CITY: RequiredStringSchema<string | undefined, AnyObject>;
                POSTAL: RequiredStringSchema<string | undefined, AnyObject>;
                REGION: RequiredStringSchema<string | undefined, AnyObject>;
                COUNTRY: RequiredStringSchema<string | undefined, AnyObject>;
            }>>, AssertsShape<Assign<ObjectShape, {
                STREET_NAME: RequiredStringSchema<string | undefined, AnyObject>;
                STREET_NUMBER: RequiredStringSchema<string | undefined, AnyObject>;
                UNIT: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
                CITY: RequiredStringSchema<string | undefined, AnyObject>;
                POSTAL: RequiredStringSchema<string | undefined, AnyObject>;
                REGION: RequiredStringSchema<string | undefined, AnyObject>;
                COUNTRY: RequiredStringSchema<string | undefined, AnyObject>;
            }>>>;
        }>>, AssertsShape<Assign<ObjectShape, {
            IS_COMPANY: RequiredBooleanSchema<boolean | null | undefined, AnyObject>;
            COMPANY_NAME: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            FIRST_NAME: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            LAST_NAME: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            EMAIL: RequiredStringSchema<string | undefined, AnyObject>;
            PHONE: RequiredStringSchema<string | undefined, AnyObject>;
            IS_SMS_VERIFIED: RequiredBooleanSchema<boolean | undefined, AnyObject>;
            IS_EMAIL_VERIFIED: RequiredBooleanSchema<boolean | undefined, AnyObject>;
            ADDRESS: yup.ObjectSchema<Assign<ObjectShape, {
                STREET_NAME: RequiredStringSchema<string | undefined, AnyObject>;
                STREET_NUMBER: RequiredStringSchema<string | undefined, AnyObject>;
                UNIT: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
                CITY: RequiredStringSchema<string | undefined, AnyObject>;
                POSTAL: RequiredStringSchema<string | undefined, AnyObject>;
                REGION: RequiredStringSchema<string | undefined, AnyObject>;
                COUNTRY: RequiredStringSchema<string | undefined, AnyObject>;
            }>, _AnyObject1, TypeOfShape<Assign<ObjectShape, {
                STREET_NAME: RequiredStringSchema<string | undefined, AnyObject>;
                STREET_NUMBER: RequiredStringSchema<string | undefined, AnyObject>;
                UNIT: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
                CITY: RequiredStringSchema<string | undefined, AnyObject>;
                POSTAL: RequiredStringSchema<string | undefined, AnyObject>;
                REGION: RequiredStringSchema<string | undefined, AnyObject>;
                COUNTRY: RequiredStringSchema<string | undefined, AnyObject>;
            }>>, AssertsShape<Assign<ObjectShape, {
                STREET_NAME: RequiredStringSchema<string | undefined, AnyObject>;
                STREET_NUMBER: RequiredStringSchema<string | undefined, AnyObject>;
                UNIT: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
                CITY: RequiredStringSchema<string | undefined, AnyObject>;
                POSTAL: RequiredStringSchema<string | undefined, AnyObject>;
                REGION: RequiredStringSchema<string | undefined, AnyObject>;
                COUNTRY: RequiredStringSchema<string | undefined, AnyObject>;
            }>>>;
        }>>>;
    }>>>;
};
export const rentalManagerCoHost: {
    PropertyContactForm: yup.ObjectSchema<Assign<ObjectShape, {
        IS_CUSTOM_PROPERTY_CONTACT: RequiredBooleanSchema<boolean | undefined, AnyObject>;
        PROPERTY_CONTACT: OptionalObjectSchema<ObjectShape, _AnyObject1, TypeOfShape<ObjectShape>>;
        IS_CO_HOST_MANAGER_ENABLED: RequiredBooleanSchema<boolean | undefined, AnyObject>;
        CO_HOST: OptionalObjectSchema<ObjectShape, _AnyObject1, TypeOfShape<ObjectShape>>;
    }>, _AnyObject1, TypeOfShape<Assign<ObjectShape, {
        IS_CUSTOM_PROPERTY_CONTACT: RequiredBooleanSchema<boolean | undefined, AnyObject>;
        PROPERTY_CONTACT: OptionalObjectSchema<ObjectShape, _AnyObject1, TypeOfShape<ObjectShape>>;
        IS_CO_HOST_MANAGER_ENABLED: RequiredBooleanSchema<boolean | undefined, AnyObject>;
        CO_HOST: OptionalObjectSchema<ObjectShape, _AnyObject1, TypeOfShape<ObjectShape>>;
    }>>, AssertsShape<Assign<ObjectShape, {
        IS_CUSTOM_PROPERTY_CONTACT: RequiredBooleanSchema<boolean | undefined, AnyObject>;
        PROPERTY_CONTACT: OptionalObjectSchema<ObjectShape, _AnyObject1, TypeOfShape<ObjectShape>>;
        IS_CO_HOST_MANAGER_ENABLED: RequiredBooleanSchema<boolean | undefined, AnyObject>;
        CO_HOST: OptionalObjectSchema<ObjectShape, _AnyObject1, TypeOfShape<ObjectShape>>;
    }>>>;
};
export const minPhotos = 5;
export const photos: {
    PhotosForm: yup.ObjectSchema<Assign<ObjectShape, {
        EXTERNAL_URLS: yup.ObjectSchema<Assign<ObjectShape, {
            URL_AIRBNB: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            URL_VRBO: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            URL_OTHER: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
        }>, _AnyObject1, TypeOfShape<Assign<ObjectShape, {
            URL_AIRBNB: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            URL_VRBO: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            URL_OTHER: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
        }>>, AssertsShape<Assign<ObjectShape, {
            URL_AIRBNB: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            URL_VRBO: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            URL_OTHER: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
        }>>>;
        NUM_PHOTOS: yup.NumberSchema<number | undefined, AnyObject, number | undefined>;
    }>, _AnyObject1, TypeOfShape<Assign<ObjectShape, {
        EXTERNAL_URLS: yup.ObjectSchema<Assign<ObjectShape, {
            URL_AIRBNB: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            URL_VRBO: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            URL_OTHER: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
        }>, _AnyObject1, TypeOfShape<Assign<ObjectShape, {
            URL_AIRBNB: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            URL_VRBO: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            URL_OTHER: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
        }>>, AssertsShape<Assign<ObjectShape, {
            URL_AIRBNB: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            URL_VRBO: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            URL_OTHER: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
        }>>>;
        NUM_PHOTOS: yup.NumberSchema<number | undefined, AnyObject, number | undefined>;
    }>>, AssertsShape<Assign<ObjectShape, {
        EXTERNAL_URLS: yup.ObjectSchema<Assign<ObjectShape, {
            URL_AIRBNB: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            URL_VRBO: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            URL_OTHER: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
        }>, _AnyObject1, TypeOfShape<Assign<ObjectShape, {
            URL_AIRBNB: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            URL_VRBO: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            URL_OTHER: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
        }>>, AssertsShape<Assign<ObjectShape, {
            URL_AIRBNB: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            URL_VRBO: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            URL_OTHER: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
        }>>>;
        NUM_PHOTOS: yup.NumberSchema<number | undefined, AnyObject, number | undefined>;
    }>>>;
};
export const parkingFormSchema: {
    ParkingForm: OptionalObjectSchema<{
        PARKING: yup.ObjectSchema<Assign<ObjectShape, {
            DESCRIPTION: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            INSTRUCTIONS: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            HAS_ADDITIONAL_FREE_SPOTS: RequiredBooleanSchema<boolean | null | undefined, AnyObject>;
            HAS_ADDITIONAL_PAID_SPOTS: RequiredBooleanSchema<boolean | null | undefined, AnyObject>;
            NUM_SPOTS_PROVIDED: RequiredNumberSchema<number | undefined, AnyObject>;
            IS_DEFAULT_DESCRIPTION: RequiredBooleanSchema<boolean | undefined, AnyObject>;
            CODES: yup.ObjectSchema<Assign<ObjectShape, {
                GARAGE_DOOR_CODE: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            }>, _AnyObject1, TypeOfShape<Assign<ObjectShape, {
                GARAGE_DOOR_CODE: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            }>>, AssertsShape<Assign<ObjectShape, {
                GARAGE_DOOR_CODE: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            }>>>;
        }>, _AnyObject1, TypeOfShape<Assign<ObjectShape, {
            DESCRIPTION: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            INSTRUCTIONS: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            HAS_ADDITIONAL_FREE_SPOTS: RequiredBooleanSchema<boolean | null | undefined, AnyObject>;
            HAS_ADDITIONAL_PAID_SPOTS: RequiredBooleanSchema<boolean | null | undefined, AnyObject>;
            NUM_SPOTS_PROVIDED: RequiredNumberSchema<number | undefined, AnyObject>;
            IS_DEFAULT_DESCRIPTION: RequiredBooleanSchema<boolean | undefined, AnyObject>;
            CODES: yup.ObjectSchema<Assign<ObjectShape, {
                GARAGE_DOOR_CODE: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            }>, _AnyObject1, TypeOfShape<Assign<ObjectShape, {
                GARAGE_DOOR_CODE: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            }>>, AssertsShape<Assign<ObjectShape, {
                GARAGE_DOOR_CODE: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            }>>>;
        }>>, AssertsShape<Assign<ObjectShape, {
            DESCRIPTION: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            INSTRUCTIONS: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            HAS_ADDITIONAL_FREE_SPOTS: RequiredBooleanSchema<boolean | null | undefined, AnyObject>;
            HAS_ADDITIONAL_PAID_SPOTS: RequiredBooleanSchema<boolean | null | undefined, AnyObject>;
            NUM_SPOTS_PROVIDED: RequiredNumberSchema<number | undefined, AnyObject>;
            IS_DEFAULT_DESCRIPTION: RequiredBooleanSchema<boolean | undefined, AnyObject>;
            CODES: yup.ObjectSchema<Assign<ObjectShape, {
                GARAGE_DOOR_CODE: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            }>, _AnyObject1, TypeOfShape<Assign<ObjectShape, {
                GARAGE_DOOR_CODE: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            }>>, AssertsShape<Assign<ObjectShape, {
                GARAGE_DOOR_CODE: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            }>>>;
        }>>>;
    }, _AnyObject1, TypeOfShape<{
        PARKING: yup.ObjectSchema<Assign<ObjectShape, {
            DESCRIPTION: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            INSTRUCTIONS: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            HAS_ADDITIONAL_FREE_SPOTS: RequiredBooleanSchema<boolean | null | undefined, AnyObject>;
            HAS_ADDITIONAL_PAID_SPOTS: RequiredBooleanSchema<boolean | null | undefined, AnyObject>;
            NUM_SPOTS_PROVIDED: RequiredNumberSchema<number | undefined, AnyObject>;
            IS_DEFAULT_DESCRIPTION: RequiredBooleanSchema<boolean | undefined, AnyObject>;
            CODES: yup.ObjectSchema<Assign<ObjectShape, {
                GARAGE_DOOR_CODE: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            }>, _AnyObject1, TypeOfShape<Assign<ObjectShape, {
                GARAGE_DOOR_CODE: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            }>>, AssertsShape<Assign<ObjectShape, {
                GARAGE_DOOR_CODE: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            }>>>;
        }>, _AnyObject1, TypeOfShape<Assign<ObjectShape, {
            DESCRIPTION: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            INSTRUCTIONS: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            HAS_ADDITIONAL_FREE_SPOTS: RequiredBooleanSchema<boolean | null | undefined, AnyObject>;
            HAS_ADDITIONAL_PAID_SPOTS: RequiredBooleanSchema<boolean | null | undefined, AnyObject>;
            NUM_SPOTS_PROVIDED: RequiredNumberSchema<number | undefined, AnyObject>;
            IS_DEFAULT_DESCRIPTION: RequiredBooleanSchema<boolean | undefined, AnyObject>;
            CODES: yup.ObjectSchema<Assign<ObjectShape, {
                GARAGE_DOOR_CODE: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            }>, _AnyObject1, TypeOfShape<Assign<ObjectShape, {
                GARAGE_DOOR_CODE: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            }>>, AssertsShape<Assign<ObjectShape, {
                GARAGE_DOOR_CODE: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            }>>>;
        }>>, AssertsShape<Assign<ObjectShape, {
            DESCRIPTION: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            INSTRUCTIONS: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            HAS_ADDITIONAL_FREE_SPOTS: RequiredBooleanSchema<boolean | null | undefined, AnyObject>;
            HAS_ADDITIONAL_PAID_SPOTS: RequiredBooleanSchema<boolean | null | undefined, AnyObject>;
            NUM_SPOTS_PROVIDED: RequiredNumberSchema<number | undefined, AnyObject>;
            IS_DEFAULT_DESCRIPTION: RequiredBooleanSchema<boolean | undefined, AnyObject>;
            CODES: yup.ObjectSchema<Assign<ObjectShape, {
                GARAGE_DOOR_CODE: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            }>, _AnyObject1, TypeOfShape<Assign<ObjectShape, {
                GARAGE_DOOR_CODE: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            }>>, AssertsShape<Assign<ObjectShape, {
                GARAGE_DOOR_CODE: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
            }>>>;
        }>>>;
    }>>;
};
export const schema: any;
export const generateSchema: (subformName: RequiredSubformsEnum | OptionalSubformsEnum) => yup.ObjectSchema<Assign<ObjectShape, {
    [x: string]: any;
}>, _AnyObject1, TypeOfShape<Assign<ObjectShape, {
    [x: string]: any;
}>>, AssertsShape<Assign<ObjectShape, {
    [x: string]: any;
}>>>;
export const formSchemas: {
    emptySchema: typeof yup.object;
};
export const createReservationSchema: OptionalObjectSchema<{
    IS_NEW_GUEST: yup.BooleanSchema<boolean | undefined, AnyObject, boolean | undefined>;
    GUEST_FIRST_NAME: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
    ARRIVAL: RequiredDateSchema<Date | undefined, AnyObject>;
    GUEST_EMAIL: RequiredStringSchema<string | undefined, AnyObject>;
    PROPERTY_ID: RequiredNumberSchema<number | undefined, AnyObject>;
    NIGHTS: RequiredNumberSchema<number | undefined, AnyObject>;
    PARTY_SIZE_ADULTS: RequiredNumberSchema<number | undefined, AnyObject>;
    PARTY_SIZE_KIDS: yup.NumberSchema<number | undefined, AnyObject, number | undefined>;
    BOOKING_NET: RequiredNumberSchema<number | undefined, AnyObject>;
    PRICE_PER_NIGHT: RequiredNumberSchema<number | undefined, AnyObject>;
    DAMAGE_DEPOSIT_MODE_ID: RequiredNumberSchema<number | undefined, AnyObject>;
    DAMAGE_DEPOSIT_AMOUNT: yup.NumberSchema<number | undefined, AnyObject, number | undefined>;
    DEPOSIT_PERCENTAGE: RequiredNumberSchema<number | undefined, AnyObject>;
    BALANCE_DUE_DATE: yup.DateSchema<Date | undefined, AnyObject, Date | undefined>;
}, _AnyObject1, TypeOfShape<{
    IS_NEW_GUEST: yup.BooleanSchema<boolean | undefined, AnyObject, boolean | undefined>;
    GUEST_FIRST_NAME: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
    ARRIVAL: RequiredDateSchema<Date | undefined, AnyObject>;
    GUEST_EMAIL: RequiredStringSchema<string | undefined, AnyObject>;
    PROPERTY_ID: RequiredNumberSchema<number | undefined, AnyObject>;
    NIGHTS: RequiredNumberSchema<number | undefined, AnyObject>;
    PARTY_SIZE_ADULTS: RequiredNumberSchema<number | undefined, AnyObject>;
    PARTY_SIZE_KIDS: yup.NumberSchema<number | undefined, AnyObject, number | undefined>;
    BOOKING_NET: RequiredNumberSchema<number | undefined, AnyObject>;
    PRICE_PER_NIGHT: RequiredNumberSchema<number | undefined, AnyObject>;
    DAMAGE_DEPOSIT_MODE_ID: RequiredNumberSchema<number | undefined, AnyObject>;
    DAMAGE_DEPOSIT_AMOUNT: yup.NumberSchema<number | undefined, AnyObject, number | undefined>;
    DEPOSIT_PERCENTAGE: RequiredNumberSchema<number | undefined, AnyObject>;
    BALANCE_DUE_DATE: yup.DateSchema<Date | undefined, AnyObject, Date | undefined>;
}>>;
export const bookingNotesSchema: yup.ObjectSchema<Assign<ObjectShape, {
    notes_owner: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
}>, _AnyObject1, TypeOfShape<Assign<ObjectShape, {
    notes_owner: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
}>>, AssertsShape<Assign<ObjectShape, {
    notes_owner: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
}>>>;
export const customMessageSchema: yup.ObjectSchema<Assign<ObjectShape, {
    id: RequiredNumberSchema<number | undefined, AnyObject>;
    message: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
    entry_code: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
}>, _AnyObject1, TypeOfShape<Assign<ObjectShape, {
    id: RequiredNumberSchema<number | undefined, AnyObject>;
    message: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
    entry_code: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
}>>, AssertsShape<Assign<ObjectShape, {
    id: RequiredNumberSchema<number | undefined, AnyObject>;
    message: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
    entry_code: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
}>>>;
export const mainPasswordValidation: RequiredStringSchema<string | undefined, AnyObject>;
export const passwordValidation: OptionalObjectSchema<{
    PASSWORD: RequiredStringSchema<string | undefined, AnyObject>;
    PASSWORD_CONFIRM: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
}, _AnyObject1, TypeOfShape<{
    PASSWORD: RequiredStringSchema<string | undefined, AnyObject>;
    PASSWORD_CONFIRM: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
}>>;
export const userProfileValidation: yup.ObjectSchema<Assign<ObjectShape, {
    IS_COMPANY: RequiredBooleanSchema<boolean | null | undefined, AnyObject>;
    COMPANY_NAME: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
    FIRST_NAME: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
    LAST_NAME: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
    EMAIL: RequiredStringSchema<string | undefined, AnyObject>;
    PHONE: RequiredStringSchema<string | undefined, AnyObject>;
    ADDRESS: yup.ObjectSchema<Assign<ObjectShape, {
        STREET_NAME: RequiredStringSchema<string | undefined, AnyObject>;
        STREET_NUMBER: RequiredStringSchema<string | undefined, AnyObject>;
        UNIT: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
        CITY: RequiredStringSchema<string | undefined, AnyObject>;
        POSTAL: RequiredStringSchema<string | undefined, AnyObject>;
        REGION: RequiredStringSchema<string | undefined, AnyObject>;
        COUNTRY: RequiredStringSchema<string | undefined, AnyObject>;
    }>, _AnyObject1, TypeOfShape<Assign<ObjectShape, {
        STREET_NAME: RequiredStringSchema<string | undefined, AnyObject>;
        STREET_NUMBER: RequiredStringSchema<string | undefined, AnyObject>;
        UNIT: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
        CITY: RequiredStringSchema<string | undefined, AnyObject>;
        POSTAL: RequiredStringSchema<string | undefined, AnyObject>;
        REGION: RequiredStringSchema<string | undefined, AnyObject>;
        COUNTRY: RequiredStringSchema<string | undefined, AnyObject>;
    }>>, AssertsShape<Assign<ObjectShape, {
        STREET_NAME: RequiredStringSchema<string | undefined, AnyObject>;
        STREET_NUMBER: RequiredStringSchema<string | undefined, AnyObject>;
        UNIT: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
        CITY: RequiredStringSchema<string | undefined, AnyObject>;
        POSTAL: RequiredStringSchema<string | undefined, AnyObject>;
        REGION: RequiredStringSchema<string | undefined, AnyObject>;
        COUNTRY: RequiredStringSchema<string | undefined, AnyObject>;
    }>>>;
}>, _AnyObject1, TypeOfShape<Assign<ObjectShape, {
    IS_COMPANY: RequiredBooleanSchema<boolean | null | undefined, AnyObject>;
    COMPANY_NAME: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
    FIRST_NAME: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
    LAST_NAME: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
    EMAIL: RequiredStringSchema<string | undefined, AnyObject>;
    PHONE: RequiredStringSchema<string | undefined, AnyObject>;
    ADDRESS: yup.ObjectSchema<Assign<ObjectShape, {
        STREET_NAME: RequiredStringSchema<string | undefined, AnyObject>;
        STREET_NUMBER: RequiredStringSchema<string | undefined, AnyObject>;
        UNIT: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
        CITY: RequiredStringSchema<string | undefined, AnyObject>;
        POSTAL: RequiredStringSchema<string | undefined, AnyObject>;
        REGION: RequiredStringSchema<string | undefined, AnyObject>;
        COUNTRY: RequiredStringSchema<string | undefined, AnyObject>;
    }>, _AnyObject1, TypeOfShape<Assign<ObjectShape, {
        STREET_NAME: RequiredStringSchema<string | undefined, AnyObject>;
        STREET_NUMBER: RequiredStringSchema<string | undefined, AnyObject>;
        UNIT: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
        CITY: RequiredStringSchema<string | undefined, AnyObject>;
        POSTAL: RequiredStringSchema<string | undefined, AnyObject>;
        REGION: RequiredStringSchema<string | undefined, AnyObject>;
        COUNTRY: RequiredStringSchema<string | undefined, AnyObject>;
    }>>, AssertsShape<Assign<ObjectShape, {
        STREET_NAME: RequiredStringSchema<string | undefined, AnyObject>;
        STREET_NUMBER: RequiredStringSchema<string | undefined, AnyObject>;
        UNIT: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
        CITY: RequiredStringSchema<string | undefined, AnyObject>;
        POSTAL: RequiredStringSchema<string | undefined, AnyObject>;
        REGION: RequiredStringSchema<string | undefined, AnyObject>;
        COUNTRY: RequiredStringSchema<string | undefined, AnyObject>;
    }>>>;
}>>, AssertsShape<Assign<ObjectShape, {
    IS_COMPANY: RequiredBooleanSchema<boolean | null | undefined, AnyObject>;
    COMPANY_NAME: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
    FIRST_NAME: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
    LAST_NAME: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
    EMAIL: RequiredStringSchema<string | undefined, AnyObject>;
    PHONE: RequiredStringSchema<string | undefined, AnyObject>;
    ADDRESS: yup.ObjectSchema<Assign<ObjectShape, {
        STREET_NAME: RequiredStringSchema<string | undefined, AnyObject>;
        STREET_NUMBER: RequiredStringSchema<string | undefined, AnyObject>;
        UNIT: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
        CITY: RequiredStringSchema<string | undefined, AnyObject>;
        POSTAL: RequiredStringSchema<string | undefined, AnyObject>;
        REGION: RequiredStringSchema<string | undefined, AnyObject>;
        COUNTRY: RequiredStringSchema<string | undefined, AnyObject>;
    }>, _AnyObject1, TypeOfShape<Assign<ObjectShape, {
        STREET_NAME: RequiredStringSchema<string | undefined, AnyObject>;
        STREET_NUMBER: RequiredStringSchema<string | undefined, AnyObject>;
        UNIT: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
        CITY: RequiredStringSchema<string | undefined, AnyObject>;
        POSTAL: RequiredStringSchema<string | undefined, AnyObject>;
        REGION: RequiredStringSchema<string | undefined, AnyObject>;
        COUNTRY: RequiredStringSchema<string | undefined, AnyObject>;
    }>>, AssertsShape<Assign<ObjectShape, {
        STREET_NAME: RequiredStringSchema<string | undefined, AnyObject>;
        STREET_NUMBER: RequiredStringSchema<string | undefined, AnyObject>;
        UNIT: yup.StringSchema<string | undefined, AnyObject, string | undefined>;
        CITY: RequiredStringSchema<string | undefined, AnyObject>;
        POSTAL: RequiredStringSchema<string | undefined, AnyObject>;
        REGION: RequiredStringSchema<string | undefined, AnyObject>;
        COUNTRY: RequiredStringSchema<string | undefined, AnyObject>;
    }>>>;
}>>>;
export const loginValidation: yup.ObjectSchema<Assign<ObjectShape, {
    email: RequiredStringSchema<string | undefined, AnyObject>;
    password: RequiredStringSchema<string | undefined, AnyObject>;
}>, _AnyObject1, TypeOfShape<Assign<ObjectShape, {
    email: RequiredStringSchema<string | undefined, AnyObject>;
    password: RequiredStringSchema<string | undefined, AnyObject>;
}>>, AssertsShape<Assign<ObjectShape, {
    email: RequiredStringSchema<string | undefined, AnyObject>;
    password: RequiredStringSchema<string | undefined, AnyObject>;
}>>>;
export const forgotPasswordValidation: yup.ObjectSchema<Assign<ObjectShape, {
    email: RequiredStringSchema<string | undefined, AnyObject>;
}>, _AnyObject1, TypeOfShape<Assign<ObjectShape, {
    email: RequiredStringSchema<string | undefined, AnyObject>;
}>>, AssertsShape<Assign<ObjectShape, {
    email: RequiredStringSchema<string | undefined, AnyObject>;
}>>>;
declare const initialValues: {
    message: string;
};
interface _Props3 {
    onSubmit: (values: typeof initialValues, helpers: any) => void;
    children: React.ReactNode;
}
export const CreateMessageForm: ({ children, onSubmit }: _Props3) => JSX.Element;
export const parkingFields: {
    garageCode: {
        label: string;
        field: string;
    };
};
export const generateParkingText: ({ numberOfSpotsProvided, hasAdditionalFreeSpots, hasAdditionalPaidSpots, }: {
    numberOfSpotsProvided: number;
    hasAdditionalFreeSpots: boolean;
    hasAdditionalPaidSpots: boolean;
}) => string;
export const generateParkingValues: ({ PARKING, INSTRUCTIONS: { PARKING: parkingInstructions }, CODES, }: Property) => {
    ParkingForm: {
        PARKING: {
            INSTRUCTIONS: string;
            CODES: {
                GARAGE_DOOR_CODE: string;
            };
            DESCRIPTION: string;
            HAS_ADDITIONAL_FREE_SPOTS: string;
            HAS_ADDITIONAL_PAID_SPOTS: string;
            IS_DEFAULT_DESCRIPTION: boolean;
            NUM_SPOTS_PROVIDED: string;
        };
    };
};
export const reservationCancelRequestFormValues: {
    initialValues: {
        message: string;
        isChecked: boolean;
    };
    validationSchema: OptionalObjectSchema<{
        message: RequiredStringSchema<string | undefined, AnyObject>;
        isChecked: RequiredBooleanSchema<boolean | undefined, AnyObject>;
    }, _AnyObject1, TypeOfShape<{
        message: RequiredStringSchema<string | undefined, AnyObject>;
        isChecked: RequiredBooleanSchema<boolean | undefined, AnyObject>;
    }>>;
};
export const reservationEditRequestFormValues: {
    initialValues: {
        message: string;
        isChecked: boolean;
    };
    validationSchema: OptionalObjectSchema<{
        message: RequiredStringSchema<string | undefined, AnyObject>;
        isChecked: RequiredBooleanSchema<boolean | undefined, AnyObject>;
    }, _AnyObject1, TypeOfShape<{
        message: RequiredStringSchema<string | undefined, AnyObject>;
        isChecked: RequiredBooleanSchema<boolean | undefined, AnyObject>;
    }>>;
};
export enum SubjectIdentifier {
    BOOKING = "BOOKING",
    INQUIRY = "INQUIRY"
}
interface CreateMessageSubjectBooking {
    TYPE: SubjectIdentifier.BOOKING;
    ID: number;
    ARRIVAL_DATE: string;
    DEPARTURE_DATE: string;
    REFERENCE: string;
}
interface CreateMessageSubjectInquiry {
    TYPE: SubjectIdentifier.INQUIRY;
    ID: number;
    ARRIVAL_DATE: string | undefined;
    DEPARTURE_DATE: string | undefined;
}
export type CreateMessageSubject = CreateMessageSubjectBooking | CreateMessageSubjectInquiry;
export function generateCreateMessageSubject(subject: UserMessageSubject | undefined): CreateMessageSubject | undefined;
export interface MessageSearchParams {
    contactId: number;
    contactTypeId: UserRoleIDEnum;
    initialBookingId?: number;
    initialMessageId?: number;
}
/** When visiting a thread from the message overview screen none of initialBookingId or initialMessageId are selected.
 *    In this scenario the booking, inquiry or message id will be set by the most recent message in the message thread
 *  When visiting a thread from a reservation or guidebook screen the initialBookingId will be set
 *    In this scenario, bookingId will be set
 *  In both scenarios, once one of bookingId or messageId are set then the subject will be fetched and set
 */
export const useInitializeThread: ({ initialBookingId, initialMessageId, }: Omit<MessageSearchParams, "contactId" | "contactTypeId">) => {
    bookingId: number | undefined;
    setBookingId: Dispatch<SetStateAction<number | undefined>>;
    messageId: number | undefined;
    setMessageId: Dispatch<SetStateAction<number | undefined>>;
    hasInitialSubjectSelection: boolean;
    hasCurrentSubjectSelection: boolean;
};
export const useMessageContact: ({ propertyId, contactUserId, contactUserTypeId }: UserMessageContactArgs) => {
    userContactQuery: UseQueryResult<_APIResponse1<{
        CONTACT: User;
        LAST_RESERVATION_DATE: string;
        NEXT_RESERVATION_DATE: string;
        STATUS: string;
    }>, Error>;
    userContact: MessageUserContact | undefined;
};
interface _Args29 {
    userId: number;
    userTypeId: UserRoleIDEnum;
    contactUserId: number;
    contactUserTypeId: UserRoleIDEnum;
}
/** Automatically marks all messages between the current user and a contact user as read */
export const useMessageMarkAsRead: ({ contactUserId, contactUserTypeId, userId, userTypeId }: _Args29) => void;
interface _Args30 {
    userId: number;
    userTypeId: UserRoleIDEnum;
    hasCurrentSubjectSelection: boolean;
    bookingId?: number;
    messageId?: number;
}
/** Fetch and set the selected subject and property based on the param passed in
 *  selectedSubject and selectedProperty will be auto-selected when sending a message for convenience
 */
export const useMessageSubject: ({ userId, userTypeId, hasCurrentSubjectSelection, bookingId, messageId }: _Args30) => {
    subjectQuery: UseQueryResult<_APIResponse1<{
        SUBJECT: UserMessageSubject;
    }>, Error>;
    selectedSubject: CreateMessageSubject | undefined;
    setSelectedSubject: Dispatch<SetStateAction<CreateMessageSubject | undefined>>;
    selectedProperty: {
        ID: number;
        THUMBNAIL: string;
        NAME: string;
        SIZE_CATEGORY: string;
    } | undefined;
    setSelectedProperty: Dispatch<SetStateAction<{
        ID: number;
        THUMBNAIL: string;
        NAME: string;
        SIZE_CATEGORY: string;
    } | undefined>>;
};
interface _Args31 {
    userId: number;
    userTypeId: UserRoleIDEnum;
    contactUserId: number;
    contactUserTypeId: UserRoleIDEnum;
}
export const useMessageThread: ({ userTypeId, userId, contactUserId, contactUserTypeId, ...rest }: _Args31 & ConfigurableAppInfiniteQueryArgs) => {
    threadQuery: UseInfiniteQueryResult<_InfiniteData1<any, unknown>, any>;
    threadData: {
        MESSAGE: {
            MESSAGE: string;
            IS_READ: boolean;
            SUBJECT: string;
            TO_EMAILS: string;
            FROM_EMAIL: string;
            THUMBNAIL: string;
            SENT_DATE: string;
            SENT_TIME: string;
            BOOKING_ID: number;
            ID: number;
            READ_DATE: string;
            READ_TIME: string;
            INQUIRY_ID: number;
            SENDER_USER_ID: number;
            SENDER_USER_TYPE_ID: UserRoleIDEnum;
            RECEIVER_USER_ID: number;
            RECEIVER_USER_TYPE_ID: UserRoleIDEnum;
            ARRIVAL_DATE: string;
            DEPARTURE_DATE: string;
            IS_INQUIRY: boolean;
            NUM_BEDS: number;
            NUM_GUESTS: number;
        };
        PROPERTY: {
            ID: number;
            THUMBNAIL: string;
            NAME: string;
            SIZE_CATEGORY: string;
        };
        BOOKING: {
            ID: number;
            ARRIVAL_DATE: string;
            DEPARTURE_DATE: string;
            CREATED_DATE: string;
            REFERENCE: string;
        };
    }[];
    lastThreadData: {
        MESSAGE: {
            MESSAGE: string;
            IS_READ: boolean;
            SUBJECT: string;
            TO_EMAILS: string;
            FROM_EMAIL: string;
            THUMBNAIL: string;
            SENT_DATE: string;
            SENT_TIME: string;
            BOOKING_ID: number;
            ID: number;
            READ_DATE: string;
            READ_TIME: string;
            INQUIRY_ID: number;
            SENDER_USER_ID: number;
            SENDER_USER_TYPE_ID: UserRoleIDEnum;
            RECEIVER_USER_ID: number;
            RECEIVER_USER_TYPE_ID: UserRoleIDEnum;
            ARRIVAL_DATE: string;
            DEPARTURE_DATE: string;
            IS_INQUIRY: boolean;
            NUM_BEDS: number;
            NUM_GUESTS: number;
        };
        PROPERTY: {
            ID: number;
            THUMBNAIL: string;
            NAME: string;
            SIZE_CATEGORY: string;
        };
        BOOKING: {
            ID: number;
            ARRIVAL_DATE: string;
            DEPARTURE_DATE: string;
            CREATED_DATE: string;
            REFERENCE: string;
        };
    } | undefined;
    refreshThread: () => Promise<void>;
    refreshingThread: boolean;
};
interface _Args32 {
    lastThreadData: MessageThreadItem | undefined;
    hasCurrentSubjectSelection: boolean;
    setBookingId: (id: number) => void;
    setMessageId: (id: number) => void;
}
/** When a user enters a thread from an overview screen none of bookingId or messageId are set
 *  To set one of these and download the subject we check the last message in the thread
 */
export const useUpdateSubjectSelection: ({ lastThreadData, hasCurrentSubjectSelection, setBookingId, setMessageId, }: _Args32) => void;
export type ParkingFormValues = ReturnType<typeof generateParkingValues>;
export const generatePropertyTransactionsParameters: (propertyId: number, { startDate, endDate, status, sort, source }: TransactionsOrReservationsServerSearchTool) => string;
export function generateAPIResponse<T>(data: T): APIResponse<T>;
export enum HttpResponseCode {
    UNAUTHORIZED = 401,
    FORBIDDEN = 403,
    NOT_FOUND = 404
}
export const startOfYear: Date;
export const oneYearInFuture: Date;
export const pipe: (...fns: any) => (x: any) => any;
export const compose: (...fns: any) => (x: any) => any;
export function curry(func: any): (...args: any) => any;
export const generateNestedComputedValue: (path: string, obj: {
    [key: string]: any;
}) => any;
export const countryCodeToCountryName: {
    AB: string;
    AC: string;
    AD: string;
    AE: string;
    AF: string;
    AG: string;
    AI: string;
    AL: string;
    AM: string;
    AO: string;
    AQ: string;
    AR: string;
    AS: string;
    AT: string;
    AU: string;
    AW: string;
    AX: string;
    AZ: string;
    BA: string;
    BB: string;
    BD: string;
    BE: string;
    BF: string;
    BG: string;
    BH: string;
    BI: string;
    BJ: string;
    BL: string;
    BM: string;
    BN: string;
    BO: string;
    BQ: string;
    BR: string;
    BS: string;
    BT: string;
    BV: string;
    BW: string;
    BY: string;
    BZ: string;
    CA: string;
    CC: string;
    CD: string;
    CF: string;
    CG: string;
    CH: string;
    CI: string;
    CK: string;
    CL: string;
    CM: string;
    CN: string;
    CO: string;
    CR: string;
    CU: string;
    CV: string;
    CW: string;
    CX: string;
    CY: string;
    CZ: string;
    DE: string;
    DJ: string;
    DK: string;
    DM: string;
    DO: string;
    DZ: string;
    EC: string;
    EE: string;
    EG: string;
    EH: string;
    ER: string;
    ES: string;
    ET: string;
    FI: string;
    FJ: string;
    FK: string;
    FM: string;
    FO: string;
    FR: string;
    GA: string;
    GB: string;
    GD: string;
    GE: string;
    GF: string;
    GG: string;
    GH: string;
    GI: string;
    GL: string;
    GM: string;
    GN: string;
    GP: string;
    GQ: string;
    GR: string;
    GS: string;
    GT: string;
    GU: string;
    GW: string;
    GY: string;
    HK: string;
    HM: string;
    HN: string;
    HR: string;
    HT: string;
    HU: string;
    ID: string;
    IE: string;
    IL: string;
    IM: string;
    IN: string;
    IO: string;
    IQ: string;
    IR: string;
    IS: string;
    IT: string;
    JE: string;
    JM: string;
    JO: string;
    JP: string;
    KE: string;
    KG: string;
    KH: string;
    KI: string;
    KM: string;
    KN: string;
    KP: string;
    KR: string;
    KW: string;
    KY: string;
    KZ: string;
    LA: string;
    LB: string;
    LC: string;
    LI: string;
    LK: string;
    LR: string;
    LS: string;
    LT: string;
    LU: string;
    LV: string;
    LY: string;
    MA: string;
    MC: string;
    MD: string;
    ME: string;
    MF: string;
    MG: string;
    MH: string;
    MK: string;
    ML: string;
    MM: string;
    MN: string;
    MO: string;
    MP: string;
    MQ: string;
    MR: string;
    MS: string;
    MT: string;
    MU: string;
    MV: string;
    MW: string;
    MX: string;
    MY: string;
    MZ: string;
    NA: string;
    NC: string;
    NE: string;
    NF: string;
    NG: string;
    NI: string;
    NL: string;
    NO: string;
    NP: string;
    NR: string;
    NU: string;
    NZ: string;
    OM: string;
    OS: string;
    PA: string;
    PE: string;
    PF: string;
    PG: string;
    PH: string;
    PK: string;
    PL: string;
    PM: string;
    PN: string;
    PR: string;
    PS: string;
    PT: string;
    PW: string;
    PY: string;
    QA: string;
    RE: string;
    RO: string;
    RS: string;
    RU: string;
    RW: string;
    SA: string;
    SB: string;
    SC: string;
    SD: string;
    SE: string;
    SG: string;
    SH: string;
    SI: string;
    SJ: string;
    SK: string;
    SL: string;
    SM: string;
    SN: string;
    SO: string;
    SR: string;
    SS: string;
    ST: string;
    SV: string;
    SX: string;
    SY: string;
    SZ: string;
    TA: string;
    TC: string;
    TD: string;
    TF: string;
    TG: string;
    TH: string;
    TJ: string;
    TK: string;
    TL: string;
    TM: string;
    TN: string;
    TO: string;
    TR: string;
    TT: string;
    TV: string;
    TW: string;
    TZ: string;
    UA: string;
    UG: string;
    UM: string;
    US: string;
    UY: string;
    UZ: string;
    VA: string;
    VC: string;
    VE: string;
    VG: string;
    VI: string;
    VN: string;
    VU: string;
    WF: string;
    WS: string;
    XK: string;
    YE: string;
    YT: string;
    ZA: string;
    ZM: string;
    ZW: string;
    ZZ: string;
};
export const preferredCountries: CountryCode[];
/** https://www.twilio.com/docs/glossary/what-e164
 
 * E.164 is the international telephone numbering plan that ensures each device on the PSTN has globally unique number.
    This number allows phone calls and text messages can be correctly
    routed to individual phones in different countries. E.164 numbers are formatted [+] [country code] [subscriber number including area code] and can have a maximum of fifteen digits. */
/** for display purposes. As of 2022-01-31, all future phone inputs will require the E164 format : [+] [country code] [subscriber number including area code].
 ** This function will format the E164 format to National or International depending on if the phone number is from North America.
 ** Use this function when displaying phone values on the client.
 */
export function formatPhoneNumber(phoneNumber: string): string;
interface E164Format {
    subscriberNumber: number | string;
    countryCallingCode: number | string;
}
/** Phone number to be sent for submission to server */
export function formatE164PhoneNumber({ subscriberNumber, countryCallingCode }: E164Format): string;
export function parsePhone(phoneNumber: string): {
    countryCode: string;
    country: string;
    subscriberNumber: string;
};
/** We have legacy phone numbers that will not include the + symbol
 ** In order to cover a larger base of phone numbers, we will identify numbers that do not have the + and add it.   */
export const handleAddPlusToPhoneNumber: (phoneNumber: string) => string;
export interface CountryAndCode {
    countryCode: CountryCode | string;
    callingCode: CountryCallingCode | string;
    countryName: string;
}
export function getAllCountryCallingCodes(): CountryAndCode[];
export function replaceEmptyRteHtml(html: string): string;
type EnumType = {
    [s: number]: string;
};
export const getEnumValues: (enumerable: EnumType) => string[];
export const getEnumKeys: (enumerable: EnumType) => string[];
export interface Subject {
    title: string;
    subtitle: string;
    subtitle2: string;
}
/** For display in message threads */
export function generateSelectedSubjectDisplay({ subject, isOwnerRole, }: {
    subject: CreateMessageSubject | undefined;
    isOwnerRole: boolean;
}): string;
/** For display in message subject select dialog */
export function generateReservationSubject({ subject, isOwnerMode, }: {
    subject: UserMessageSubject;
    isOwnerMode: boolean;
}): Subject;
/** For display in message subject select dialog
 * Bookings are also being fed through this function; added date check on BOOKING object, and removed (sendDate) when none found for cleaner UI
*/
export function generateOwnerInquirySubject(subject: UserMessageSubject): Subject;
export function generateContactName(overviewMessage: UserMessageOverview): string;
export function generateLastMessageSentTime(overviewMessage: UserMessageOverview): string;
export function generateNumberOfUnread(overviewMessage: UserMessageOverview): string;
export function hasNextReservation(overviewMessage: UserMessageOverview): boolean;
export function generateMessageProperty(overviewMessage: UserMessageOverview): string;
/** Guests can view the access code on the day of arrival, owners can view the access code at any time
 * @param arrival is a yyyy-mm-dd formatted string
 */
export function accessCodeAvailableDate(arrival: string): Dayjs;
/** Can the guest view the access code for a specific booking */
export function canViewAccessCode({ bookingStatusId, arrival, departure, }: {
    bookingStatusId: BookingStatusId;
    arrival: string;
    departure: string;
}): boolean;
/** Owner must enter access codes for a reservation 9 days before the arrival date
 * This is important only when the owner has selected the access code option that requires a unique code for each reservation
 */
export const accessCodeDueDate: (arrival: string) => dayjs.Dayjs;
export function generateAccessCodeDueDate(arrival: string): string;
export enum BookingAccessCodeTextEnum {
    noLongerAvailable = "No Longer Available",
    payDepositFirst = "Make Payment First",
    providedByHost = "Provided by Host",
    providedByFrontDesk = "Provided by Front Desk",
    guestUnavailableDoorCode = "Unavailable, Contact Host"
}
interface BookingAccessCodeText {
    isOwnerMode: boolean;
    bookingStatusId: BookingStatusId;
    accessToUnit: AccessToUnit;
    arrival: string;
    departure: string;
    customDoorCode?: string;
}
/** Text that will appear for the guest whenever they try to view the door code / access code */
export function generateBookingAccessCodeText({ isOwnerMode, bookingStatusId, accessToUnit, arrival, departure, customDoorCode, }: BookingAccessCodeText): string;
export function generateAccessCodeLabel({ accessToUnit }: {
    accessToUnit: AccessToUnit;
}): string;
interface AccessOptions {
    codeId: AccessCodeIdEnum;
    methodId: AccessMethodIdEnum;
    typeId: AccessCodeTypeIDEnum;
}
export function accessToUnitSelectedOptions({ codeId, methodId, typeId }: AccessOptions): {
    hasSelectedPropertyAccessType: boolean;
    hasSelectedAccessMethod: boolean;
    hasSelectedAccessCode: boolean;
    hasStandardCode: boolean;
    hasAccessCode: boolean;
    hasAccessCodeEmailMethod: boolean;
    hasKeyLockboxMethod: boolean;
    hasFrontDeskMethod: boolean;
    hasOtherDeskMethod: boolean;
    hasAccessCodeSection: boolean;
};
export const transactionText: {
    /** Section of a reservation screen/page where billing, invoice, revenue, bank info is deisplayed */
    billingDetails: string;
    /** A bill that a guest receives for booking with alluraDirect */
    reservationInvoice: string;
    /** A bill that a guest receives for booking with an allura partner (Whistler) */
    partnerInvoice: string;
    /** Summary of deposits that the owner has received from a booking */
    bankDeposits: string;
    /** A breakdown of the total amount that the owner will receive from a booking */
    revenueReceivedSummary: string;
    /** Price per night * number of nights */
    accommodation: string;
    cleaningAndPetFees: string;
    /** Service fee that the guest is charged for booking with alluraDirect */
    guestServiceFee: string;
    /** The total amount due for a booking. Includes fees, taxes etc */
    reservationTotal: string;
    partnerCommissionFee: string;
    damageDeposit: string;
    creditCardFee: string;
    bookingCommission: string;
    /** Non-resident only */
    nr6Withheld: string;
    totalDepositedToBank: string;
    /** Either the property owner or alluraDirect */
    taxRemitter: string;
    /** Property managers want an additional cut of the booking fee */
    propertyManagerServiceFee: string;
};
export function isInflatedBooking(booking: FullBooking): boolean;
export const hasReview: (booking: SparseBooking) => boolean;
export const hasMadePayment: (booking: SparseBooking) => boolean;
export const canMakeBookingPayment: (bookingStatusId: BookingStatusId) => bookingStatusId is BookingStatusId.DepositPaidDue;
export const hasVisiblePropertyGuideBookBtn: (bookingStatusId: BookingStatusId, bookingDeparture: string) => boolean;
export const hasVisibleRebookPropertyBtn: (bookingDeparture: string) => boolean;
export const isCurrentReservation: (arrival: string, departure: string) => boolean;
export const isPastReservation: (departure: string) => boolean;
type PendingReservationArgs = Pick<Booking, 'STATUS' | 'FLAGS' | 'PAYMENT'>;
export const isPendingReservation: ({ STATUS, FLAGS, PAYMENT }: PendingReservationArgs) => boolean;
export const canViewPropertyGuidebook: (statusId: BookingStatusId, arrival: string, departure: string) => boolean;
export const propertyGuidebookAvailableDate: (arrival: string) => dayjs.Dayjs;
export const propertyGuidebookAvailableDateFormatted: (arrival: string) => string;
interface GuestRequestModifyArgs {
    departure: string;
    bookingStatusId: BookingStatusId;
}
/** Comment from Matt: A booking would be adjustable as long as the departure date is not today or in the past.
 * Example:  Dec 11 - Dec 15
 * On the checkout morning of Dec 15, they could NOT adjust it as it wouldnt give the host enough time to approve/adjust pricing
 * The night before the checkout (Dec 14), is a likely scenario to extend the reservation.  “The snow is amazing, lets stay a few more days!”
 *
 * A cancelled booking is not editable
 */
export const canGuestRequestToModifyBooking: ({ departure, bookingStatusId }: GuestRequestModifyArgs) => boolean;
interface HostModifyBookingArgs {
    departure: string;
    bookingStatusId: BookingStatusId;
}
/** Hosts cannot modify a booking that is cancelled or is in the past.
 * This is similar to the guest modify booking except the owner can modify on the last day for added flexibility
 *
 * In the future hosts may need certain permissions to modify a booking (think co-host or property manager with limited ability maybe)
 */
export const canHostModifyBooking: ({ departure, bookingStatusId }: HostModifyBookingArgs) => boolean;
interface HostModifyBookingStartDateArgs {
    arrival: string;
}
/** The host can modify the booking start date up to and including the day of arrival */
export const canHostModifyBookingStartDate: ({ arrival }: HostModifyBookingStartDateArgs) => boolean;
/** Deprecated, use canGuestRequestToModifyBooking instead. Create canHostModifyBooking once details are confirmed */
export const canModifyBooking: (arrival: string, statusId: BookingStatusId) => boolean;
export const confirmationPropertyGuidebookText: (statusId: BookingStatusId, arrival: string) => string;
export const isPaymentButtonVisible: (statusId: BookingStatusId) => statusId is BookingStatusId.ReservationRequest | BookingStatusId.DepositPaidDue;
/** Bookings can only be reviewed if the balance is paid, they are departing or have departed and the booking is less than 2 years in the past */
export const canReviewBooking: (statusId: BookingStatusId, departure: string) => boolean;
export const reservationStatusText: (statusId: BookingStatusId, isCurrentReservation: boolean, hasMadePayment: boolean) => BookingStatusMessage.ReservationRequested | BookingStatusMessage.DepositDue | BookingStatusMessage.PaymentDue | BookingStatusMessage.Confirmed | BookingStatusMessage.Cancelled | BookingStatusMessage.ReservationDeclined | BookingStatusMessage.LatePayment | BookingStatusMessage.UnknownStatusId;
export const balanceText: ({ amountOutstanding, statusId, balanceDueDate, depositDueDate, hasMadePayment, }: {
    amountOutstanding: string;
    statusId: BookingStatusId;
    balanceDueDate: string;
    depositDueDate: string;
    hasMadePayment: boolean;
}) => string;
export function hasPerGuestMessage(customMessage: CustomMessage): boolean;
export function hasCustomMessage(message: string): boolean;
export function hasCustomEntryCode(entryCode: string): boolean;
export function generateCustomMessagePreview(message: string): string;
export const convertBookingServerToParams: (booking: FullBooking) => EditBookingBody;
export const generateBookingStatusDetails: (booking: FullBooking) => {
    hasPaidDeposit: boolean;
    hasPaidFull: boolean;
    isFullPayment: boolean;
    hasDamangeDepositAmount: boolean;
};
export const generateSurchargeIds: (isPetFeeEnabled: boolean, isCleaningFeeEnabled: boolean) => string;
export const generateSurchargeData: (surcharges: PropertySurcharge[]) => {
    petFeeAmount: string;
    isPetFeeEnabled: boolean;
    cleaningFeeAmount: string;
    isCleaningFeeEnabled: boolean;
    surchargeIds: string;
};
export const calculateIsWithinBalanceDate: (arrival: Dayjs, balanceDaysBefore: number) => boolean;
export const generateRateQuoteErrorData: (start: Dayjs, balanceDaysBeforeArrival: number, propertyDepositPercentage: number) => {
    PRICE_PER_NIGHT: number;
    BOOKING_NET: string;
    BALANCE_DUE_DATE: string;
    DEPOSIT_DUE_DATE: string;
    DEPOSIT_PERCENTAGE: number;
};
export const isDamageDepositCollected: (booking: FullBooking) => boolean;
interface _Args33 {
    STREET_NUMBER: number | string;
    STREET_NAME: string;
    POSTAL: string;
    CITY: string;
    COUNTRY: string;
}
export function generateReadableAddress(address: _Args33): string;
export enum PropertyAmenityCategories {
    BUILDING = "BUILDING",
    ESSENTIAL = "ESSENTIAL",
    KITCHEN = "KITCHEN",
    PRIVATE = "PRIVATE",
    SAFETY = "SAFETY"
}
interface _Args34 {
    property: Property;
    formAmenity: NameIdItem;
    section: PropertyAmenityCategories;
}
/** Check if a formInputs amenity is enabled (exists) in the property object */
export function propertyHasAmenity({ property, formAmenity, section }: _Args34): boolean;
export function getPropertyAmenity({ property, formAmenity, section }: _Args34): Amenity | undefined;
export function amenityHasInstructions(amenity: Amenity): boolean;
export function amenityHasDescription(amenity: Amenity): boolean;
export function isWifiAmenity(amenityId: number): boolean;
export function amenityHasAccessCode(amenityId: number): boolean;
interface GenerateAmenityArgs {
    ID: number;
    NAME: string;
    INSTRUCTIONS: string;
    DESCRIPTION: string;
    PROPERTY_AMENITY_ID?: number;
    ACCESS_CODE?: string;
    INTERNET_NETWORK_NAME?: string;
    INTERNET_PASSWORD?: string;
}
export function generateAmenity({ ID, NAME, INSTRUCTIONS, DESCRIPTION, PROPERTY_AMENITY_ID, ACCESS_CODE, INTERNET_NETWORK_NAME, INTERNET_PASSWORD, }: GenerateAmenityArgs): Amenity;
export const CreateMessage: {
    generateMessageSubjectTitle(userContact: UserMessageSubject, userType: UserRoleIDEnum): string;
    generateMessageSubjectSubtitle(userContact: UserMessageSubject, userType: UserRoleIDEnum): string;
    generateMessageSubjectThumbnail(userContact: UserMessageSubject, userType: UserRoleIDEnum | 0): string;
};
export const developmentMapsKey = "AIzaSyBWM3cDz-C4uU-WlG3K1jjdLkaFbLPtzek";
export const liveMapsKey = "AIzaSyBWM3cDz-C4uU-WlG3K1jjdLkaFbLPtzek";
interface GetMapsKeyArgs {
    isLive: boolean;
}
export const getMapsKey: ({ isLive }: GetMapsKeyArgs) => string;
export function generateMapsAddressURL(address: Address): string;
interface _Args35 {
    address: Address;
    isLive: boolean;
}
export function generateMapsEmbedAddressURL({ address, isLive }: _Args35): string;
/**
 * google recommends formatting queries in the format suggested by the local region.
 * Since alluraDirect currently operates out of Canada we should use the Canadian postal code format
 * The following code follows the postal code format + the address result obtained from sample google maps queries
 *
 * https://www.canadapost-postescanada.ca/cpc/en/support/kb/addressing/accuracy/addressing-mail-accurately
 * https://developers.google.com/maps/faq#geocoder_queryformat
 */
export function generateQueryFromAddress({ STREET_NUMBER, STREET_NAME, CITY, REGION, POSTAL, }: Pick<Address, 'STREET_NUMBER' | 'STREET_NAME' | 'CITY' | 'REGION' | 'POSTAL'>): string;
export enum EditorFieldEnum {
    welcomeMessage = "Welcome Message",
    parkingInstructions = "Parking Instructions",
    checkIn = "Check-In Procedure",
    gettingToUnit = "Directions to Property",
    frontDesk = "Front-Desk Details",
    whatToBring = "What to bring with you",
    lateCheckIn = "Late Check-In Procedure",
    locationSummary = "Location Summary",
    heating = "Heating",
    aboutBuilding = "About the Building",
    emergencyContactProcedure = "Emergency Contact Procedure",
    directionsToSkiLift = "Directions To Ski Lifts",
    skiInOut = "Ski In / Ski Out Instructions",
    gettingAround = "Getting Around the Area",
    linens = "Extra Towels & Linens",
    restaurants = "Restaurants",
    services = "Services & Activities",
    houseKeeping = "House Keeping Details",
    other = "Other",
    checkOut = "Check-Out Process",
    garbage = "Garbage Removal"
}
export const editorURLParamsEnum: {
    "About the Building": PropertyInstructionsEnum;
    "Check-In Procedure": PropertyInstructionsEnum;
    "Check-Out Process": PropertyInstructionsEnum;
    "Directions To Ski Lifts": PropertyInstructionsEnum;
    "Emergency Contact Procedure": PropertyInstructionsEnum;
    "Front-Desk Details": PropertyInstructionsEnum;
    "Garbage Removal": PropertyInstructionsEnum;
    "Getting Around the Area": PropertyInstructionsEnum;
    Heating: PropertyInstructionsEnum;
    "House Keeping Details": PropertyInstructionsEnum;
    "Late Check-In Procedure": PropertyInstructionsEnum;
    "Extra Towels & Linens": PropertyInstructionsEnum;
    "Location Summary": PropertyInstructionsEnum;
    Other: PropertyInstructionsEnum;
    "Parking Instructions": PropertyInstructionsEnum;
    "Welcome Message": PropertyInstructionsEnum;
    Restaurants: PropertyInstructionsEnum;
    "Services & Activities": PropertyInstructionsEnum;
    "Ski In / Ski Out Instructions": PropertyInstructionsEnum;
    "What to bring with you": PropertyInstructionsEnum;
    "Directions to Property": PropertyInstructionsEnum;
};
export function getGuidebookAccessCode(guidebook: PropertyGuidebook): string;
export function getGuidebookWifiDetails(guidebook: PropertyGuidebook): string;
export function hasGuidebookAmenity(guidebook: PropertyGuidebook, amenityId: PropertyAmenityId): boolean;
export function hasGuidebookWifiAmenity(guidebook: PropertyGuidebook): boolean;
export function getGuidebookDirectionsToProperty(guidebook: PropertyGuidebook): string;
export function guidebookHtmlAsString(html: string | string[]): string;
export function isAmenitySkiOrBike(amenity: Amenity): boolean;
/** A property can access the dashboard if the Listing is Active, or if they have gone from Active to inactive.
 * An inactive property status is not possible without completing onboarding.
 * A deactivation requested property can still access dashboard (Jira: REMDASH-3934)
 */
export const dashboardLinkStatuses: JoinStatusIDEnum[];
export const onboardingLinkStatuses: JoinStatusIDEnum[];
export const calculateIsGatewayOpen: (propertyGatewayModeId: BookingGateWayModeIdEnum) => propertyGatewayModeId is BookingGateWayModeIdEnum.open;
export const calculateIsPremium: (subscriptionTierId: PropertySubscriptionTierIdEnum) => subscriptionTierId is PropertySubscriptionTierIdEnum.PREMIUM;
export const calculateIsStandard: (subscriptionTierId: PropertySubscriptionTierIdEnum) => subscriptionTierId is PropertySubscriptionTierIdEnum.STANDARD;
export const calculateIsActive: (joinStatusId: JoinStatusIDEnum) => joinStatusId is JoinStatusIDEnum.ListingActive;
export const calculateIsDisabled: (joinStatusId: JoinStatusIDEnum) => joinStatusId is JoinStatusIDEnum.ListingDisabled;
export const calculateIsInactive: (joinStatusId: JoinStatusIDEnum) => joinStatusId is JoinStatusIDEnum.ListingInactive;
export const calculateIsRequestActivation: (joinStatusId: JoinStatusIDEnum) => joinStatusId is JoinStatusIDEnum.ActivationRequested;
export const calculateCanUpgradeToPremium: (joinStatusId: JoinStatusIDEnum) => joinStatusId is JoinStatusIDEnum.ListingActive;
export const calculateIsMigrating: (joinStatusId: JoinStatusIDEnum) => joinStatusId is JoinStatusIDEnum.SetUpInProgress;
export const calculateIsComplete: (completionPercentage: number) => completionPercentage is 100;
export const calculateCanDeactivate: (joinStatusId: JoinStatusIDEnum) => boolean;
interface PropertyTitle {
    DEVELOPMENT: string;
    UNIT: string;
    STREET_NUMBER: string;
    STREET_NAME: string;
}
export const defaultPropertyTitle = "--";
export function generatePropertyTitle(info: PropertyTitle): string;
interface PropertySubtitleArgs {
    propertyId: number;
    numBedrooms: number;
    numBathrooms: number;
}
export function generatePropertySubtitle({ propertyId, numBedrooms, numBathrooms }: PropertySubtitleArgs): string;
export const chaletOrHouse = "Chalet/House";
export function generateStreetNumberNameTitle(streetNumber: string, streetName: string): string;
export function generateDevelopmentUnitTitle(development: string, unit: string): string;
export function bedroomBathroomDisplay(bedrooms: number, bathrooms: number): string;
export function calculatePropertyUnitNumberDisplay(unitNumber: string): string;
export function calculateCanSignIn(joinStatusId: JoinStatusIDEnum, hasCompletedOnboarding: boolean): boolean;
/** #1585 -Aspens #120 */
export const generatePropertyString: ({ propertyId, propertyDevelopment, propertyUnit, }: {
    propertyId: number;
    propertyDevelopment: string;
    propertyUnit: string;
}) => string;
export function isPropertyInWhistler({ resortId }: {
    resortId: ResortIdEnum;
}): boolean;
export function isPropertyInBigWhite({ resortId }: {
    resortId: ResortIdEnum;
}): boolean;
export function hasPropertyContact(property: Property): boolean;
export function simplifyData(data: any): {
    SUCCESS: any;
    DATA: string;
    MESSAGE: any;
} | undefined;
export interface RequestInfo {
    url: string;
    method: string;
    responseCode?: number;
    dataType?: string;
    dataReceived?: any;
}
export type OptionalRequestInfo = Partial<RequestInfo>;
/** This class is a singleton, only one instance can exist in the entire application */
export class RequestTracking {
    maxLen: number;
    requests: RequestInfo[];
    static _instance: RequestTracking;
    constructor(maxLen: number);
    push(request: RequestInfo): void;
    update(url: string, request: OptionalRequestInfo): void;
    getFormattedRequests(): string;
}
export const MAX_REQUESTS_TRACKED = 5;
export const requestTracking: RequestTracking;
interface UserInfo {
    IS_COMPANY?: boolean;
    COMPANY_NAME?: string;
    LAST_NAME: string;
    FIRST_NAME: string;
}
export function generateUserName(user: UserInfo): string;
/** Guest accounts are automatically created with the owner create booking tool if the email does not exist.
 *  These guests are required to fill additional information before their account is considered usable
 */
export function isUserMissingProfileInfo(user: User): boolean;
export function hasGuestRole(user: User): boolean;
export function hasOwnerRole(user: User): boolean;
export function hasCoHostRole(user: User): boolean;
export function hasPropertyManagerRole(user: User): boolean;
export const fetchOptions: FetchOptions;
interface FetchOptions {
    credentials: any;
    headers: {
        cookie: string;
    };
}
interface _Args36 {
    isLive: boolean;
}
export const getStripeToken: ({ isLive }: _Args36) => string;
interface _Args37 {
    isLive: boolean;
}
export const getPlacesApiKey: ({ isLive }: _Args37) => string;
export const ownerSignUpLink = "https://www.alluradirect.com/list/";
export const guestSignUpLink = "https://www.alluradirect.com/signup/";
export const userLogin = "https://www.alluradirect.com/login-guest/";
export const alluraDirectNorthAmericanPhoneNumber = "1-866-425-5872";
export const alluraDirectEmail = "info@alluradirect.com";
export const directVacationsEmail = "info@directvacations.com";
export const alluraDirect = "alluraDirect";
export const directVacations = "DirectVacations";
/** The Mobile Pin is used in The Mobile Walkthrough to confirm that a user has downloaded and entered the following pin.
 * The pin is displayed on the help page of the Mobile App
 */
export const mobilePin = "47839";
export const calculateBrandName: (isDV: boolean) => string;
export const calculateBrandEmail: (isDV: boolean) => string;
export enum GuestURLPathsEnum {
    booking = "guest/booking"
}
/** Produces a url for use in the React Web App
 ** ex: https://staging.alluradirect.com/guest/booking/1234
 */
export const generateGuestBookingPageLink: ({ baseUrl, bookingId }: {
    baseUrl: string;
    bookingId: string | number;
}) => string;

//# sourceMappingURL=types.d.ts.map
