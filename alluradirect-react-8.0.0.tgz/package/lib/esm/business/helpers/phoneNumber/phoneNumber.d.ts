import { CountryCode, CountryCallingCode } from 'libphonenumber-js';
export declare const preferredCountries: CountryCode[];
/** https://www.twilio.com/docs/glossary/what-e164
 
 * E.164 is the international telephone numbering plan that ensures each device on the PSTN has globally unique number.
    This number allows phone calls and text messages can be correctly
    routed to individual phones in different countries. E.164 numbers are formatted [+] [country code] [subscriber number including area code] and can have a maximum of fifteen digits. */
/** for display purposes. As of 2022-01-31, all future phone inputs will require the E164 format : [+] [country code] [subscriber number including area code].
 ** This function will format the E164 format to National or International depending on if the phone number is from North America.
 ** Use this function when displaying phone values on the client.
 */
export declare function formatPhoneNumber(phoneNumber: string): string;
interface E164Format {
    subscriberNumber: number | string;
    countryCallingCode: number | string;
}
/** Phone number to be sent for submission to server */
export declare function formatE164PhoneNumber({ subscriberNumber, countryCallingCode }: E164Format): string;
export declare function parsePhone(phoneNumber: string): {
    countryCode: string;
    country: string;
    subscriberNumber: string;
};
/** We have legacy phone numbers that will not include the + symbol
 ** In order to cover a larger base of phone numbers, we will identify numbers that do not have the + and add it.   */
export declare const handleAddPlusToPhoneNumber: (phoneNumber: string) => string;
export interface CountryAndCode {
    countryCode: CountryCode | string;
    callingCode: CountryCallingCode | string;
    countryName: string;
}
export declare function getAllCountryCallingCodes(): CountryAndCode[];
export {};
