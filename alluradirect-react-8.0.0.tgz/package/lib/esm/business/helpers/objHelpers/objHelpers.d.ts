export declare const generateNestedComputedValue: (path: string, obj: {
    [key: string]: any;
}) => any;
