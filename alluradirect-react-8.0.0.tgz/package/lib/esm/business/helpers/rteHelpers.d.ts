export declare function replaceEmptyRteHtml(html: string): string;
