export declare const encodeParams: (params: {
    [key: string]: unknown;
}) => string;
export declare const generateFormData: (params: {
    [key: string]: unknown | [];
}) => FormData;
export declare const generateBodyParams: (params: any) => URLSearchParams;
/** In React Native UrlSearchParams will not work. We use FormData instead */
export declare const generateFormDataBodyParams: (params: any) => FormData;
export declare const generateURLParams: (params: any) => string;
export declare const generateParamsString: (params: any) => string;
export declare function flattenApiPages(data: any, key: string): any[];
