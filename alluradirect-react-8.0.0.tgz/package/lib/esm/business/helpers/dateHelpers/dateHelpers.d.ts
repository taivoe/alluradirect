import { DateOfBirth } from './types';
import { Dayjs } from 'dayjs';
import dayjs from 'dayjs';
type DateLike = Dayjs | Date | string;
export declare const convertDateToGMTDate: (date: Date) => Date;
export declare const handleAddDay: (date: string | Date | Dayjs) => Dayjs;
export declare const handleAddDays: (date: string | Date | Dayjs, daysToAdd: number) => Dayjs;
export declare const handleRemoveDay: (date: string | Date | Dayjs) => Dayjs;
export declare const daysInCurrentMonth: (year: number, month: number) => number;
export declare const calculateIsDateInPast: (date: string | Date | Dayjs) => boolean;
export declare const calculateIsDateBeforeMandatoryGST: () => boolean;
export declare const convertDateStringToDate: (dateString: string) => Date;
export declare function isValidDate(d: any): boolean;
export declare const checkIsValidDate: (date: dayjs.ConfigType) => boolean;
export declare const calculateIsFinalMonthOfData: (date: dayjs.ConfigType, finalMonth: dayjs.ConfigType) => boolean;
export declare const hourOrDayDifferenceString: ({ fromDateTime, toDateTime }: {
    fromDateTime: Dayjs;
    toDateTime: Dayjs;
}) => string;
export declare const calculateDayDifference: (start: DateLike, end: DateLike) => number;
/** Will return a negative number if the start is before the end, positive otherwise
 *  When start and end differ by a year, dayjs correctly calculates the month difference as +/- 12
 * */
export declare const calculateMonthDifference: (start: DateLike, end: DateLike) => number;
export declare const calculateNights: ({ date1, date2 }: {
    date1: DateLike;
    date2: DateLike;
}) => number;
/**  Number of days difference between selected date and today (negative if date is in past) */
export declare const numberOfDaysUntil: (date: DateLike) => number;
export declare const calculateDifferenceInDays: (start: Date, end: Date) => number;
export declare function serverDaysFromToday(numDays: number): string;
/** time param format: <number><number>:<number><number>.  */
export declare const convert24HourTo12Hour: (time: string) => string;
export declare const parseDOB: (dob: string) => DateOfBirth;
export declare const convertDateToUTCSeconds: (date: Date) => number;
export declare const isDayWithinRange: ({ day, start, end }: {
    day: Dayjs;
    start: Dayjs;
    end: Dayjs;
}) => boolean;
/** Returns true if checked range is infact inside the range of the comparator range */
interface RangeWithinRange {
    checked: {
        start: Dayjs;
        end: Dayjs;
    };
    comparator: {
        start: Dayjs;
        end: Dayjs;
    };
}
export declare const isRangeWithinRange: ({ checked, comparator }: RangeWithinRange) => boolean;
export declare const isWeekendDate: (date: Dayjs) => boolean;
/** dateSent is a YYYY-MM-DD formatted UTC string
 *  timeSent is an HH:MM formatted 24-hour string
 */
export declare function getRelativeTime(dateSent: string, timeSent: string, now?: dayjs.Dayjs): string;
/** Given date and time, returns a Dayjs object corresponding to the server's timezone (PDT)
 * @param date is a YYYY-MM-DD formatted PDT string
 * @param time is an HH:MM formatted 24-hour string (also PDT time)
 * @returns Returns a dayjs object in the PDT timezone
 */
export declare function getDateTime(date: string, time: string): Dayjs;
export declare function getDateWithNoHoursMinutesSeconds(): Dayjs;
export declare function convertDateWithNoHoursMinutesSeconds(date: DateLike): Dayjs;
export declare const serverStringFormat = "YYYY-MM-DD";
export declare const shortMonthDayFormat = "MMM D";
export declare const shortMonthFormat = "MMM D, YYYY";
export declare const longMonthYearFormat = "MMMM YYYY";
export declare const longMonthFormat = "MMMM D, YYYY";
export declare const longMonthOrdinalFormat = "MMMM Do, YYYY";
export declare const shortMonthOrdinalFormat = "MMM Do, YYYY";
export declare const longStringFormat = "dddd, MMMM D, YYYY";
export declare const handleDateObjToStringYYYMMDD: (date: Date) => string;
export declare const dateFormatShortMonthDay: (date: Dayjs) => string;
export declare const dateFormatDialog: (date: Date | Dayjs) => string;
export declare const dateFormatLong: (date: Date | string | Dayjs) => string;
export declare const dateFormatLongMonth: (date: Date | string | Dayjs) => string;
export declare const dateFormatLongString: (date: Date | string | Dayjs) => string;
export declare const dateFormatMontDay: (date: string) => string;
export declare const dateFormatMonthDayYearDayOfWeek: (date: string) => string;
export declare const dateFormatMonthYear: (date: string) => string;
export declare const dateFormatServer: (date: Date | Dayjs) => string;
export declare const dayjsFormatServer: (date: Dayjs) => string;
export declare const dayjsFormatLongOrdinal: (date: Dayjs | string | Date) => string;
export declare const dayjsFormatShortOrdinal: (date: Dayjs) => string;
export declare const getYearsDifferenceExact: (date1: Date, date2: Date) => number;
export {};
