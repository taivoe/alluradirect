export declare const startOfYear: Date;
export declare const oneYearInFuture: Date;
