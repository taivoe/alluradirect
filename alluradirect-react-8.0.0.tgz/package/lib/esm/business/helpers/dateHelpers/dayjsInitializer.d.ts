/** dayjs needs to be initialized in every project it is used in
 *  importing this file should setup dayjs with the required extensions + timezone
 */
export declare function dayjsInitializer(): void;
