export declare const pipe: (...fns: any) => (x: any) => any;
export declare const compose: (...fns: any) => (x: any) => any;
export declare function curry(func: any): (...args: any) => any;
