export declare const stringNewlinesToBrTags: (text: string) => string;
export declare function toDecimal(text: string, decimalPlaces?: number): string;
export declare function hasContent(str: string): boolean;
export declare const truncate: (text: string, length: number) => string;
export declare const handleStripHTML: (str: string) => string;
export declare const isStringHTMLString: (str: string) => boolean;
export declare const handleStripHTMLAndSpaces: (string: string) => string;
/**  Turn a string into first-letter of each word capitalized, rest lowercase form
 *  Example: "TEST" -> "Test", "abc" -> "Abc", "all right" -> "All Right"
 */
export declare function capitalize(str: string): string;
export declare const snakeCaseToSpace: (s: string) => string;
export declare function pluralize(count: number, text: string, pluralizationAffix?: string): string;
/** This is used when looking to provide a singular or plural display. For instance 1 Bathroom vs 2 Bathrooms */
export declare function generateCountString(count: number, text: string, pluralizationAffix?: string): string;
