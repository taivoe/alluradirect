type EnumType = {
    [s: number]: string;
};
export declare const getEnumValues: (enumerable: EnumType) => string[];
export declare const getEnumKeys: (enumerable: EnumType) => string[];
export {};
