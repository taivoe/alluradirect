export declare function arrayMove<T>(arr: T[], oldIndex: number, newIndex: number): T[];
export declare function createEmptyArray(length: number): any[];
/** https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/flat
 *
 * Flattens the array with a depth of 1. Use this instead of .flat for browser compatability
 * https://caniuse.com/array-flat
 * */
export declare function flattenArray<T = any>(arr: T[]): any[];
