interface Args {
    isLive: boolean;
}
export declare const getPlacesApiKey: ({ isLive }: Args) => string;
export {};
