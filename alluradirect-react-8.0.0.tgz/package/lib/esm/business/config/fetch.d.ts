export declare const fetchOptions: FetchOptions;
interface FetchOptions {
    credentials: any;
    headers: {
        cookie: string;
    };
}
export {};
