export declare const developmentMapsKey = "AIzaSyBWM3cDz-C4uU-WlG3K1jjdLkaFbLPtzek";
export declare const liveMapsKey = "AIzaSyBWM3cDz-C4uU-WlG3K1jjdLkaFbLPtzek";
