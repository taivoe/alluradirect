interface Args {
    isLive: boolean;
}
export declare const getStripeToken: ({ isLive }: Args) => string;
export {};
