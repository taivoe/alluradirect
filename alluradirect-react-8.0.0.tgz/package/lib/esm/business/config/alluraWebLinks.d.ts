export declare const ownerSignUpLink = "https://www.alluradirect.com/list/";
export declare const guestSignUpLink = "https://www.alluradirect.com/signup/";
export declare const userLogin = "https://www.alluradirect.com/login-guest/";
