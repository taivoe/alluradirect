export declare const alluraDirectNorthAmericanPhoneNumber = "1-866-425-5872";
export declare const alluraDirectEmail = "info@alluradirect.com";
export declare const directVacationsEmail = "info@directvacations.com";
export declare const alluraDirect = "alluraDirect";
export declare const directVacations = "DirectVacations";
/** The Mobile Pin is used in The Mobile Walkthrough to confirm that a user has downloaded and entered the following pin.
 * The pin is displayed on the help page of the Mobile App
 */
export declare const mobilePin = "47839";
export declare const calculateBrandName: (isDV: boolean) => string;
export declare const calculateBrandEmail: (isDV: boolean) => string;
