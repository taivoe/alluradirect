import { UserMessageSubject, UserRoleIDEnum } from '../../../api/user/types';
export declare const CreateMessage: {
    generateMessageSubjectTitle(userContact: UserMessageSubject, userType: UserRoleIDEnum): string;
    generateMessageSubjectSubtitle(userContact: UserMessageSubject, userType: UserRoleIDEnum): string;
    generateMessageSubjectThumbnail(userContact: UserMessageSubject, userType: UserRoleIDEnum | 0): string;
};
