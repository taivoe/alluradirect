import { CreateMessageSubject } from '../../../customReact/messages/types';
import { UserMessageSubject } from '../../../api/user/types';
export interface Subject {
    title: string;
    subtitle: string;
    subtitle2: string;
}
/** For display in message threads */
export declare function generateSelectedSubjectDisplay({ subject, isOwnerRole, }: {
    subject: CreateMessageSubject | undefined;
    isOwnerRole: boolean;
}): string;
/** For display in message subject select dialog */
export declare function generateReservationSubject({ subject, isOwnerMode, }: {
    subject: UserMessageSubject;
    isOwnerMode: boolean;
}): Subject;
/** For display in message subject select dialog
 * Bookings are also being fed through this function; added date check on BOOKING object, and removed (sendDate) when none found for cleaner UI
*/
export declare function generateOwnerInquirySubject(subject: UserMessageSubject): Subject;
