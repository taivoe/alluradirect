import { UserMessageOverview } from '../../../api/user/types';
export declare function generateContactName(overviewMessage: UserMessageOverview): string;
export declare function generateLastMessageSentTime(overviewMessage: UserMessageOverview): string;
export declare function generateNumberOfUnread(overviewMessage: UserMessageOverview): string;
export declare function hasNextReservation(overviewMessage: UserMessageOverview): boolean;
export declare function generateMessageProperty(overviewMessage: UserMessageOverview): string;
