import { BookingGateWayModeIdEnum, JoinStatusIDEnum, Property, PropertySubscriptionTierIdEnum } from '../../api/property/types';
import { ResortIdEnum } from '../../api/ownerFormInputs/types';
/** A property can access the dashboard if the Listing is Active, or if they have gone from Active to inactive.
 * An inactive property status is not possible without completing onboarding.
 * A deactivation requested property can still access dashboard (Jira: REMDASH-3934)
 */
export declare const dashboardLinkStatuses: JoinStatusIDEnum[];
export declare const onboardingLinkStatuses: JoinStatusIDEnum[];
export declare const calculateIsGatewayOpen: (propertyGatewayModeId: BookingGateWayModeIdEnum) => propertyGatewayModeId is BookingGateWayModeIdEnum.open;
export declare const calculateIsPremium: (subscriptionTierId: PropertySubscriptionTierIdEnum) => subscriptionTierId is PropertySubscriptionTierIdEnum.PREMIUM;
export declare const calculateIsStandard: (subscriptionTierId: PropertySubscriptionTierIdEnum) => subscriptionTierId is PropertySubscriptionTierIdEnum.STANDARD;
export declare const calculateIsActive: (joinStatusId: JoinStatusIDEnum) => joinStatusId is JoinStatusIDEnum.ListingActive;
export declare const calculateIsDisabled: (joinStatusId: JoinStatusIDEnum) => joinStatusId is JoinStatusIDEnum.ListingDisabled;
export declare const calculateIsInactive: (joinStatusId: JoinStatusIDEnum) => joinStatusId is JoinStatusIDEnum.ListingInactive;
export declare const calculateIsRequestActivation: (joinStatusId: JoinStatusIDEnum) => joinStatusId is JoinStatusIDEnum.ActivationRequested;
export declare const calculateCanUpgradeToPremium: (joinStatusId: JoinStatusIDEnum) => joinStatusId is JoinStatusIDEnum.ListingActive;
export declare const calculateIsMigrating: (joinStatusId: JoinStatusIDEnum) => joinStatusId is JoinStatusIDEnum.SetUpInProgress;
export declare const calculateIsComplete: (completionPercentage: number) => completionPercentage is 100;
export declare const calculateCanDeactivate: (joinStatusId: JoinStatusIDEnum) => boolean;
interface PropertyTitle {
    DEVELOPMENT: string;
    UNIT: string;
    STREET_NUMBER: string;
    STREET_NAME: string;
}
export declare const defaultPropertyTitle = "--";
export declare function generatePropertyTitle(info: PropertyTitle): string;
interface PropertySubtitleArgs {
    propertyId: number;
    numBedrooms: number;
    numBathrooms: number;
}
export declare function generatePropertySubtitle({ propertyId, numBedrooms, numBathrooms }: PropertySubtitleArgs): string;
export declare const chaletOrHouse = "Chalet/House";
export declare function generateStreetNumberNameTitle(streetNumber: string, streetName: string): string;
export declare function generateDevelopmentUnitTitle(development: string, unit: string): string;
export declare function bedroomBathroomDisplay(bedrooms: number, bathrooms: number): string;
export declare function calculatePropertyUnitNumberDisplay(unitNumber: string): string;
export declare function calculateCanSignIn(joinStatusId: JoinStatusIDEnum, hasCompletedOnboarding: boolean): boolean;
/** #1585 -Aspens #120 */
export declare const generatePropertyString: ({ propertyId, propertyDevelopment, propertyUnit, }: {
    propertyId: number;
    propertyDevelopment: string;
    propertyUnit: string;
}) => string;
export declare function isPropertyInWhistler({ resortId }: {
    resortId: ResortIdEnum;
}): boolean;
export declare function isPropertyInBigWhite({ resortId }: {
    resortId: ResortIdEnum;
}): boolean;
export declare function hasPropertyContact(property: Property): boolean;
export {};
