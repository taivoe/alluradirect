export declare function simplifyData(data: any): {
    SUCCESS: any;
    DATA: string;
    MESSAGE: any;
} | undefined;
