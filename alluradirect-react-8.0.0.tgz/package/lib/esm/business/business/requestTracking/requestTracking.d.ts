import { OptionalRequestInfo, RequestInfo } from './types';
/** This class is a singleton, only one instance can exist in the entire application */
export declare class RequestTracking {
    maxLen: number;
    requests: RequestInfo[];
    static _instance: RequestTracking;
    constructor(maxLen: number);
    push(request: RequestInfo): void;
    update(url: string, request: OptionalRequestInfo): void;
    getFormattedRequests(): string;
}
export declare const MAX_REQUESTS_TRACKED = 5;
export declare const requestTracking: RequestTracking;
