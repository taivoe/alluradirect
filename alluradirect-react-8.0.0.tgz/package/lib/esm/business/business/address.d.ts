interface Args {
    STREET_NUMBER: number | string;
    STREET_NAME: string;
    POSTAL: string;
    CITY: string;
    COUNTRY: string;
}
export declare function generateReadableAddress(address: Args): string;
export {};
