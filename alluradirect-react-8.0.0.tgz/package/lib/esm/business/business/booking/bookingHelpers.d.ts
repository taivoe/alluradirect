import { Booking, BookingStatusId, BookingStatusMessage, CustomMessage, EditBookingBody, FullBooking, SparseBooking } from '../../../api/booking/types';
import dayjs, { Dayjs } from 'dayjs';
import { PropertySurcharge } from '../../../api/property/types';
export declare const hasReview: (booking: SparseBooking) => boolean;
export declare const hasMadePayment: (booking: SparseBooking) => boolean;
export declare const canMakeBookingPayment: (bookingStatusId: BookingStatusId) => bookingStatusId is BookingStatusId.DepositPaidDue;
export declare const hasVisiblePropertyGuideBookBtn: (bookingStatusId: BookingStatusId, bookingDeparture: string) => boolean;
export declare const hasVisibleRebookPropertyBtn: (bookingDeparture: string) => boolean;
export declare const isCurrentReservation: (arrival: string, departure: string) => boolean;
export declare const isPastReservation: (departure: string) => boolean;
type PendingReservationArgs = Pick<Booking, 'STATUS' | 'FLAGS' | 'PAYMENT'>;
export declare const isPendingReservation: ({ STATUS, FLAGS, PAYMENT }: PendingReservationArgs) => boolean;
export declare const canViewPropertyGuidebook: (statusId: BookingStatusId, arrival: string, departure: string) => boolean;
export declare const propertyGuidebookAvailableDate: (arrival: string) => dayjs.Dayjs;
export declare const propertyGuidebookAvailableDateFormatted: (arrival: string) => string;
interface GuestRequestModifyArgs {
    departure: string;
    bookingStatusId: BookingStatusId;
}
/** Comment from Matt: A booking would be adjustable as long as the departure date is not today or in the past.
 * Example:  Dec 11 - Dec 15
 * On the checkout morning of Dec 15, they could NOT adjust it as it wouldnt give the host enough time to approve/adjust pricing
 * The night before the checkout (Dec 14), is a likely scenario to extend the reservation.  “The snow is amazing, lets stay a few more days!”
 *
 * A cancelled booking is not editable
 */
export declare const canGuestRequestToModifyBooking: ({ departure, bookingStatusId }: GuestRequestModifyArgs) => boolean;
interface HostModifyBookingArgs {
    departure: string;
    bookingStatusId: BookingStatusId;
}
/** Hosts cannot modify a booking that is cancelled or is in the past.
 * This is similar to the guest modify booking except the owner can modify on the last day for added flexibility
 *
 * In the future hosts may need certain permissions to modify a booking (think co-host or property manager with limited ability maybe)
 */
export declare const canHostModifyBooking: ({ departure, bookingStatusId }: HostModifyBookingArgs) => boolean;
interface HostModifyBookingStartDateArgs {
    arrival: string;
}
/** The host can modify the booking start date up to and including the day of arrival */
export declare const canHostModifyBookingStartDate: ({ arrival }: HostModifyBookingStartDateArgs) => boolean;
/** Deprecated, use canGuestRequestToModifyBooking instead. Create canHostModifyBooking once details are confirmed */
export declare const canModifyBooking: (arrival: string, statusId: BookingStatusId) => boolean;
export declare const confirmationPropertyGuidebookText: (statusId: BookingStatusId, arrival: string) => string;
export declare const isPaymentButtonVisible: (statusId: BookingStatusId) => statusId is BookingStatusId.ReservationRequest | BookingStatusId.DepositPaidDue;
/** Bookings can only be reviewed if the balance is paid, they are departing or have departed and the booking is less than 2 years in the past */
export declare const canReviewBooking: (statusId: BookingStatusId, departure: string) => boolean;
export declare const reservationStatusText: (statusId: BookingStatusId, isCurrentReservation: boolean, hasMadePayment: boolean) => BookingStatusMessage.ReservationRequested | BookingStatusMessage.DepositDue | BookingStatusMessage.PaymentDue | BookingStatusMessage.Confirmed | BookingStatusMessage.Cancelled | BookingStatusMessage.ReservationDeclined | BookingStatusMessage.LatePayment | BookingStatusMessage.UnknownStatusId;
export declare const balanceText: ({ amountOutstanding, statusId, balanceDueDate, depositDueDate, hasMadePayment, }: {
    amountOutstanding: string;
    statusId: BookingStatusId;
    balanceDueDate: string;
    depositDueDate: string;
    hasMadePayment: boolean;
}) => string;
export declare function hasPerGuestMessage(customMessage: CustomMessage): boolean;
export declare function hasCustomMessage(message: string): boolean;
export declare function hasCustomEntryCode(entryCode: string): boolean;
export declare function generateCustomMessagePreview(message: string): string;
export declare const convertBookingServerToParams: (booking: FullBooking) => EditBookingBody;
export declare const generateBookingStatusDetails: (booking: FullBooking) => {
    hasPaidDeposit: boolean;
    hasPaidFull: boolean;
    isFullPayment: boolean;
    hasDamangeDepositAmount: boolean;
};
export declare const generateSurchargeIds: (isPetFeeEnabled: boolean, isCleaningFeeEnabled: boolean) => string;
export declare const generateSurchargeData: (surcharges: PropertySurcharge[]) => {
    petFeeAmount: string;
    isPetFeeEnabled: boolean;
    cleaningFeeAmount: string;
    isCleaningFeeEnabled: boolean;
    surchargeIds: string;
};
export declare const calculateIsWithinBalanceDate: (arrival: Dayjs, balanceDaysBefore: number) => boolean;
export declare const generateRateQuoteErrorData: (start: Dayjs, balanceDaysBeforeArrival: number, propertyDepositPercentage: number) => {
    PRICE_PER_NIGHT: number;
    BOOKING_NET: string;
    BALANCE_DUE_DATE: string;
    DEPOSIT_DUE_DATE: string;
    DEPOSIT_PERCENTAGE: number;
};
export declare const isDamageDepositCollected: (booking: FullBooking) => boolean;
export {};
