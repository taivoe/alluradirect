import { FullBooking } from '../../../api/booking/types';
export declare const transactionText: {
    /** Section of a reservation screen/page where billing, invoice, revenue, bank info is deisplayed */
    billingDetails: string;
    /** A bill that a guest receives for booking with alluraDirect */
    reservationInvoice: string;
    /** A bill that a guest receives for booking with an allura partner (Whistler) */
    partnerInvoice: string;
    /** Summary of deposits that the owner has received from a booking */
    bankDeposits: string;
    /** A breakdown of the total amount that the owner will receive from a booking */
    revenueReceivedSummary: string;
    /** Price per night * number of nights */
    accommodation: string;
    cleaningAndPetFees: string;
    /** Service fee that the guest is charged for booking with alluraDirect */
    guestServiceFee: string;
    /** The total amount due for a booking. Includes fees, taxes etc */
    reservationTotal: string;
    partnerCommissionFee: string;
    damageDeposit: string;
    creditCardFee: string;
    bookingCommission: string;
    /** Non-resident only */
    nr6Withheld: string;
    totalDepositedToBank: string;
    /** Either the property owner or alluraDirect */
    taxRemitter: string;
    /** Property managers want an additional cut of the booking fee */
    propertyManagerServiceFee: string;
};
export declare function isInflatedBooking(booking: FullBooking): boolean;
