import { Amenity, NameIdItem } from '../../../api/types';
import { Property } from '../../../api/property/types';
import { PropertyAmenityCategories } from './amenitiesTypes';
interface Args {
    property: Property;
    formAmenity: NameIdItem;
    section: PropertyAmenityCategories;
}
/** Check if a formInputs amenity is enabled (exists) in the property object */
export declare function propertyHasAmenity({ property, formAmenity, section }: Args): boolean;
export declare function getPropertyAmenity({ property, formAmenity, section }: Args): Amenity | undefined;
export declare function amenityHasInstructions(amenity: Amenity): boolean;
export declare function amenityHasDescription(amenity: Amenity): boolean;
export declare function isWifiAmenity(amenityId: number): boolean;
export declare function amenityHasAccessCode(amenityId: number): boolean;
interface GenerateAmenityArgs {
    ID: number;
    NAME: string;
    INSTRUCTIONS: string;
    DESCRIPTION: string;
    PROPERTY_AMENITY_ID?: number;
    ACCESS_CODE?: string;
    INTERNET_NETWORK_NAME?: string;
    INTERNET_PASSWORD?: string;
}
export declare function generateAmenity({ ID, NAME, INSTRUCTIONS, DESCRIPTION, PROPERTY_AMENITY_ID, ACCESS_CODE, INTERNET_NETWORK_NAME, INTERNET_PASSWORD, }: GenerateAmenityArgs): Amenity;
export {};
