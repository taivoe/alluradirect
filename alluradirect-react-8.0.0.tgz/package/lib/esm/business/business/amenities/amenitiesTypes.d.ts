export declare enum PropertyAmenityCategories {
    BUILDING = "BUILDING",
    ESSENTIAL = "ESSENTIAL",
    KITCHEN = "KITCHEN",
    PRIVATE = "PRIVATE",
    SAFETY = "SAFETY"
}
