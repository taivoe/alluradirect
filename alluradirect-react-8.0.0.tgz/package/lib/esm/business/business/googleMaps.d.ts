import { Address } from '../../api/types';
interface GetMapsKeyArgs {
    isLive: boolean;
}
export declare const getMapsKey: ({ isLive }: GetMapsKeyArgs) => string;
export declare function generateMapsAddressURL(address: Address): string;
interface Args {
    address: Address;
    isLive: boolean;
}
export declare function generateMapsEmbedAddressURL({ address, isLive }: Args): string;
/**
 * google recommends formatting queries in the format suggested by the local region.
 * Since alluraDirect currently operates out of Canada we should use the Canadian postal code format
 * The following code follows the postal code format + the address result obtained from sample google maps queries
 *
 * https://www.canadapost-postescanada.ca/cpc/en/support/kb/addressing/accuracy/addressing-mail-accurately
 * https://developers.google.com/maps/faq#geocoder_queryformat
 */
export declare function generateQueryFromAddress({ STREET_NUMBER, STREET_NAME, CITY, REGION, POSTAL, }: Pick<Address, 'STREET_NUMBER' | 'STREET_NAME' | 'CITY' | 'REGION' | 'POSTAL'>): string;
export {};
