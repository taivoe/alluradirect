import { User } from '../../../api/user/types';
interface UserInfo {
    IS_COMPANY?: boolean;
    COMPANY_NAME?: string;
    LAST_NAME: string;
    FIRST_NAME: string;
}
export declare function generateUserName(user: UserInfo): string;
/** Guest accounts are automatically created with the owner create booking tool if the email does not exist.
 *  These guests are required to fill additional information before their account is considered usable
 */
export declare function isUserMissingProfileInfo(user: User): boolean;
export declare function hasGuestRole(user: User): boolean;
export declare function hasOwnerRole(user: User): boolean;
export declare function hasCoHostRole(user: User): boolean;
export declare function hasPropertyManagerRole(user: User): boolean;
export {};
