import { AccessCodeIdEnum, AccessCodeTypeIDEnum, AccessMethodIdEnum } from '../../../api/ownerFormInputs/types';
import { AccessToUnit } from '../../../api/property/types';
import { BookingStatusId } from '../../../api/booking/types';
import dayjs, { Dayjs } from 'dayjs';
/** Guests can view the access code on the day of arrival, owners can view the access code at any time
 * @param arrival is a yyyy-mm-dd formatted string
 */
export declare function accessCodeAvailableDate(arrival: string): Dayjs;
/** Can the guest view the access code for a specific booking */
export declare function canViewAccessCode({ bookingStatusId, arrival, departure, }: {
    bookingStatusId: BookingStatusId;
    arrival: string;
    departure: string;
}): boolean;
/** Owner must enter access codes for a reservation 9 days before the arrival date
 * This is important only when the owner has selected the access code option that requires a unique code for each reservation
 */
export declare const accessCodeDueDate: (arrival: string) => dayjs.Dayjs;
export declare function generateAccessCodeDueDate(arrival: string): string;
export declare enum BookingAccessCodeTextEnum {
    noLongerAvailable = "No Longer Available",
    payDepositFirst = "Make Payment First",
    providedByHost = "Provided by Host",
    providedByFrontDesk = "Provided by Front Desk",
    guestUnavailableDoorCode = "Unavailable, Contact Host"
}
interface BookingAccessCodeText {
    isOwnerMode: boolean;
    bookingStatusId: BookingStatusId;
    accessToUnit: AccessToUnit;
    arrival: string;
    departure: string;
    customDoorCode?: string;
}
/** Text that will appear for the guest whenever they try to view the door code / access code */
export declare function generateBookingAccessCodeText({ isOwnerMode, bookingStatusId, accessToUnit, arrival, departure, customDoorCode, }: BookingAccessCodeText): string;
export declare function generateAccessCodeLabel({ accessToUnit }: {
    accessToUnit: AccessToUnit;
}): string;
interface AccessOptions {
    codeId: AccessCodeIdEnum;
    methodId: AccessMethodIdEnum;
    typeId: AccessCodeTypeIDEnum;
}
export declare function accessToUnitSelectedOptions({ codeId, methodId, typeId }: AccessOptions): {
    hasSelectedPropertyAccessType: boolean;
    hasSelectedAccessMethod: boolean;
    hasSelectedAccessCode: boolean;
    hasStandardCode: boolean;
    hasAccessCode: boolean;
    hasAccessCodeEmailMethod: boolean;
    hasKeyLockboxMethod: boolean;
    hasFrontDeskMethod: boolean;
    hasOtherDeskMethod: boolean;
    hasAccessCodeSection: boolean;
};
export {};
