import { FetchMethodTypes, FetchMethods } from '../../apiHooks/types';
import React from 'react';
export interface QueryFnOptions {
    isOffline: boolean;
    method?: FetchMethods | FetchMethodTypes;
    values?: any;
    /** Special encoding required for subforms */
    isSubform?: boolean;
    /** Ignore any potential data-transformations, data is already formatted */
    isCustomSendData?: boolean;
}
interface QueryContextValues {
    isOffline: boolean;
    queryFn: <TData = unknown>(url: string, options: QueryFnOptions) => Promise<TData>;
    onSuccessToast: (data: any) => void;
    onErrorToast: (data: any) => void;
}
export declare const QueryContext: React.Context<QueryContextValues | null>;
export declare const useQueryContext: () => QueryContextValues;
interface Props {
    children: React.ReactNode;
}
/** This Provider should be wrapped at a high-level around an app that uses it.
 * Allows access to useAppMutation and useAppQuery
 * Allows us to avoid re-writing hooks using two different version of useAppQuery and useAppMutation
 * Provides runtime configuration changes which determine offline functionality, how toasts are display and the query function that is used
 * */
export declare const QueryContextProvider: ({ children, isOffline, onErrorToast, onSuccessToast, queryFn, }: Props & QueryContextValues) => import("react/jsx-runtime").JSX.Element;
export {};
