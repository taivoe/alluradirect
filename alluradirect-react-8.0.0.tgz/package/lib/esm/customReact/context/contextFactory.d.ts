import React from 'react';
/** Use this function to create a new context with initial data, a context provider, and a hook that will consume the context  */
export declare function contextFactory<TProviderValue>(): {
    Context: React.Context<TProviderValue | null>;
    useContext: () => TProviderValue & ({} | undefined);
    ContextProvider: ({ children, value }: {
        children: React.ReactNode;
        value: TProviderValue;
    }) => React.ReactElement;
};
