import { RequiredSubformsEnum, OptionalSubformsEnum } from '../../../api/subformNames';
export declare const generateCheckInOutFields: (subformName: RequiredSubformsEnum.CheckInOutForm | OptionalSubformsEnum.CheckInOutFormOptional) => {
    buildingCode: {
        label: string;
        field: string;
    };
    garbageCode: {
        label: string;
        field: string;
    };
    checkIn: {
        label: string;
        field: string;
    };
    checkOut: {
        label: string;
        field: string;
    };
    /** RTE fields */
    checkInProcedure: {
        label: string;
        field: string;
    };
    lateCheckInProcedure: {
        label: string;
        field: string;
    };
    checkOutProcedure: {
        label: string;
        field: string;
    };
    garbageRecyclingInstructions: {
        label: string;
        field: string;
    };
};
