import { OptionalSubformsEnum, RequiredSubformsEnum } from '../../../api/subformNames';
import { Property } from '../../../api/property/types';
export declare const generateCheckInOutValues: (propertyObject: Property, subformName: RequiredSubformsEnum.CheckInOutForm | OptionalSubformsEnum.CheckInOutFormOptional) => {
    [x: string]: {
        RULES: {
            ID: number;
            ADVANCED_BOOKING: {
                NAME: string;
                ID: number;
            };
            CHECK_IN: string;
            CHECK_OUT: string;
            MAX_BOOKABLE_DAYS: number;
            MAX_GUESTS: number;
            MIN_AGE_TO_BOOK: number;
            QUIET_TIME: string;
        };
        INSTRUCTIONS: {
            LATE_CHECK_IN: string;
            CHECK_IN: string;
            CHECK_OUT: string;
            GARBAGE_RECYCLING: string;
        };
        CODES: {
            DEVELOPMENT_DOOR_CODE: string;
            GARBAGE_RECYCLING_CODE: string;
        };
    };
};
