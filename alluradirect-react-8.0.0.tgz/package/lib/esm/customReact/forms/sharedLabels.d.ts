export declare const buildingEntry = "Building Entry";
export declare const garbageRecycling = "Garbage/Recycling";
export declare const garageParking = "Garage/Parking";
export declare const wifiName = "Wifi Name";
export declare const wifiPassword = "Wifi Password";
