import React from 'react';
declare const initialValues: {
    message: string;
};
interface Props {
    onSubmit: (values: typeof initialValues, helpers: any) => void;
    children: React.ReactNode;
}
export declare const CreateMessageForm: ({ children, onSubmit }: Props) => import("react/jsx-runtime").JSX.Element;
export {};
