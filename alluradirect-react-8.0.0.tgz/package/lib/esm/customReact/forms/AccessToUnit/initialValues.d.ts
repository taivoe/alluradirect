import { Property } from '../../../api/property/types';
export declare const generateAccessToUnitValues: (property: Property) => {
    AccessToUnitForm: {
        ACCESS_TO_UNIT: {
            CODES: {
                BIKE_LOCKER_CODE: string;
                DEVELOPMENT_DOOR_CODE: string;
                DEVELOPMENT_GYM_CODE: string;
                DEVELOPMENT_HOT_TUB_CODE: string;
                DEVELOPMENT_POOL_CODE: string;
                DEVELOPMENT_SAUNA_CODE: string;
                DEVELOPMENT_STEAM_ROOM_CODE: string;
                FRONT_DOOR_CODE: string;
                GAMES_REC_ROOM_CODE: string;
                GARAGE_DOOR_CODE: string;
                GARBAGE_RECYCLING_CODE: string;
                ID: number;
                INTERNET_NETWORK_NAME: string;
                INTERNET_PASSWORD: string;
                PHONE_NUMBER: string;
                PROPERTY_ID: string;
                SKI_LOCKER_CODE: string;
                DATE_LAST_UPDATED: string;
            };
            CHECK_IN_PROCEDURE: string;
            CODE: {
                NAME: string;
                ID: import("../../../api/ownerFormInputs/types").AccessCodeIdEnum;
            };
            METHOD: {
                NAME: string;
                ID: import("../../../api/ownerFormInputs/types").AccessMethodIdEnum;
            };
            STANDARD_CODE: string;
            TYPE: {
                NAME: string;
                ID: import("../../../api/ownerFormInputs/types").AccessCodeTypeIDEnum;
            };
        };
    };
};
export type AccessToUnitFormikValues = ReturnType<typeof generateAccessToUnitValues>;
