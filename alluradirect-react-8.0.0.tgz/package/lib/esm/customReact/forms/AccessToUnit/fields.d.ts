export declare const accessToUnitFields: {
    /** Main access to unit settings */
    type: {
        label: string;
        field: string;
    };
    method: {
        label: string;
        field: string;
    };
    code: {
        label: string;
        field: string;
    };
    standardCode: {
        label: string;
        field: string;
    };
    /** Additional access codes */
    bike: {
        label: string;
        field: string;
    };
    /** building/development are used interchangeably here */
    building: {
        label: string;
        field: string;
    };
    gym: {
        label: string;
        field: string;
    };
    hottub: {
        label: string;
        field: string;
    };
    pool: {
        label: string;
        field: string;
    };
    sauna: {
        label: string;
        field: string;
    };
    steamroom: {
        label: string;
        field: string;
    };
    recRoom: {
        label: string;
        field: string;
    };
    garage: {
        label: string;
        field: string;
    };
    garbage: {
        label: string;
        field: string;
    };
    ski: {
        label: string;
        field: string;
    };
    /** Internet codes */
    internetName: {
        label: string;
        field: string;
    };
    internetPassword: {
        label: string;
        field: string;
    };
};
