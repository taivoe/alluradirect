import React from "react";
interface Props {
    children: React.ReactNode;
}
export declare const AccessToUnitFormikForm: ({ children }: Props) => import("react/jsx-runtime").JSX.Element;
export {};
