export declare const amenityEditFields: {
    wifiName: {
        label: string;
        field: string;
    };
    wifiPassword: {
        label: string;
        field: string;
    };
};
