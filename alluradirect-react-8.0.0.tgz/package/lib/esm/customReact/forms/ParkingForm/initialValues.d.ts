import { Property } from '../../../api/property/types';
export declare const generateParkingValues: ({ PARKING, INSTRUCTIONS: { PARKING: parkingInstructions }, CODES, }: Property) => {
    ParkingForm: {
        PARKING: {
            INSTRUCTIONS: string;
            CODES: {
                GARAGE_DOOR_CODE: string;
            };
            DESCRIPTION: string;
            HAS_ADDITIONAL_FREE_SPOTS: string;
            HAS_ADDITIONAL_PAID_SPOTS: string;
            IS_DEFAULT_DESCRIPTION: boolean;
            NUM_SPOTS_PROVIDED: string;
        };
    };
};
