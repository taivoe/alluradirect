export declare const generateParkingText: ({ numberOfSpotsProvided, hasAdditionalFreeSpots, hasAdditionalPaidSpots, }: {
    numberOfSpotsProvided: number;
    hasAdditionalFreeSpots: boolean;
    hasAdditionalPaidSpots: boolean;
}) => string;
