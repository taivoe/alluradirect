export declare const parkingFields: {
    garageCode: {
        label: string;
        field: string;
    };
};
