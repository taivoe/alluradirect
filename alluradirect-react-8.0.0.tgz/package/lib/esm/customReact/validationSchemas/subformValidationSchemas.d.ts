import * as yup from 'yup';
import { OptionalSubformsEnum, RequiredSubformsEnum } from '../../api/subformNames';
export declare const accountOwner: {
    AccountOwnerForm: yup.ObjectSchema<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
        USER: yup.ObjectSchema<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
            IS_COMPANY: import("yup/lib/boolean").RequiredBooleanSchema<boolean | null | undefined, import("yup/lib/types").AnyObject>;
            COMPANY_NAME: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            FIRST_NAME: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            LAST_NAME: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            EMAIL: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
            PHONE: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
            IS_SMS_VERIFIED: import("yup/lib/boolean").RequiredBooleanSchema<boolean | undefined, import("yup/lib/types").AnyObject>;
            IS_EMAIL_VERIFIED: import("yup/lib/boolean").RequiredBooleanSchema<boolean | undefined, import("yup/lib/types").AnyObject>;
            ADDRESS: yup.ObjectSchema<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
                STREET_NAME: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                STREET_NUMBER: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                UNIT: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
                CITY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                POSTAL: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                REGION: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                COUNTRY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
            }>, import("yup/lib/object").AnyObject, import("yup/lib/object").TypeOfShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
                STREET_NAME: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                STREET_NUMBER: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                UNIT: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
                CITY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                POSTAL: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                REGION: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                COUNTRY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
            }>>, import("yup/lib/object").AssertsShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
                STREET_NAME: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                STREET_NUMBER: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                UNIT: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
                CITY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                POSTAL: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                REGION: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                COUNTRY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
            }>>>;
        }>, import("yup/lib/object").AnyObject, import("yup/lib/object").TypeOfShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
            IS_COMPANY: import("yup/lib/boolean").RequiredBooleanSchema<boolean | null | undefined, import("yup/lib/types").AnyObject>;
            COMPANY_NAME: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            FIRST_NAME: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            LAST_NAME: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            EMAIL: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
            PHONE: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
            IS_SMS_VERIFIED: import("yup/lib/boolean").RequiredBooleanSchema<boolean | undefined, import("yup/lib/types").AnyObject>;
            IS_EMAIL_VERIFIED: import("yup/lib/boolean").RequiredBooleanSchema<boolean | undefined, import("yup/lib/types").AnyObject>;
            ADDRESS: yup.ObjectSchema<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
                STREET_NAME: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                STREET_NUMBER: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                UNIT: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
                CITY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                POSTAL: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                REGION: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                COUNTRY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
            }>, import("yup/lib/object").AnyObject, import("yup/lib/object").TypeOfShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
                STREET_NAME: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                STREET_NUMBER: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                UNIT: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
                CITY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                POSTAL: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                REGION: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                COUNTRY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
            }>>, import("yup/lib/object").AssertsShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
                STREET_NAME: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                STREET_NUMBER: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                UNIT: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
                CITY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                POSTAL: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                REGION: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                COUNTRY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
            }>>>;
        }>>, import("yup/lib/object").AssertsShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
            IS_COMPANY: import("yup/lib/boolean").RequiredBooleanSchema<boolean | null | undefined, import("yup/lib/types").AnyObject>;
            COMPANY_NAME: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            FIRST_NAME: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            LAST_NAME: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            EMAIL: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
            PHONE: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
            IS_SMS_VERIFIED: import("yup/lib/boolean").RequiredBooleanSchema<boolean | undefined, import("yup/lib/types").AnyObject>;
            IS_EMAIL_VERIFIED: import("yup/lib/boolean").RequiredBooleanSchema<boolean | undefined, import("yup/lib/types").AnyObject>;
            ADDRESS: yup.ObjectSchema<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
                STREET_NAME: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                STREET_NUMBER: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                UNIT: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
                CITY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                POSTAL: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                REGION: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                COUNTRY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
            }>, import("yup/lib/object").AnyObject, import("yup/lib/object").TypeOfShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
                STREET_NAME: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                STREET_NUMBER: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                UNIT: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
                CITY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                POSTAL: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                REGION: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                COUNTRY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
            }>>, import("yup/lib/object").AssertsShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
                STREET_NAME: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                STREET_NUMBER: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                UNIT: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
                CITY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                POSTAL: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                REGION: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                COUNTRY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
            }>>>;
        }>>>;
    }>, import("yup/lib/object").AnyObject, import("yup/lib/object").TypeOfShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
        USER: yup.ObjectSchema<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
            IS_COMPANY: import("yup/lib/boolean").RequiredBooleanSchema<boolean | null | undefined, import("yup/lib/types").AnyObject>;
            COMPANY_NAME: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            FIRST_NAME: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            LAST_NAME: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            EMAIL: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
            PHONE: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
            IS_SMS_VERIFIED: import("yup/lib/boolean").RequiredBooleanSchema<boolean | undefined, import("yup/lib/types").AnyObject>;
            IS_EMAIL_VERIFIED: import("yup/lib/boolean").RequiredBooleanSchema<boolean | undefined, import("yup/lib/types").AnyObject>;
            ADDRESS: yup.ObjectSchema<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
                STREET_NAME: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                STREET_NUMBER: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                UNIT: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
                CITY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                POSTAL: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                REGION: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                COUNTRY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
            }>, import("yup/lib/object").AnyObject, import("yup/lib/object").TypeOfShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
                STREET_NAME: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                STREET_NUMBER: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                UNIT: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
                CITY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                POSTAL: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                REGION: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                COUNTRY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
            }>>, import("yup/lib/object").AssertsShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
                STREET_NAME: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                STREET_NUMBER: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                UNIT: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
                CITY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                POSTAL: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                REGION: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                COUNTRY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
            }>>>;
        }>, import("yup/lib/object").AnyObject, import("yup/lib/object").TypeOfShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
            IS_COMPANY: import("yup/lib/boolean").RequiredBooleanSchema<boolean | null | undefined, import("yup/lib/types").AnyObject>;
            COMPANY_NAME: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            FIRST_NAME: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            LAST_NAME: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            EMAIL: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
            PHONE: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
            IS_SMS_VERIFIED: import("yup/lib/boolean").RequiredBooleanSchema<boolean | undefined, import("yup/lib/types").AnyObject>;
            IS_EMAIL_VERIFIED: import("yup/lib/boolean").RequiredBooleanSchema<boolean | undefined, import("yup/lib/types").AnyObject>;
            ADDRESS: yup.ObjectSchema<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
                STREET_NAME: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                STREET_NUMBER: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                UNIT: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
                CITY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                POSTAL: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                REGION: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                COUNTRY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
            }>, import("yup/lib/object").AnyObject, import("yup/lib/object").TypeOfShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
                STREET_NAME: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                STREET_NUMBER: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                UNIT: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
                CITY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                POSTAL: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                REGION: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                COUNTRY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
            }>>, import("yup/lib/object").AssertsShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
                STREET_NAME: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                STREET_NUMBER: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                UNIT: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
                CITY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                POSTAL: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                REGION: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                COUNTRY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
            }>>>;
        }>>, import("yup/lib/object").AssertsShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
            IS_COMPANY: import("yup/lib/boolean").RequiredBooleanSchema<boolean | null | undefined, import("yup/lib/types").AnyObject>;
            COMPANY_NAME: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            FIRST_NAME: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            LAST_NAME: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            EMAIL: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
            PHONE: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
            IS_SMS_VERIFIED: import("yup/lib/boolean").RequiredBooleanSchema<boolean | undefined, import("yup/lib/types").AnyObject>;
            IS_EMAIL_VERIFIED: import("yup/lib/boolean").RequiredBooleanSchema<boolean | undefined, import("yup/lib/types").AnyObject>;
            ADDRESS: yup.ObjectSchema<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
                STREET_NAME: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                STREET_NUMBER: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                UNIT: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
                CITY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                POSTAL: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                REGION: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                COUNTRY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
            }>, import("yup/lib/object").AnyObject, import("yup/lib/object").TypeOfShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
                STREET_NAME: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                STREET_NUMBER: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                UNIT: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
                CITY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                POSTAL: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                REGION: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                COUNTRY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
            }>>, import("yup/lib/object").AssertsShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
                STREET_NAME: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                STREET_NUMBER: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                UNIT: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
                CITY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                POSTAL: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                REGION: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                COUNTRY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
            }>>>;
        }>>>;
    }>>, import("yup/lib/object").AssertsShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
        USER: yup.ObjectSchema<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
            IS_COMPANY: import("yup/lib/boolean").RequiredBooleanSchema<boolean | null | undefined, import("yup/lib/types").AnyObject>;
            COMPANY_NAME: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            FIRST_NAME: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            LAST_NAME: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            EMAIL: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
            PHONE: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
            IS_SMS_VERIFIED: import("yup/lib/boolean").RequiredBooleanSchema<boolean | undefined, import("yup/lib/types").AnyObject>;
            IS_EMAIL_VERIFIED: import("yup/lib/boolean").RequiredBooleanSchema<boolean | undefined, import("yup/lib/types").AnyObject>;
            ADDRESS: yup.ObjectSchema<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
                STREET_NAME: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                STREET_NUMBER: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                UNIT: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
                CITY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                POSTAL: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                REGION: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                COUNTRY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
            }>, import("yup/lib/object").AnyObject, import("yup/lib/object").TypeOfShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
                STREET_NAME: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                STREET_NUMBER: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                UNIT: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
                CITY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                POSTAL: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                REGION: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                COUNTRY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
            }>>, import("yup/lib/object").AssertsShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
                STREET_NAME: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                STREET_NUMBER: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                UNIT: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
                CITY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                POSTAL: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                REGION: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                COUNTRY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
            }>>>;
        }>, import("yup/lib/object").AnyObject, import("yup/lib/object").TypeOfShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
            IS_COMPANY: import("yup/lib/boolean").RequiredBooleanSchema<boolean | null | undefined, import("yup/lib/types").AnyObject>;
            COMPANY_NAME: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            FIRST_NAME: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            LAST_NAME: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            EMAIL: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
            PHONE: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
            IS_SMS_VERIFIED: import("yup/lib/boolean").RequiredBooleanSchema<boolean | undefined, import("yup/lib/types").AnyObject>;
            IS_EMAIL_VERIFIED: import("yup/lib/boolean").RequiredBooleanSchema<boolean | undefined, import("yup/lib/types").AnyObject>;
            ADDRESS: yup.ObjectSchema<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
                STREET_NAME: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                STREET_NUMBER: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                UNIT: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
                CITY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                POSTAL: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                REGION: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                COUNTRY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
            }>, import("yup/lib/object").AnyObject, import("yup/lib/object").TypeOfShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
                STREET_NAME: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                STREET_NUMBER: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                UNIT: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
                CITY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                POSTAL: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                REGION: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                COUNTRY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
            }>>, import("yup/lib/object").AssertsShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
                STREET_NAME: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                STREET_NUMBER: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                UNIT: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
                CITY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                POSTAL: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                REGION: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                COUNTRY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
            }>>>;
        }>>, import("yup/lib/object").AssertsShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
            IS_COMPANY: import("yup/lib/boolean").RequiredBooleanSchema<boolean | null | undefined, import("yup/lib/types").AnyObject>;
            COMPANY_NAME: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            FIRST_NAME: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            LAST_NAME: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            EMAIL: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
            PHONE: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
            IS_SMS_VERIFIED: import("yup/lib/boolean").RequiredBooleanSchema<boolean | undefined, import("yup/lib/types").AnyObject>;
            IS_EMAIL_VERIFIED: import("yup/lib/boolean").RequiredBooleanSchema<boolean | undefined, import("yup/lib/types").AnyObject>;
            ADDRESS: yup.ObjectSchema<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
                STREET_NAME: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                STREET_NUMBER: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                UNIT: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
                CITY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                POSTAL: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                REGION: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                COUNTRY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
            }>, import("yup/lib/object").AnyObject, import("yup/lib/object").TypeOfShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
                STREET_NAME: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                STREET_NUMBER: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                UNIT: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
                CITY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                POSTAL: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                REGION: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                COUNTRY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
            }>>, import("yup/lib/object").AssertsShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
                STREET_NAME: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                STREET_NUMBER: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                UNIT: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
                CITY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                POSTAL: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                REGION: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
                COUNTRY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
            }>>>;
        }>>>;
    }>>>;
};
export declare const rentalManagerCoHost: {
    PropertyContactForm: yup.ObjectSchema<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
        IS_CUSTOM_PROPERTY_CONTACT: import("yup/lib/boolean").RequiredBooleanSchema<boolean | undefined, import("yup/lib/types").AnyObject>;
        PROPERTY_CONTACT: import("yup/lib/object").OptionalObjectSchema<import("yup/lib/object").ObjectShape, import("yup/lib/object").AnyObject, import("yup/lib/object").TypeOfShape<import("yup/lib/object").ObjectShape>>;
        IS_CO_HOST_MANAGER_ENABLED: import("yup/lib/boolean").RequiredBooleanSchema<boolean | undefined, import("yup/lib/types").AnyObject>;
        CO_HOST: import("yup/lib/object").OptionalObjectSchema<import("yup/lib/object").ObjectShape, import("yup/lib/object").AnyObject, import("yup/lib/object").TypeOfShape<import("yup/lib/object").ObjectShape>>;
    }>, import("yup/lib/object").AnyObject, import("yup/lib/object").TypeOfShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
        IS_CUSTOM_PROPERTY_CONTACT: import("yup/lib/boolean").RequiredBooleanSchema<boolean | undefined, import("yup/lib/types").AnyObject>;
        PROPERTY_CONTACT: import("yup/lib/object").OptionalObjectSchema<import("yup/lib/object").ObjectShape, import("yup/lib/object").AnyObject, import("yup/lib/object").TypeOfShape<import("yup/lib/object").ObjectShape>>;
        IS_CO_HOST_MANAGER_ENABLED: import("yup/lib/boolean").RequiredBooleanSchema<boolean | undefined, import("yup/lib/types").AnyObject>;
        CO_HOST: import("yup/lib/object").OptionalObjectSchema<import("yup/lib/object").ObjectShape, import("yup/lib/object").AnyObject, import("yup/lib/object").TypeOfShape<import("yup/lib/object").ObjectShape>>;
    }>>, import("yup/lib/object").AssertsShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
        IS_CUSTOM_PROPERTY_CONTACT: import("yup/lib/boolean").RequiredBooleanSchema<boolean | undefined, import("yup/lib/types").AnyObject>;
        PROPERTY_CONTACT: import("yup/lib/object").OptionalObjectSchema<import("yup/lib/object").ObjectShape, import("yup/lib/object").AnyObject, import("yup/lib/object").TypeOfShape<import("yup/lib/object").ObjectShape>>;
        IS_CO_HOST_MANAGER_ENABLED: import("yup/lib/boolean").RequiredBooleanSchema<boolean | undefined, import("yup/lib/types").AnyObject>;
        CO_HOST: import("yup/lib/object").OptionalObjectSchema<import("yup/lib/object").ObjectShape, import("yup/lib/object").AnyObject, import("yup/lib/object").TypeOfShape<import("yup/lib/object").ObjectShape>>;
    }>>>;
};
export declare const minPhotos = 5;
export declare const photos: {
    PhotosForm: yup.ObjectSchema<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
        EXTERNAL_URLS: yup.ObjectSchema<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
            URL_AIRBNB: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            URL_VRBO: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            URL_OTHER: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
        }>, import("yup/lib/object").AnyObject, import("yup/lib/object").TypeOfShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
            URL_AIRBNB: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            URL_VRBO: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            URL_OTHER: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
        }>>, import("yup/lib/object").AssertsShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
            URL_AIRBNB: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            URL_VRBO: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            URL_OTHER: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
        }>>>;
        NUM_PHOTOS: yup.NumberSchema<number | undefined, import("yup/lib/types").AnyObject, number | undefined>;
    }>, import("yup/lib/object").AnyObject, import("yup/lib/object").TypeOfShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
        EXTERNAL_URLS: yup.ObjectSchema<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
            URL_AIRBNB: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            URL_VRBO: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            URL_OTHER: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
        }>, import("yup/lib/object").AnyObject, import("yup/lib/object").TypeOfShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
            URL_AIRBNB: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            URL_VRBO: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            URL_OTHER: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
        }>>, import("yup/lib/object").AssertsShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
            URL_AIRBNB: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            URL_VRBO: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            URL_OTHER: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
        }>>>;
        NUM_PHOTOS: yup.NumberSchema<number | undefined, import("yup/lib/types").AnyObject, number | undefined>;
    }>>, import("yup/lib/object").AssertsShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
        EXTERNAL_URLS: yup.ObjectSchema<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
            URL_AIRBNB: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            URL_VRBO: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            URL_OTHER: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
        }>, import("yup/lib/object").AnyObject, import("yup/lib/object").TypeOfShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
            URL_AIRBNB: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            URL_VRBO: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            URL_OTHER: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
        }>>, import("yup/lib/object").AssertsShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
            URL_AIRBNB: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            URL_VRBO: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            URL_OTHER: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
        }>>>;
        NUM_PHOTOS: yup.NumberSchema<number | undefined, import("yup/lib/types").AnyObject, number | undefined>;
    }>>>;
};
export declare const parkingFormSchema: {
    ParkingForm: import("yup/lib/object").OptionalObjectSchema<{
        PARKING: yup.ObjectSchema<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
            DESCRIPTION: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            INSTRUCTIONS: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            HAS_ADDITIONAL_FREE_SPOTS: import("yup/lib/boolean").RequiredBooleanSchema<boolean | null | undefined, import("yup/lib/types").AnyObject>;
            HAS_ADDITIONAL_PAID_SPOTS: import("yup/lib/boolean").RequiredBooleanSchema<boolean | null | undefined, import("yup/lib/types").AnyObject>;
            NUM_SPOTS_PROVIDED: import("yup/lib/number").RequiredNumberSchema<number | undefined, import("yup/lib/types").AnyObject>;
            IS_DEFAULT_DESCRIPTION: import("yup/lib/boolean").RequiredBooleanSchema<boolean | undefined, import("yup/lib/types").AnyObject>;
            CODES: yup.ObjectSchema<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
                GARAGE_DOOR_CODE: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            }>, import("yup/lib/object").AnyObject, import("yup/lib/object").TypeOfShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
                GARAGE_DOOR_CODE: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            }>>, import("yup/lib/object").AssertsShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
                GARAGE_DOOR_CODE: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            }>>>;
        }>, import("yup/lib/object").AnyObject, import("yup/lib/object").TypeOfShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
            DESCRIPTION: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            INSTRUCTIONS: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            HAS_ADDITIONAL_FREE_SPOTS: import("yup/lib/boolean").RequiredBooleanSchema<boolean | null | undefined, import("yup/lib/types").AnyObject>;
            HAS_ADDITIONAL_PAID_SPOTS: import("yup/lib/boolean").RequiredBooleanSchema<boolean | null | undefined, import("yup/lib/types").AnyObject>;
            NUM_SPOTS_PROVIDED: import("yup/lib/number").RequiredNumberSchema<number | undefined, import("yup/lib/types").AnyObject>;
            IS_DEFAULT_DESCRIPTION: import("yup/lib/boolean").RequiredBooleanSchema<boolean | undefined, import("yup/lib/types").AnyObject>;
            CODES: yup.ObjectSchema<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
                GARAGE_DOOR_CODE: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            }>, import("yup/lib/object").AnyObject, import("yup/lib/object").TypeOfShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
                GARAGE_DOOR_CODE: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            }>>, import("yup/lib/object").AssertsShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
                GARAGE_DOOR_CODE: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            }>>>;
        }>>, import("yup/lib/object").AssertsShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
            DESCRIPTION: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            INSTRUCTIONS: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            HAS_ADDITIONAL_FREE_SPOTS: import("yup/lib/boolean").RequiredBooleanSchema<boolean | null | undefined, import("yup/lib/types").AnyObject>;
            HAS_ADDITIONAL_PAID_SPOTS: import("yup/lib/boolean").RequiredBooleanSchema<boolean | null | undefined, import("yup/lib/types").AnyObject>;
            NUM_SPOTS_PROVIDED: import("yup/lib/number").RequiredNumberSchema<number | undefined, import("yup/lib/types").AnyObject>;
            IS_DEFAULT_DESCRIPTION: import("yup/lib/boolean").RequiredBooleanSchema<boolean | undefined, import("yup/lib/types").AnyObject>;
            CODES: yup.ObjectSchema<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
                GARAGE_DOOR_CODE: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            }>, import("yup/lib/object").AnyObject, import("yup/lib/object").TypeOfShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
                GARAGE_DOOR_CODE: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            }>>, import("yup/lib/object").AssertsShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
                GARAGE_DOOR_CODE: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            }>>>;
        }>>>;
    }, import("yup/lib/object").AnyObject, import("yup/lib/object").TypeOfShape<{
        PARKING: yup.ObjectSchema<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
            DESCRIPTION: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            INSTRUCTIONS: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            HAS_ADDITIONAL_FREE_SPOTS: import("yup/lib/boolean").RequiredBooleanSchema<boolean | null | undefined, import("yup/lib/types").AnyObject>;
            HAS_ADDITIONAL_PAID_SPOTS: import("yup/lib/boolean").RequiredBooleanSchema<boolean | null | undefined, import("yup/lib/types").AnyObject>;
            NUM_SPOTS_PROVIDED: import("yup/lib/number").RequiredNumberSchema<number | undefined, import("yup/lib/types").AnyObject>;
            IS_DEFAULT_DESCRIPTION: import("yup/lib/boolean").RequiredBooleanSchema<boolean | undefined, import("yup/lib/types").AnyObject>;
            CODES: yup.ObjectSchema<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
                GARAGE_DOOR_CODE: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            }>, import("yup/lib/object").AnyObject, import("yup/lib/object").TypeOfShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
                GARAGE_DOOR_CODE: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            }>>, import("yup/lib/object").AssertsShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
                GARAGE_DOOR_CODE: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            }>>>;
        }>, import("yup/lib/object").AnyObject, import("yup/lib/object").TypeOfShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
            DESCRIPTION: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            INSTRUCTIONS: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            HAS_ADDITIONAL_FREE_SPOTS: import("yup/lib/boolean").RequiredBooleanSchema<boolean | null | undefined, import("yup/lib/types").AnyObject>;
            HAS_ADDITIONAL_PAID_SPOTS: import("yup/lib/boolean").RequiredBooleanSchema<boolean | null | undefined, import("yup/lib/types").AnyObject>;
            NUM_SPOTS_PROVIDED: import("yup/lib/number").RequiredNumberSchema<number | undefined, import("yup/lib/types").AnyObject>;
            IS_DEFAULT_DESCRIPTION: import("yup/lib/boolean").RequiredBooleanSchema<boolean | undefined, import("yup/lib/types").AnyObject>;
            CODES: yup.ObjectSchema<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
                GARAGE_DOOR_CODE: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            }>, import("yup/lib/object").AnyObject, import("yup/lib/object").TypeOfShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
                GARAGE_DOOR_CODE: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            }>>, import("yup/lib/object").AssertsShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
                GARAGE_DOOR_CODE: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            }>>>;
        }>>, import("yup/lib/object").AssertsShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
            DESCRIPTION: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            INSTRUCTIONS: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            HAS_ADDITIONAL_FREE_SPOTS: import("yup/lib/boolean").RequiredBooleanSchema<boolean | null | undefined, import("yup/lib/types").AnyObject>;
            HAS_ADDITIONAL_PAID_SPOTS: import("yup/lib/boolean").RequiredBooleanSchema<boolean | null | undefined, import("yup/lib/types").AnyObject>;
            NUM_SPOTS_PROVIDED: import("yup/lib/number").RequiredNumberSchema<number | undefined, import("yup/lib/types").AnyObject>;
            IS_DEFAULT_DESCRIPTION: import("yup/lib/boolean").RequiredBooleanSchema<boolean | undefined, import("yup/lib/types").AnyObject>;
            CODES: yup.ObjectSchema<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
                GARAGE_DOOR_CODE: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            }>, import("yup/lib/object").AnyObject, import("yup/lib/object").TypeOfShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
                GARAGE_DOOR_CODE: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            }>>, import("yup/lib/object").AssertsShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
                GARAGE_DOOR_CODE: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
            }>>>;
        }>>>;
    }>>;
};
export declare const schema: any;
export declare const generateSchema: (subformName: RequiredSubformsEnum | OptionalSubformsEnum) => yup.ObjectSchema<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
    [x: string]: any;
}>, import("yup/lib/object").AnyObject, import("yup/lib/object").TypeOfShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
    [x: string]: any;
}>>, import("yup/lib/object").AssertsShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
    [x: string]: any;
}>>>;
export declare const formSchemas: {
    emptySchema: typeof yup.object;
};
