export declare const messages: {
    requiredValue: string;
    requiredNumber: string;
    shortNumber: string;
    longNumber: string;
    longString: string;
    shortString: string;
    invalidTime: string;
    invalidPhone: string;
    invalidEmail: string;
    unselectedOption: string;
    maxString: string;
    /** You must only provide 500 characters */
    maxStringDefined: (length: number) => string;
    maxString2500: string;
    maxString5000: string;
    minNumber: string;
    maxNumber: string;
};
