import * as yup from 'yup';
export declare const email: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
export declare const boolean: import("yup/lib/boolean").RequiredBooleanSchema<boolean | null | undefined, import("yup/lib/types").AnyObject>;
export declare const MAX_ACCESS_CODE_LENGTH = 50;
export declare const accessCode: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
export declare const streetName: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
export declare const streetNumber: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
export declare const city: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
export declare const country: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
export declare const unit: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
export declare const htmlNotRequired: (maxLength?: number) => yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
export declare const htmlRequired: (maxLength?: number) => yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
export declare const name: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
export declare const instruction: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
export declare const description: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
export declare const phone: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
export declare const messageSchema: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
export declare const currency: import("yup/lib/number").RequiredNumberSchema<number | undefined, import("yup/lib/types").AnyObject>;
export declare const squareFeet: import("yup/lib/number").RequiredNumberSchema<number | undefined, import("yup/lib/types").AnyObject>;
export declare const requiredString: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
export declare const id: yup.NumberSchema<number | undefined, import("yup/lib/types").AnyObject, number | undefined>;
export declare const stringID: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
export declare const maxString2500: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
export declare const maxString5000: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
export declare const taxString: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
export declare const time: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
export declare const twentyFourHourTime: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
export declare const positiveNumber: import("yup/lib/number").RequiredNumberSchema<number | undefined, import("yup/lib/types").AnyObject>;
export declare const number: import("yup/lib/number").RequiredNumberSchema<number | undefined, import("yup/lib/types").AnyObject>;
export declare const minAge: import("yup/lib/number").RequiredNumberSchema<number | undefined, import("yup/lib/types").AnyObject>;
export declare const url: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
export declare const addressValidation: {
    STREET_NAME: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
    STREET_NUMBER: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
    UNIT: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
    CITY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
    POSTAL: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
    REGION: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
    COUNTRY: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
};
export declare const buttonGroupValidation: {
    ID: yup.NumberSchema<number | undefined, import("yup/lib/types").AnyObject, number | undefined>;
    NAME: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
};
export declare const buttonGroupValidationNotRequired: {
    ID: yup.NumberSchema<number | undefined, import("yup/lib/types").AnyObject, number | undefined>;
    NAME: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
};
export declare const idNameValidation: {
    ID: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
    NAME: import("yup/lib/string").RequiredStringSchema<string | undefined, import("yup/lib/types").AnyObject>;
};
export declare const numberRegExp: RegExp;
export declare const rateGroup: {
    BASE_RATE: import("yup/lib/number").RequiredNumberSchema<number | undefined, import("yup/lib/types").AnyObject>;
    MIN_NIGHTS: import("yup/lib/number").RequiredNumberSchema<number | undefined, import("yup/lib/types").AnyObject>;
};
export declare const suitability: yup.ObjectSchema<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
    IS_SUITABLE: import("yup/lib/boolean").RequiredBooleanSchema<boolean | undefined, import("yup/lib/types").AnyObject>;
    NAME: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
    DESCRIPTION: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
    ID: import("yup/lib/number").RequiredNumberSchema<number | undefined, import("yup/lib/types").AnyObject>;
}>, import("yup/lib/object").AnyObject, import("yup/lib/object").TypeOfShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
    IS_SUITABLE: import("yup/lib/boolean").RequiredBooleanSchema<boolean | undefined, import("yup/lib/types").AnyObject>;
    NAME: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
    DESCRIPTION: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
    ID: import("yup/lib/number").RequiredNumberSchema<number | undefined, import("yup/lib/types").AnyObject>;
}>>, import("yup/lib/object").AssertsShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
    IS_SUITABLE: import("yup/lib/boolean").RequiredBooleanSchema<boolean | undefined, import("yup/lib/types").AnyObject>;
    NAME: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
    DESCRIPTION: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
    ID: import("yup/lib/number").RequiredNumberSchema<number | undefined, import("yup/lib/types").AnyObject>;
}>>>;
export declare const amenityDescription: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
export declare const amenityInstructions: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
export declare const amenitySchema: yup.ObjectSchema<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
    INSTRUCTIONS: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
    DESCRIPTION: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
    ACCESS_CODE: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
    INTERNET_NETWORK_NAME: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
    INTERNET_PASSWORD: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
}>, import("yup/lib/object").AnyObject, import("yup/lib/object").TypeOfShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
    INSTRUCTIONS: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
    DESCRIPTION: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
    ACCESS_CODE: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
    INTERNET_NETWORK_NAME: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
    INTERNET_PASSWORD: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
}>>, import("yup/lib/object").AssertsShape<import("yup/lib/object").Assign<import("yup/lib/object").ObjectShape, {
    INSTRUCTIONS: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
    DESCRIPTION: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
    ACCESS_CODE: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
    INTERNET_NETWORK_NAME: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
    INTERNET_PASSWORD: yup.StringSchema<string | undefined, import("yup/lib/types").AnyObject, string | undefined>;
}>>>;
export declare const numericValidationRegex: RegExp;
