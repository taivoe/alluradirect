export interface UseToggleType {
    isOpen: boolean;
    toggle: () => void;
    close: () => void;
    open: () => void;
}
export declare const useToggle: (defaultState?: {
    isOpen: boolean;
}) => UseToggleType;
