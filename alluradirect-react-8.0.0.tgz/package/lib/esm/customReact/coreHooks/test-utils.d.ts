import { act } from '@testing-library/react';
export declare function renderHook<T>(callback: () => T): {
    result: {
        current: T | undefined;
    };
};
export { act };
