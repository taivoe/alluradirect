import { CalculateDisabledDatesReturn } from './helpers';
export interface UseDateRangePickerArgs {
    initialStart?: Date;
    initialEnd?: Date;
    initialMonth?: Date;
    initialCurrentlySelecting?: 'start' | 'end';
    /** Formatted key: YYYY-MM-DD, value: <num_nights> */
    minNightsDates?: {
        [key: string]: number;
    }[];
    unavailabilityArrival?: Date[];
    unavailabilityDeparture?: Date[];
    canSelectPastDates?: boolean;
    onClickStart?: (day: Date, hasUnbookableGap: boolean) => void;
    onClickEnd?: (day: Date) => void;
}
export declare const useDateRangePicker: ({ initialStart, initialEnd, initialMonth, initialCurrentlySelecting, minNightsDates, unavailabilityDeparture, unavailabilityArrival, canSelectPastDates, onClickStart, onClickEnd, }: UseDateRangePickerArgs) => {
    startDate: Date | undefined;
    setStartDate: import("react").Dispatch<import("react").SetStateAction<Date | undefined>>;
    endDate: Date | undefined;
    setEndDate: import("react").Dispatch<import("react").SetStateAction<Date | undefined>>;
    currentlySelecting: "start" | "end";
    setCurrentlySelecting: import("react").Dispatch<import("react").SetStateAction<"start" | "end">>;
    onDayClick: (day: Date, callback?: (selecting: "start" | "end", day: Date) => void) => void;
    disabledDates: CalculateDisabledDatesReturn;
    modifiers: {
        start: Date | undefined;
        end: Date | undefined;
        minNight: Date[];
    };
    initialMonth: Date;
    nights: number;
    /** Re-export so we can pass the return of this hook to the component */
    unavailabilityArrival: Date[];
    unavailabilityDeparture: Date[];
    canSelectPastDates: boolean;
};
export type UseDateRangePickerReturn = ReturnType<typeof useDateRangePicker>;
