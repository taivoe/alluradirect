/** Use this function if the user cannot 'skip' over the next unbookable dates when selecting end
 * For example, there are a set of bookable dates which start and end are within.
 * The end date can be moved to the end of these set of dates but cannot select the next unavailable departure date or anything past that
 */
export declare const calculateDisabledAfterDateSelectingEnd: (unavailabilityDepartureDates: Date[], selectedEndDate: Date) => Date | undefined;
/** If the start date has moved and there is now an unbookable gap between the start and end date
 * Client needs to figure out how to handle this scenario.
 * Simple solution is to set departure to arrival when this occurs
 */
export declare const isUnbookableGapBetweenStartAndEnd: ({ arrival, departure, unavailabilityDepartureDates, }: {
    arrival: string;
    departure: string;
    unavailabilityDepartureDates: Date[];
}) => boolean;
export interface HandleDayClickArgs {
    day: Date;
    currentlySelecting: 'start' | 'end';
    setStartDate: (date: Date) => void;
    endDate: Date | undefined;
    setEndDate: (date: Date) => void;
    setCurrentlySelecting: (selecting: 'start' | 'end') => void;
    callback?: (selecting: 'start' | 'end', day: Date) => void;
    unavailabilityDeparture: Date[];
    onClickStart?: (day: Date, hasUnbookableGap: boolean) => void;
    onClickEnd?: (day: Date) => void;
}
export declare const handleDayClick: ({ day, currentlySelecting, setStartDate, endDate, setEndDate, callback, setCurrentlySelecting, unavailabilityDeparture, onClickEnd, onClickStart, }: HandleDayClickArgs) => void;
export interface CalculateDisabledDatesArgs {
    currentlySelecting: 'start' | 'end';
    unavailabilityDeparture: Date[];
    unavailabilityArrival: Date[];
    canSelectPastDates: boolean;
    endDate: Date | undefined;
    startDate: Date | undefined;
}
export interface CalculateDisabledDatesReturn {
    disabledDays: Date[];
    before?: Date;
    after?: Date;
}
export declare const calculateDisabledDates: ({ currentlySelecting, unavailabilityArrival, unavailabilityDeparture, canSelectPastDates, endDate, startDate, }: CalculateDisabledDatesArgs) => CalculateDisabledDatesReturn;
interface CalculateMinNightsDatesArgs {
    minNightsDates: {
        [key: string]: number;
    }[];
    startDate: Date | undefined;
}
export declare const calculateMinNightsDates: ({ startDate, minNightsDates }: CalculateMinNightsDatesArgs) => Date[];
export declare const calculateModifiers: ({ startDate, minNightsDates, endDate, }: CalculateMinNightsDatesArgs & {
    endDate: Date | undefined;
}) => {
    start: Date | undefined;
    end: Date | undefined;
    minNight: Date[];
};
export {};
