export interface UseSelectedToggleType<T> {
    isOpen: boolean;
    openWith: (val: T) => void;
    close: () => void;
    selectedValue: T | null;
}
export declare function useSelectedToggle<T>(initialValue?: T): UseSelectedToggleType<T>;
