import { NotificationEndpointFilterCategory, NotificationEndpointFilterStatus } from '../../../../../api/types';
interface Args {
    guestId: number;
    category: NotificationEndpointFilterCategory;
    status: NotificationEndpointFilterStatus;
    refetchInterval?: number;
    enabled?: boolean;
}
export declare const useGuestNotificationsQueryKeys: import("../../../queryKeyFactory").QueryKeys;
export declare const useGuestNotificationsInfiniteQuery: ({ guestId, category, status, enabled, refetchInterval, }: Args) => import("@tanstack/react-query").UseInfiniteQueryResult<import("@tanstack/query-core").InfiniteData<any, unknown>, any>;
export {};
