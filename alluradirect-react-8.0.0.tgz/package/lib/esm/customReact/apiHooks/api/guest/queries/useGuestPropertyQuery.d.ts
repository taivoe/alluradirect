/**  A guest has the ability to fetch a property. */
export declare const guestPropertyQueryKey: import("../../../queryKeyFactory").QueryKeys;
export declare const useGuestPropertyQuery: ({ bookingId, guestId, isEnabled, }: {
    bookingId: number;
    guestId: number;
    isEnabled: boolean;
}) => import("@tanstack/react-query").UseQueryResult<{
    ID: number;
    ACCESS_TO_UNIT: {
        CODE: {
            NAME: string;
            ID: import("../../../../../api/ownerFormInputs/types").AccessCodeIdEnum;
        };
        METHOD: {
            NAME: string;
            ID: import("../../../../../api/ownerFormInputs/types").AccessMethodIdEnum;
        };
        STANDARD_CODE: string;
        TYPE: {
            NAME: string;
            ID: import("../../../../../api/ownerFormInputs/types").AccessCodeTypeIDEnum;
        };
    };
    ADDRESS: {
        AREA: string;
        AREA_ID: number;
        CITY: string;
        COUNTRY: string;
        COUNTRY_CODE: string;
        COUNTRY_ID: number;
        DEVELOPMENT: string;
        DEVELOPMENT_ID: number;
        ID: number;
        LATITUDE: number;
        LONGITUDE: number;
        POSTAL: string;
        REGION: string;
        REGION_ID: number;
        RESORT: string;
        RESORT_ID: number;
        STREET_NAME: string;
        STREET_NUMBER: string;
        UNIT: string;
    };
    AMENITIES: {
        BUILDING: {
            TYPE: string;
            LIST: import("../../../../../api/types").Amenity[];
        };
        ESSENTIAL: {
            TYPE: string;
            LIST: import("../../../../../api/types").Amenity[];
        };
        KITCHEN: {
            TYPE: string;
            LIST: import("../../../../../api/types").Amenity[];
        };
        PRIVATE: {
            TYPE: string;
            LIST: import("../../../../../api/types").Amenity[];
        };
        SAFETY: {
            TYPE: string;
            LIST: import("../../../../../api/types").Amenity[];
        };
    };
    BANKING: {
        ACCOUNTHOLDER: {
            ADDRESS: {
                AREA: string;
                AREA_ID: number;
                CITY: string;
                COUNTRY: string;
                COUNTRY_CODE: string;
                COUNTRY_ID: number;
                DEVELOPMENT: string;
                DEVELOPMENT_ID: number;
                ID: number;
                LATITUDE: number;
                LONGITUDE: number;
                POSTAL: string;
                REGION: string;
                REGION_ID: number;
                RESORT: string;
                RESORT_ID: number;
                STREET_NAME: string;
                STREET_NUMBER: string;
                UNIT: string;
            };
            COMPANY_NAME: string;
            FIRST_NAME: string;
            IS_COMPANY: boolean;
            LAST_NAME: string;
        };
        BANK: {
            ACCOUNT_NUMBER: string;
            INSTITUTION: string;
            NAME: string;
            TRANSIT: string;
            ID: number;
        };
    };
    BATHROOMS: import("../../../../../api/property/types").Bathroom[];
    BEDROOMS: import("../../../../../api/property/types").Bedroom[];
    BLOCKOFFS: never[];
    CANCELLATION_POLICY: {
        ADMIN_PENALTY: number;
        ADMIN_PENALTY_UNIT: string;
        BOOKING_GRACE_PERIOD: string;
        DATE_ACTIVATED: string;
        DATE_LAST_UPDATED: string;
        DATE_RANGES: {
            DATE_ACTIVATED: string;
            DESCRIPTION: string;
            FROM_DAYS: string;
            ID: number;
            LABEL: string;
            REFUND_PERCENTAGE: string;
            TO_DAYS: string;
        }[];
        DESCRIPTION: string;
        ID: number;
        IS_CREDIT_ONLY_REFUND: boolean;
        IS_REFUND_REBOOKED_DATES: boolean;
        IS_SPECIAL_CIRCUMSTANCE: boolean;
        NAME: string;
        POLICY_ID: number;
        SERVICE_FEE_REFUND: string;
        SPECIAL_CIRCUMSTANCE_DESCRIPTION: string;
        SPECIAL_CIRCUMSTANCE_ID: number;
        SPECIAL_CIRCUMSTANCE_NAME: string;
        SURCHARGE_REFUND: string;
    };
    CLEANING_PROTOCOL: {
        HAS_AUTOMATIC_BUFFER_DAYS: boolean;
        IS_APPLY_TO_EXISTING_BOOKINGS: boolean;
        NUMBER_OF_BLOCKOFF_DAYS: number;
    };
    CODES: {
        BIKE_LOCKER_CODE: string;
        DEVELOPMENT_DOOR_CODE: string;
        DEVELOPMENT_GYM_CODE: string;
        DEVELOPMENT_HOT_TUB_CODE: string;
        DEVELOPMENT_POOL_CODE: string;
        DEVELOPMENT_SAUNA_CODE: string;
        DEVELOPMENT_STEAM_ROOM_CODE: string;
        FRONT_DOOR_CODE: string;
        GAMES_REC_ROOM_CODE: string;
        GARAGE_DOOR_CODE: string;
        GARBAGE_RECYCLING_CODE: string;
        ID: number;
        INTERNET_NETWORK_NAME: string;
        INTERNET_PASSWORD: string;
        PHONE_NUMBER: string;
        PROPERTY_ID: string;
        SKI_LOCKER_CODE: string;
        DATE_LAST_UPDATED: string;
    };
    CO_HOST: {
        COHOST_PROFILE: {
            PERMISSIONS: Omit<import("../../../../../api/user/constants").PropertyPermission, "PROPERTY_ID">;
            PROPERTY_IDS: never[];
        };
        ID: number;
        FIRST_NAME: string;
        LAST_NAME: string;
        IS_COMPANY: boolean;
        COMPANY_NAME: string;
        THUMBNAIL: string;
        PHONE: string;
        EMAIL: string;
        CREATED_DATE: string;
        DATE_LAST_LOGIN: string;
        DATE_UPDATED: string;
        ADDRESS: {
            AREA: string;
            AREA_ID: number;
            CITY: string;
            COUNTRY: string;
            COUNTRY_CODE: string;
            COUNTRY_ID: number;
            DEVELOPMENT: string;
            DEVELOPMENT_ID: number;
            ID: number;
            LATITUDE: number;
            LONGITUDE: number;
            POSTAL: string;
            REGION: string;
            REGION_ID: number;
            RESORT: string;
            RESORT_ID: number;
            STREET_NAME: string;
            STREET_NUMBER: string;
            UNIT: string;
        };
        IS_SMS_VERIFIED: boolean;
        IS_EMAIL_VERIFIED: boolean;
        DATE_EMAIL_VERIFIED: string;
        DATE_SMS_VERIFIED: string;
        DATE_OF_BIRTH: string;
        IS_ACTIVE: boolean;
        IS_STAFF: boolean;
        IS_SUPERUSER: boolean;
        IS_DUE_DILIGENCE_REQUIRED: boolean;
    };
    CONTENT: {
        ABOUT_THE_BUILDING: string;
        DESCRIPTION: string;
        KITCHEN: string;
        LOCATION: string;
        SUMMARY: string;
        TITLE: string;
    };
    DAMAGE_DEPOSIT: {
        AMOUNT: string;
        TYPE: {
            ID: import("../../../../../api/types").DamageDepositModeId;
            NAME: string;
        };
    };
    DAYS_TO_EXPIRY: number;
    DIRECT_VACATIONS: {
        ID: number;
        IS_ACTIVE: boolean;
        LOGO: string;
        NAME: string;
        URL: string;
    };
    EMERGENCY_CONTACTS: {
        PRIMARY: import("../../../../../api/property/types").EmergencyContact;
        OTHERS: import("../../../../../api/property/types").EmergencyContact[];
    };
    EXTERNAL_URLS: {
        URL_AIRBNB: string;
        URL_OTHER: string;
        URL_VRBO: string;
    };
    ICALS: {
        HAS_ICALS: boolean;
        PRIMARY: {
            ALLURA_URL: string;
            AVAILABILITY_WINDOW: number;
            IS_AVAILABILITY_WINDOW: boolean;
            IS_BLOCK_RATELESS: boolean;
        };
        SECONDARY: {
            ALLURA_URL: string;
            AVAILABILITY_WINDOW: number;
            IS_ACTIVE: boolean;
            IS_AVAILABILITY_WINDOW: boolean;
            IS_BLOCK_RATELESS: boolean;
        };
        EXTERNAL: {
            ID: number;
            LISTING_URL: string;
            NAME: string;
            URL: string;
        }[];
    };
    INSTRUCTIONS: {
        ABOUT_THE_BUILDING: string;
        ACTIVITIES: string;
        BUILDING_COMMON_AREAS: string;
        CHECK_IN: string;
        CHECK_OUT: string;
        EMERGENCY_CONTACTS: string;
        FRONT_DESK: string;
        GARBAGE_RECYCLING: string;
        GETTING_AROUND: string;
        GETTING_TO_UNIT: string;
        HEATING: string;
        HOUSEKEEPING: string;
        ID: number;
        INFANT_SUPPLIES: string;
        KITCHEN: string;
        LATE_CHECK_IN: string;
        LINENS_AND_TOWELS: string;
        OTHER: string;
        PARKING: string;
        RESTAURANTS: string;
        SERVICES: string;
        SKI_IN_SKI_OUT: string;
        TO_FROM_LIFTS: string;
        WELCOME: string;
        WHAT_TO_BRING: string;
    };
    IS_ALLURA_RATES: boolean;
    IS_CO_HOST_MANAGER_ENABLED: string;
    IS_ENABLED: boolean;
    IS_SKI_IN_SKI_OUT: boolean;
    JOIN_STATUS: {
        COMPLETION_PERCENTAGE_REQUIRED: number;
        COMPLETION_PERCENTAGE_OPTIONAL: number;
        DATES: {
            CREATED: string;
            LAST_UPDATED: string;
            ACTIVATED: string;
            ACTIVATION_REQUEST: string;
        };
        HAS_COMPLETED_ONBOARDING: boolean;
        STATUS: string;
        STATUS_ID: import("../../../../../api/property/types").JoinStatusIDEnum;
        SUBFORMS_COMPLETED: import("../../../../../api/subformNames").RequiredSubformsEnum[];
        SUBFORMS_OPTIONAL_COMPLETED: import("../../../../../api/subformNames").OptionalSubformsEnum[];
    };
    LISTING_QUALITY: {
        MESSAGE: string;
        RATES_AVAILABILITY: {
            MESSAGE: string;
            PROPERTY_COUNT: number;
            RECOMMENDED_COUNT: number;
            SCORE: number;
        };
        PROPERTY_GUIDEBOOK: {
            MESSAGE: string;
            PROPERTY_COUNT: number;
            RECOMMENDED_COUNT: number;
            SCORE: number;
        };
        STAR_RATING: number;
        PHOTOS: {
            MESSAGE: string;
            PROPERTY_COUNT: number;
            RECOMMENDED_COUNT: number;
            SCORE: number;
        };
    };
    NAME: string;
    NON_RESIDENT: {
        ITN_INFO: {
            ID: number;
            ITN: number;
            PERCENTAGE_OWNERSHIP: number;
            DOB: string;
            FIRST_NAME: string;
            LAST_NAME: string;
        }[];
        IS_NON_RESIDENT: boolean;
        WITHHOLDING_PERCENTAGE: number;
    };
    OFFERS: {
        IS_NEW_LISTING_OFFER_ENABLED: boolean;
        IS_NEW_LISTING_OFFER_BLACKOUT_ENABLED: boolean;
    };
    OWNER: import("../../../../../api/types").WithRequiredProperty<import("../../../../../api/user/types").User, "OWNER_PROFILE">;
    PARKING: {
        DESCRIPTION: string;
        HAS_ADDITIONAL_FREE_SPOTS: string;
        HAS_ADDITIONAL_PAID_SPOTS: string;
        INSTRUCTIONS: string;
        IS_DEFAULT_DESCRIPTION: boolean;
        NUM_SPOTS_PROVIDED: string;
    };
    PARTNERS: never[];
    PHOTOS: import("../../../../../api/property/types").Photo[];
    POLICIES: {
        ACCOUNT: import("../../../../../api/property/types").Policy[];
        GENERAL: import("../../../../../api/property/types").Policy[];
        GUEST_STAY: import("../../../../../api/property/types").Policy[];
        HOUSE_RULES: import("../../../../../api/property/types").Policy[];
        PROPERTY: import("../../../../../api/property/types").Policy[];
        RESERVATION: import("../../../../../api/property/types").Policy[];
    };
    PRIMARY_CONTACT: import("../../../../../api/user/types").User;
    PROPERTY_CONTACT: {
        PROPERTY_MANAGER_PROFILE: {
            PERMISSIONS: Omit<import("../../../../../api/user/constants").PropertyPermission, "PROPERTY_ID">;
            PROPERTY_IDS: never[];
        };
        ID: number;
        FIRST_NAME: string;
        LAST_NAME: string;
        IS_COMPANY: boolean;
        COMPANY_NAME: string;
        THUMBNAIL: string;
        PHONE: string;
        EMAIL: string;
        CREATED_DATE: string;
        DATE_LAST_LOGIN: string;
        DATE_UPDATED: string;
        ADDRESS: {
            AREA: string;
            AREA_ID: number;
            CITY: string;
            COUNTRY: string;
            COUNTRY_CODE: string;
            COUNTRY_ID: number;
            DEVELOPMENT: string;
            DEVELOPMENT_ID: number;
            ID: number;
            LATITUDE: number;
            LONGITUDE: number;
            POSTAL: string;
            REGION: string;
            REGION_ID: number;
            RESORT: string;
            RESORT_ID: number;
            STREET_NAME: string;
            STREET_NUMBER: string;
            UNIT: string;
        };
        IS_SMS_VERIFIED: boolean;
        IS_EMAIL_VERIFIED: boolean;
        DATE_EMAIL_VERIFIED: string;
        DATE_SMS_VERIFIED: string;
        DATE_OF_BIRTH: string;
        IS_ACTIVE: boolean;
        IS_STAFF: boolean;
        IS_SUPERUSER: boolean;
        IS_DUE_DILIGENCE_REQUIRED: boolean;
    };
    RATES_SCHEDULE: import("../../../../../api/property/types").ServerRateSchedule[];
    RATES_SETTINGS: {
        IS_AVAILABILITY_AUTOMATION_ENABLED: boolean;
        HAS_RATE_INSIGHTS_DATA: boolean;
        IS_OPTIMIZED_PRICING_ENABLED: boolean;
        NO_RATES_DATES: import("../../../../../api/property/types").NoRatesDate[];
        PRICING_STRATEGY: {
            ID: import("../../../../../api/property/types").PricingStrategyEnum;
            RATE_INSIGHTS_LEVEL_ID: import("../../../../../api/property/types").RateInsightLevelIdEnum;
        };
        WEEKEND_PREMIUM: {
            ID: import("../../../../../api/property/types").RatesSettingsWeekendPremiumId;
            DOLLAR_AMOUNT: number;
            PERCENTAGE_AMOUNT: number;
        };
        AVAILABILITY_WINDOW: {
            ID: import("../../../../../api/property/types").RateAvailabilityIdEnum;
        };
        DATE_LAST_SAVED: string;
        RATE_GROUPS: {
            HIGH: import("../../../../../api/property/types").RateGroup;
            LOW: import("../../../../../api/property/types").RateGroup;
            PRIME: import("../../../../../api/property/types").RateGroup;
            MID: import("../../../../../api/property/types").RateGroup;
        };
        DISCOUNT_GROUP: {
            TEN_DAY: number;
            SEVEN_DAY: number;
            FIVE_DAY: number;
            ID: number;
        };
        ID: number;
    };
    RESERVATION_SETTINGS: {
        DEPOSIT_PERCENTAGE: number;
        BALANCE_DAYS_BEFORE_ARRIVAL: number;
        BOOKING_GATEWAY_MODE_ID: number;
    };
    RULES: {
        ID: number;
        ADVANCED_BOOKING: {
            NAME: string;
            ID: number;
        };
        CHECK_IN: string;
        CHECK_OUT: string;
        MAX_BOOKABLE_DAYS: number;
        MAX_GUESTS: number;
        MIN_AGE_TO_BOOK: number;
        QUIET_TIME: string;
    };
    SETUP_QUESTIONS: {
        NUM_PROPERTIES: number;
        PLATFORMS_LISTED: {
            ID: number;
            URL: string;
        }[];
        ID: number;
    };
    SIZE_CATEGORY: {
        NAME: string;
        ID: number;
    };
    SQUARE_FEET: string;
    STYLE: {
        NAME: string;
        ID: number;
    };
    SURCHARGES: {
        CLEANING: {
            AMOUNT: string;
            ID: number;
            IS_ENABLED: boolean;
            NAME: string;
        };
        PETS: {
            AMOUNT: string;
            ID: number;
            IS_ENABLED: boolean;
            NAME: string;
        };
    };
    SUBSCRIPTION: {
        COMMISSION_PERCENTAGE: number;
        CREDIT_CARD_PERCENTAGE: number;
        DESCRIPTION: string;
        DURATION: string;
        FEE: string;
        GST: string;
        GST_RATE: number;
        ID: number;
        NAME: string;
        NUMBER_OF_DAYS: number;
        RESORT_ID: number;
        SUBSCRIPTION_TIER_ID: import("../../../../../api/property/types").PropertySubscriptionTierIdEnum;
    };
    SUITABILITIES: {
        LONG_TERM_RENTALS: {
            ID: number;
            DESCRIPTION: string;
            IS_SUITABLE: boolean;
            NAME: string;
        };
        PARTIES_EVENTS: {
            ID: number;
            DESCRIPTION: string;
            IS_SUITABLE: boolean;
            NAME: string;
        };
        PETS: {
            ID: number;
            DESCRIPTION: string;
            IS_SUITABLE: boolean;
            NAME: string;
        };
        SMOKING: {
            ID: number;
            DESCRIPTION: string;
            IS_SUITABLE: boolean;
            NAME: string;
        };
        TRAVEL_RESELLERS: {
            ID: number;
            DESCRIPTION: string;
            IS_SUITABLE: boolean;
            NAME: string;
        };
        WHEELCHAIR_ACCESSIBLE: {
            ID: number;
            DESCRIPTION: string;
            IS_SUITABLE: boolean;
            NAME: string;
        };
    };
    TAXES: {
        IS_MANDATORY: boolean;
        IS_PASS_THROUGH_TO_OWNER: boolean;
        NAME: string;
        ID: number;
        RATE: number;
        REGISTRATION_NUMBER: string;
        DESCRIPTION: string;
    }[];
    TAX_NUMBERS: {
        BC_SHORT_TERM_REGISTRY_NUMBER: string;
        BUSINESS_LICENCE_NUMBER: string;
        GST_NUMBER: string;
        PST_NUMBER: string;
    };
    THUMBNAIL_URL: string;
    URL: string;
    VIDEOS: {
        THREESIXTY: {
            DATA: string;
            ID: number;
        };
        YOUTUBE: {
            DATA: string;
            ID: number;
        }[];
        FEATURED: {
            DATA: string;
            ID: number;
        };
    };
    WALKTHROUGH: {
        PROPERTY_GUIDEBOOK: import("../../../../../api/property/types").GuidebookWalkthrough;
    };
}, Error>;
