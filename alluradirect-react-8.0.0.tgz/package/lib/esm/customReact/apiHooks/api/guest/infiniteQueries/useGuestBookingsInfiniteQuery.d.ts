import { BookingStatusId } from '../../../../../api/booking/types';
import { PageDirection } from '../../../useAppInfiniteQuery/types';
interface Args {
    guestId: number;
    direction: PageDirection;
    amountPerPage?: number;
    statusIdFilter?: BookingStatusId;
    enabled?: boolean;
    refetchInterval?: number;
}
export declare const guestBookingsInfiniteQueryKeys: import("../../../queryKeyFactory").QueryKeys;
export declare const useGuestBookingsInfiniteQuery: ({ guestId, amountPerPage, enabled, refetchInterval, statusIdFilter, direction, }: Args) => import("@tanstack/react-query").UseInfiniteQueryResult<import("@tanstack/query-core").InfiniteData<any, unknown>, any>;
export {};
