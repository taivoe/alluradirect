/** This will return the entire Cancellation Policy HTML. To use the Object
 version, use useGuestCancellationPolicyObject
 */
export declare const useGuestBookingCancellationPolicyHTML: (bookingId: number, guestId: number) => import("@tanstack/react-query").UseQueryResult<string, Error>;
