import { APIResponse } from '../../../../../api/types';
import { Args } from '../../user/queries/useUnavailableDatesQuery/types';
export interface UnavailableDatesResponse {
    CANNOT_ARRIVE: string[];
    CANNOT_DEPART: string[];
    UNAVAILABILITY_ARRIVAL: string[];
    UNAVAILABILITY_DEPARTURE: string[];
}
interface GuestArgs extends Omit<Args, 'propertyId'> {
    guestId: number;
}
export declare const useGuestUnavailableDates: ({ isEnabled, bookingId, guestId, onSuccess, }: GuestArgs) => import("@tanstack/react-query").UseQueryResult<APIResponse<UnavailableDatesResponse>, Error>;
export {};
