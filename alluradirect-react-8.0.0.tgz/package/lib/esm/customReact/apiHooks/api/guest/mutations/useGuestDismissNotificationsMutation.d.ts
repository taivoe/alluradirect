import { ConfigurableAppMutationArgs } from '../../../useAppMutation/useAppMutation';
interface Values {
    /** Guest Id */
    id: number;
    notification_ids: number[] | 'all';
}
export declare const useGuestDismissNotificationsMutation: (args: ConfigurableAppMutationArgs) => import("@tanstack/react-query").UseMutationResult<any, Error, Values, void>;
export {};
