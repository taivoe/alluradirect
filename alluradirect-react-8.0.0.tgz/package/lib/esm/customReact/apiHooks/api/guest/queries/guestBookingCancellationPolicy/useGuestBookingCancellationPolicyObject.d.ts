/** This will return the entire Cancellation Policy Object. To use the HTML
 version, use useGuestCancellationPolicyHTML
 */
export declare const useGuestBookingCancellationPolicyObject: (bookingId: number, guestId: number) => import("@tanstack/react-query").UseQueryResult<{
    ADMIN_PENALTY: number;
    ADMIN_PENALTY_UNIT: string;
    BOOKING_GRACE_PERIOD: string;
    DATE_ACTIVATED: string;
    DATE_LAST_UPDATED: string;
    DATE_RANGES: {
        DATE_ACTIVATED: string;
        DESCRIPTION: string;
        FROM_DAYS: string;
        ID: number;
        LABEL: string;
        REFUND_PERCENTAGE: string;
        TO_DAYS: string;
    }[];
    DESCRIPTION: string;
    ID: number;
    IS_CREDIT_ONLY_REFUND: boolean;
    IS_REFUND_REBOOKED_DATES: boolean;
    IS_SPECIAL_CIRCUMSTANCE: boolean;
    NAME: string;
    POLICY_ID: number;
    SERVICE_FEE_REFUND: string;
    SPECIAL_CIRCUMSTANCE_DESCRIPTION: string;
    SPECIAL_CIRCUMSTANCE_ID: number;
    SPECIAL_CIRCUMSTANCE_NAME: string;
    SURCHARGE_REFUND: string;
}, Error>;
