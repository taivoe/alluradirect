import { FullBooking } from '../../../../../api/booking/types';
interface Args {
    isOwnerRole: boolean;
    isGuestRole: boolean;
    bookingId: number;
    guestId?: number;
    isEnabled?: boolean;
    onSuccess?: (booking: FullBooking) => void;
    includeTimeline?: boolean;
    ownerOffer?: {
        code: string;
        id: string;
    };
    alluraOffer?: {
        code: string;
        id: string;
    };
    alluraGiftCertificate?: {
        code: string;
        id: string;
    };
    ownerGiftCertificate?: {
        code: string;
        id: string;
    };
}
export declare const useBookingQuery: ({ bookingId, isOwnerRole, isGuestRole, guestId, isEnabled, onSuccess, includeTimeline, ownerOffer, alluraOffer, alluraGiftCertificate, ownerGiftCertificate, }: Args) => import("@tanstack/react-query").UseQueryResult<FullBooking, Error>;
export {};
