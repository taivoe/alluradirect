import { ConfigurableAppMutationArgs } from '../../../useAppMutation/useAppMutation';
interface Values {
    bookingId: number;
    message?: string;
    entry_code?: string;
}
export declare const useCustomMessageMutation: (args: ConfigurableAppMutationArgs) => import("@tanstack/react-query").UseMutationResult<any, Error, Values, void>;
export {};
