import { CreateBookingBody, EditBookingBody, FullBooking } from '../../../../../api/booking/types';
import { APIKeyResponse } from '../../../../../api/types';
export type BookingQuoteResponse = APIKeyResponse<FullBooking, 'BOOKING'>;
export declare const generateBookingQuoteEndpoint: (quoteParams: CreateBookingBody | Pick<CreateBookingBody, "ARRIVAL" | "NIGHTS" | "PROPERTY_ID">) => string;
type CreateRateQuote = Pick<CreateBookingBody, 'ARRIVAL' | 'NIGHTS' | 'PROPERTY_ID'>;
type EditRateQuote = Pick<EditBookingBody, 'ARRIVAL' | 'NIGHTS' | 'PROPERTY_ID' | 'ID'>;
type QuoteParams = CreateBookingBody | EditBookingBody | CreateRateQuote | EditRateQuote;
export declare const generateBookingQuoteQueryKeyDetail: (quoteParams: QuoteParams) => [string, "detail", string];
export declare const bookingQuoteQueryKey: import("../../../queryKeyFactory").QueryKeys;
interface Args {
    quoteParams: QuoteParams;
    isEnabled: boolean;
    onSuccess?: (response: any) => void;
    onError?: (error: any) => void;
    onSettled?: () => void;
}
export declare const useBookingQuoteQuery: ({ quoteParams, isEnabled, onSuccess, onError, onSettled, }: Args) => import("@tanstack/react-query").UseQueryResult<BookingQuoteResponse, Error>;
export {};
