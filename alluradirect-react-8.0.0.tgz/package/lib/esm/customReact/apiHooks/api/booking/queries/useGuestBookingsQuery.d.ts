import { BookingStatusId } from '../../../../../api/booking/types';
interface Args {
    direction?: 'future' | 'past' | 'all';
    statusId?: BookingStatusId;
    enabled?: boolean;
    guestId: number;
}
/** For use in the useGuestBookingsQuery hook (not the infinite query) */
export declare const guestBookingsQueryKeys: import("../../../queryKeyFactory").QueryKeys;
export declare const useGuestBookingsQuery: ({ direction, statusId, enabled, guestId, }: Args) => import("@tanstack/react-query").UseQueryResult<{
    CUSTOM_MESSAGE: {
        MESSAGE: string;
        ENTRY_CODE: string;
    };
    DATES: {
        ARRIVAL: string;
        BOOKING: string;
        BOOKING_TIME: string;
        CHECK_IN_SENT: string;
        DEPARTURE: string;
        SERVER_TIMESTAMP: string;
    };
    FLAGS: {
        IS_PAST_DUE: boolean;
    };
    GUEST: {
        AGE: string;
        EMAIL: string;
        FIRST_NAME: string;
        GUEST_PROFILE: {
            MEMBER_SINCE: string;
            PERMISSIONS: {
                SHOW_NUM_REVIEWS: boolean;
                SHOW_MEMBER_SINCE: boolean;
                SHOW_NUM_RECOMMENDS: boolean;
            };
            NUM_BOOKINGS: number;
            NUM_RECOMMENDATIONS: number;
            NUM_REVIEWS: number;
        };
        ID: number;
        IS_AGE_VERIFIED: boolean;
        IS_EMAIL_VERIFIED: boolean;
        IS_SMS_VERIFIED: boolean;
        LAST_NAME: string;
        PHONE: string;
        THUMBNAIL: string;
    };
    GUEST_COMMENT: string;
    GUEST_REQUESTS: string;
    ID: number;
    NIGHTS: number;
    NIGHTLY_RATES: {
        DATE: string;
        DAY: string;
        RATE: string;
        BASE_RATE: string;
        LOS_DISCOUNT: string;
        OFFER_DISCOUNT: string;
    }[];
    NOTES_OWNER: string;
    PARTY_SIZE: {
        ADULTS: number;
        KIDS: number;
    };
    PAYMENT: {
        AMOUNT_OUTSTANDING: string;
        AMOUNT_REFUNDED: string;
        BALANCE: {
            DUE_DATE: string;
            PAYMENT_DATE: string;
            TOTAL: string;
        };
        BOOKING_NET: string;
        DAMAGE_DEPOSIT: {
            MODE: string;
            MODE_ID: import("../../../../../api/types").DamageDepositModeId;
        };
        DEPOSIT: {
            DUE_DATE: string;
            PAYMENT_DATE: string;
            TOTAL: string;
        };
        NEXT_PAYMENT: {
            DUE_DATE: string;
            IS_PAST_DUE: boolean;
            NAME: string;
            TOTAL: string;
        };
        PAID_TO_DATE: string;
    };
    PAYMENT_INFORMATION: {
        ACCOMMODATION_SUBTOTAL: string;
        ALLURA_OFFER_DISCOUNT: string;
        BOOKING_NET_BASE_RATE: string;
        BOOKING_NET_BASE_RATE_MINUS_LOS: string;
        LENGTH_OF_STAY_DISCOUNT: string;
        OWNER_OFFER_DISCOUNT: string;
    };
    PROPERTY: {
        RULES: {
            CHECK_IN: string;
            CHECK_OUT: string;
            MAX_GUESTS: string;
            MIN_AGE_TO_BOOK: number;
            MAX_BOOKABLE_DAYS: number;
            QUIET_TIME: number;
        };
        ADDRESS: {
            UNIT: string;
            RESORT: string;
            DEVELOPMENT: string;
            STREET_NAME: string;
            STREET_NUMBER: string;
        };
        JOIN_STATUS: {
            STATUS_ID: import("../../../../../api/property/types").JoinStatusIDEnum;
        };
        ID: number;
        THUMBNAIL_URL: string;
        ACCESS_TO_UNIT: {
            CODE: {
                NAME: string;
                ID: import("../../../../../api/ownerFormInputs/types").AccessCodeIdEnum;
            };
            METHOD: {
                NAME: string;
                ID: import("../../../../../api/ownerFormInputs/types").AccessMethodIdEnum;
            };
            STANDARD_CODE: string;
            TYPE: {
                NAME: string;
                ID: import("../../../../../api/ownerFormInputs/types").AccessCodeTypeIDEnum;
            };
        };
        CODES: {
            BIKE_LOCKER_CODE: string;
            DEVELOPMENT_DOOR_CODE: string;
            DEVELOPMENT_GYM_CODE: string;
            DEVELOPMENT_HOT_TUB_CODE: string;
            DEVELOPMENT_POOL_CODE: string;
            DEVELOPMENT_SAUNA_CODE: string;
            DEVELOPMENT_STEAM_ROOM_CODE: string;
            FRONT_DOOR_CODE: string;
            GAMES_REC_ROOM_CODE: string;
            GARAGE_DOOR_CODE: string;
            GARBAGE_RECYCLING_CODE: string;
            ID: number;
            INTERNET_NETWORK_NAME: string;
            INTERNET_PASSWORD: string;
            PHONE_NUMBER: string;
            PROPERTY_ID: string;
            SKI_LOCKER_CODE: string;
            DATE_LAST_UPDATED: string;
        };
        PRIMARY_CONTACT: import("../../../../../api/property/types").EmergencyContact & {
            THUMBNAIL_URL: string;
        };
    };
    REFERENCE: string;
    REVIEW: {
        ID: number;
    };
    SOURCE: string;
    STATUS: {
        ID: BookingStatusId;
        NAME: string;
    };
    STATUSES: {
        DATE: string;
        IS_DONE: boolean;
        LABEL: string;
    }[];
    SURCHARGES: {
        NET: string;
        TAXES_TOTAL: string;
    };
    TAX: {
        TOTAL: string;
    };
    TOTAL: string;
}[], Error>;
export {};
