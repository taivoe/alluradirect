import { ConfigurableAppQueryArgs } from '../../../useAppQuery/useAppQuery';
import { APIResponse } from '../../../../../api/types';
interface Args {
    guestEmail: string;
}
export declare const useBookingGuestExistsQuery: ({ guestEmail, enabled, ...rest }: Args & ConfigurableAppQueryArgs) => import("@tanstack/react-query").UseQueryResult<APIResponse<{
    IS_EXISTING_GUEST: boolean;
}>, Error>;
export {};
