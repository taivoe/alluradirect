export declare const rentalAgreementSummaryQueryKey: import("../../../queryKeyFactory").QueryKeys;
export declare const useRentalAgreementSummaryQuery: ({ enabled, bookingId, guestId, }: {
    enabled?: boolean;
    bookingId: number;
    guestId: number;
}) => import("@tanstack/react-query").UseQueryResult<string, Error>;
