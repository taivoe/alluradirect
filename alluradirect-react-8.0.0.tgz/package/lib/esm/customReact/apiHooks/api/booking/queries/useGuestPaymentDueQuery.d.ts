export declare const guestPaymentDueQueryKey: import("../../../queryKeyFactory").QueryKeys;
export declare const useGuestPaymentDueQuery: ({ bookingId, guestId, isEnabled, }: {
    bookingId: number;
    guestId: number;
    isEnabled: boolean;
}) => import("@tanstack/react-query").UseQueryResult<{
    ID: number;
    PAYMENT_DUE: {
        BOOKING: {
            AMOUNT_DUE: number;
            ARRIVAL: string;
            BOOKING_NET: number;
            BOOKING_TOTAL: number;
            DAMAGE_DEPOSIT: number;
            DEPARTURE: string;
            ID: number;
            NIGHTLY_RATE: number;
            NIGHTS: number;
            PAID_TO_DATE: number;
            PARTY_SIZE: number;
            TAXES_AND_FEES_TOTAL: number;
        };
        FEES: import("../../../../../api/guest/types").GuestPaymentFee[];
        TAXES: import("../../../../../api/guest/types").GuestPaymentTaxes[];
    };
}, Error>;
