import { CancellationDetails } from '../../../../../api/booking/types';
import { APIKeyResponse } from '../../../../../api/types';
export declare const useBookingCancellationQuery: ({ bookingId }: {
    bookingId: number | string;
}) => import("@tanstack/react-query").UseQueryResult<APIKeyResponse<CancellationDetails, "CANCELLATION_DETAILS">, Error>;
