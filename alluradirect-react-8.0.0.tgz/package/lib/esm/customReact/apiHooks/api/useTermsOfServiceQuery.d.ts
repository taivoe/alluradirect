import { APIResponse } from '../../../api/types';
import { UserRoleIDEnum } from '../../../api/user/types';
import { ConfigurableAppQueryArgs } from '../useAppQuery/useAppQuery';
interface Args {
    userTypeId: UserRoleIDEnum;
}
/** Returns html Terms of service agreement for guests or hosts */
export declare const useTermsOfServiceQuery: ({ userTypeId, ...rest }: Args & ConfigurableAppQueryArgs) => import("@tanstack/react-query").UseQueryResult<APIResponse<{
    TOSSA: string;
}>, Error>;
export {};
