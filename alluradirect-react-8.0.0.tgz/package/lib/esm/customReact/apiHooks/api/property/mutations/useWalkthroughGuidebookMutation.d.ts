export declare const useWalkthroughGuidebookMutation: () => import("@tanstack/react-query").UseMutationResult<any, Error, {
    id: number;
    form_data: string;
}, void>;
