export declare const generateUpdatedSendValues: (pid: any) => (values: any) => any;
