import { FullBooking } from '../../../../../api/booking/types';
interface Args {
    bookingId: number;
    isEnabled?: boolean;
    onSuccess?: (booking: FullBooking) => void;
    onError?: () => void;
    includeTimeline?: boolean;
}
export declare const propertyBookingQueryKey: import("../../../queryKeyFactory").QueryKeys;
export declare const usePropertyBookingQuery: ({ isEnabled, bookingId, includeTimeline, onSuccess, onError, }: Args) => import("@tanstack/react-query").UseQueryResult<FullBooking, Error>;
export {};
