import { ConfigurableAppMutationArgs } from '../../../../useAppMutation/useAppMutation';
interface Args {
    onSuccess?: (data: any) => void;
    propertyId: number;
}
type ConfigurableArgs = Omit<ConfigurableAppMutationArgs, 'onSuccess' | 'modifySendData'>;
export declare const usePropertySubformMutation: ({ onSuccess, propertyId, ...rest }: Args & ConfigurableArgs) => import("@tanstack/react-query").UseMutationResult<any, Error, any, void>;
export {};
