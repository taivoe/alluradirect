import { ConfigurableAppInfiniteQueryArgs } from '../../../useAppInfiniteQuery/types';
import { InfiniteQueryPageDirections } from '../../../../../api/types';
interface Args {
    propertyId: number;
    pageDirection?: InfiniteQueryPageDirections;
    amountPerPage?: number;
    initialPageParam?: number;
}
export declare const propertyReviewsInfiniteQueryKey: import("../../../queryKeyFactory").QueryKeys;
export declare const usePropertyReviewsInfiniteQuery: ({ propertyId, pageDirection, amountPerPage, initialPageParam, ...rest }: Args & ConfigurableAppInfiniteQueryArgs) => import("@tanstack/react-query").UseInfiniteQueryResult<import("@tanstack/query-core").InfiniteData<any, unknown>, any>;
export {};
