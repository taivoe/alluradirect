import { ConfigurableAppQueryArgs } from '../../../useAppQuery/useAppQuery';
import { FinancesArgs } from '../../../../../api/owner/endpoints';
import { APIResponse } from '../../../../../api/types';
export declare const useOwnerFinancesSummaryQuery: ({ ownerId, year, fromMonth, toMonth, sortOrder, propertyId, ...rest }: FinancesArgs & ConfigurableAppQueryArgs) => import("@tanstack/react-query").UseQueryResult<APIResponse<{
    OWNER_ID: number;
    PROPERTIES: {
        PROPERTY_ID: number;
        PROPERTY_ADDRESS: string;
        PROPERTY_THUMBNAIL_URL: string;
        UPCOMING: {
            NON_RESIDENT_WITHHELD: string;
            TAXES: {
                OWNER_REMIT_AMOUNT: string;
                NAME: string;
                ID: number;
                AMOUNT: string;
            }[];
            CREDIT_CARD_FEES: string;
            COMMISSION: string;
            RESERVATIONS_COUNT: number;
            SURCHARGES_AMOUNT: string;
            RESERVATIONS_AMOUNT: string;
        };
        TOTAL: {
            NON_RESIDENT_WITHHELD: string;
            TAXES: {
                OWNER_REMIT_AMOUNT: string;
                NAME: string;
                ID: number;
                AMOUNT: string;
            }[];
            CREDIT_CARD_FEES: string;
            COMMISSION: string;
            RESERVATIONS_COUNT: number;
            SURCHARGES_AMOUNT: string;
            RESERVATIONS_AMOUNT: string;
        };
        PAID: {
            NON_RESIDENT_WITHHELD: string;
            TAXES: {
                OWNER_REMIT_AMOUNT: string;
                NAME: string;
                ID: number;
                AMOUNT: string;
            }[];
            CREDIT_CARD_FEES: string;
            COMMISSION: string;
            RESERVATIONS_COUNT: number;
            SURCHARGES_AMOUNT: string;
            RESERVATIONS_AMOUNT: string;
        };
    }[];
    GROSS_VALUES: {
        UPCOMING: string;
        TOTAL: string;
        PAID: string;
    };
}>, Error>;
