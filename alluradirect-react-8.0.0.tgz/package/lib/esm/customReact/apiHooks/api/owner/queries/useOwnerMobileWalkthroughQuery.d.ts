import { APIResponse } from '../../../../../api/types';
import { ConfigurableAppQueryArgs } from '../../../useAppQuery/useAppQuery';
interface Args {
    id: number;
}
export declare const useOwnerMobileWalkthroughQuery: ({ id }: Args & ConfigurableAppQueryArgs) => import("@tanstack/react-query").UseQueryResult<APIResponse<{
    WALKTHROUGH_MOBILE: {
        COMPLETED_STEPS: import("../../../../../api/owner/types").MobileWalkThroughNameEnum[];
        COMPLETION_PERCENTAGE: number;
        NUM_STEPS: number;
        STEPS: import("../../../../../api/owner/types").MobileWalkThroughNameEnum[];
    };
}>, Error>;
export {};
