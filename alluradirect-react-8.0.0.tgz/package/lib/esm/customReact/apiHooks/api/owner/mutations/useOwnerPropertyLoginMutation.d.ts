import { APIResponse } from '../../../../../api/types';
import { ConfigurableAppMutationArgs } from '../../../useAppMutation/useAppMutation';
export declare const useOwnerPropertyLoginMutation: (reactQueryOptions?: ConfigurableAppMutationArgs) => import("@tanstack/react-query").UseMutationResult<APIResponse<{
    PROPERTY_ID: number;
}>, Error, {
    id: number;
    property_id: number;
}, void>;
