import { MobileWalkThroughNameEnum } from '../../../../../api/owner/types';
export declare const useOwnerMobileWalkthroughMutation: () => import("@tanstack/react-query").UseMutationResult<any, Error, {
    id: number;
    step_name: MobileWalkThroughNameEnum;
}, void>;
