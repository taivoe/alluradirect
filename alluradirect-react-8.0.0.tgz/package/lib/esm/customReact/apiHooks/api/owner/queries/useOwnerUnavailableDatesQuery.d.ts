import { Args, UnavailableDatesResponse } from '../../user/queries/useUnavailableDatesQuery/types';
import { APIResponse } from '../../../../../api/types';
export declare const useOwnerUnavailableDates: ({ isEnabled, bookingId, propertyId, onSuccess, }: Args) => import("@tanstack/react-query").UseQueryResult<APIResponse<UnavailableDatesResponse>, Error>;
