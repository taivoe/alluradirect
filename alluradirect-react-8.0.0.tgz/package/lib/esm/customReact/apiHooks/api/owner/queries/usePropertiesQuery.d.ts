import { ConfigurableAppQueryArgs } from '../../../useAppQuery/useAppQuery';
import { APIResponse } from '../../../../../api/types';
import { OwnerProperty } from '../../../../../api/owner/types';
interface Args {
    ownerId: number;
}
export declare const usePropertiesQuery: ({ ownerId, ...rest }: Args & ConfigurableAppQueryArgs<any>) => import("@tanstack/react-query").UseQueryResult<APIResponse<{
    PROPERTIES: OwnerProperty[];
    OWNER_ID: number;
}>, Error>;
export {};
