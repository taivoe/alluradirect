import { NotificationEndpointFilterCategory, NotificationEndpointFilterStatus } from '../../../../../api/types';
interface Args {
    ownerId: number;
    category: NotificationEndpointFilterCategory;
    status: NotificationEndpointFilterStatus;
    propertyId?: number;
    refetchInterval?: number;
    enabled?: boolean;
}
export declare const useOwnerNotificationsQueryKeys: import("../../../queryKeyFactory").QueryKeys;
export declare const useOwnerNotificationsInfiniteQuery: ({ ownerId, category, status, enabled, refetchInterval, propertyId, }: Args) => import("@tanstack/react-query").UseInfiniteQueryResult<import("@tanstack/query-core").InfiniteData<any, unknown>, any>;
export {};
