import { ConfigurableAppQueryArgs } from '../../../useAppQuery/useAppQuery';
import { APIResponse } from '../../../../../api/types';
interface Args {
    ownerId: number;
    propertyId?: number;
    numMonths: number;
}
export declare const ownerUnbookableDatesQueryKey: import("../../../queryKeyFactory").QueryKeys;
export declare const useOwnerUnbookableDatesQuery: ({ ownerId, propertyId, numMonths, ...rest }: Args & ConfigurableAppQueryArgs) => import("@tanstack/react-query").UseQueryResult<APIResponse<{
    OWNER_ID: string;
    PROPERTIES: {
        PROPERTY: {
            ID: number;
            TITLE: string;
            THUMBNAIL: string;
        };
        BLOCKED_DATES: {
            ARRIVAL: string;
            DEPARTURE: string;
            BOOKING_ID: number;
            TITLE: string;
            DESCRIPTION: string;
        }[];
        MIN_NIGHT_GAPS: {
            PROPERTY_ID: number;
            START: string;
            MIN_NIGHTS: number;
            AVAILABLE_NIGHTS: number;
            END: string;
        }[];
        LAST_AVAILABLE_DATE: string;
    }[];
}>, Error>;
export {};
