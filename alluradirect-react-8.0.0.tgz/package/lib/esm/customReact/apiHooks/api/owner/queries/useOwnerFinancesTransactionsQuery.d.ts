import { ConfigurableAppQueryArgs } from '../../../useAppQuery/useAppQuery';
import { TransactionsArgs } from '../../../../../api/owner/endpoints';
import { APIResponse } from '../../../../../api/types';
export declare const useOwnerFinancesTransactionsQuery: ({ ownerId, year, toMonth, fromMonth, propertyId, sortOrder, filter, ...rest }: TransactionsArgs & ConfigurableAppQueryArgs) => import("@tanstack/react-query").UseQueryResult<APIResponse<{
    OWNER_ID: number;
    TRANSACTIONS: {
        BOOKING_DATES: string;
        BOOKING_ID: number;
        BOOKING_REFERENCE: string;
        DETAIL_ID: number;
        GUEST_NAME: string;
        PROPERTY_ID: number;
        TRANSFER_AMOUNT: string;
        TRANSFER_DATE: string;
        TRANSFER_DETAILS: string;
    }[];
}>, Error>;
