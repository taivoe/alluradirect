import { ConfigurableAppQueryArgs } from '../../../useAppQuery/useAppQuery';
import { APIResponse } from '../../../../../api/types';
interface Args {
    ownerId: number;
    propertyId?: number;
    numMonths: number;
}
export declare const ownerExternalEventsQueryKey: import("../../../queryKeyFactory").QueryKeys;
export declare const useOwnerExternalEventsQuery: ({ ownerId, propertyId, numMonths, ...rest }: Args & ConfigurableAppQueryArgs) => import("@tanstack/react-query").UseQueryResult<APIResponse<{
    PROPERTIES: {
        PROPERTY: {
            ID: number;
            TITLE: string;
            THUMBNAIL: string;
        };
        EXTERNAL_BOOKINGS: {
            SOURCE: string;
            NIGHTS: number;
            ARRIVAL: string;
            DEPARTURE: string;
            ID: number;
            SUMMARY: string;
        }[];
    }[];
    OWNER_ID: string;
}>, Error>;
export {};
