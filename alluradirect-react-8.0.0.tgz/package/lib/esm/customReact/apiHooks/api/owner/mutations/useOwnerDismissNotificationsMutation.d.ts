import { ConfigurableAppMutationArgs } from '../../../useAppMutation/useAppMutation';
interface Values {
    /** Owner Id */
    id: number;
    notification_ids: number[] | 'all';
}
export declare const useOwnerDismissNotificationsMutation: (args: ConfigurableAppMutationArgs) => import("@tanstack/react-query").UseMutationResult<any, Error, Values, void>;
export {};
