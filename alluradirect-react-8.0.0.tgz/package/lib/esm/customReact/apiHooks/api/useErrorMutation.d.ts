interface Values {
    client_ip: number;
    user_id: number;
    user_type_id: number;
    stack_trace: string;
    message: string;
}
export declare const useErrorMutation: () => import("@tanstack/react-query").UseMutationResult<any, Error, Values, void>;
export {};
