import { UserMessage } from '../../../../../../api/user/types';
export declare const generateEditReservationMessage: ({ guestId, propertyOwnerId, message, booking_id, start, end, }: {
    guestId: number;
    propertyOwnerId: number;
    message: string;
    booking_id: number;
    start: string;
    end: string;
}) => UserMessage;
export declare const generateCancelReservationMessage: ({ guestId, propertyOwnerId, message, booking_id, }: {
    guestId: number;
    propertyOwnerId: number;
    message: string;
    booking_id: number;
}) => UserMessage;
