import { APIResponse } from '../../../../../api/types';
import { ConfigurableAppQueryArgs } from '../../../useAppQuery/useAppQuery';
interface Args {
    email: string;
}
export declare const useUserCheckEmailTaken: ({ email, ...rest }: Args & ConfigurableAppQueryArgs) => import("@tanstack/react-query").UseQueryResult<APIResponse<{
    IS_EMAIL_TAKEN: boolean;
}>, Error>;
export {};
