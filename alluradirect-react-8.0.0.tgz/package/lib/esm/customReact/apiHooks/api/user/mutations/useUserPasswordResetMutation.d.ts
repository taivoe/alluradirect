interface Values {
    email: string;
}
export declare const useUserPasswordResetMutation: () => import("@tanstack/react-query").UseMutationResult<any, Error, Values, void>;
export {};
