import { APIResponse } from '../../../../../api/types';
import { ConfigurableAppMutationArgs } from '../../../useAppMutation/useAppMutation';
interface Values {
    urlArgs: string[];
}
export declare const useUserCheckEmailTakenMutation: (props?: ConfigurableAppMutationArgs) => import("@tanstack/react-query").UseMutationResult<APIResponse<{
    is_email_taken: boolean;
}>, Error, Values, void>;
export {};
