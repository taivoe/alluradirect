interface Props {
    /** The bookingId is not required when editing a booking
     *  since we want to allow the dates that the booking is on to be available */
    bookingId?: number;
    isGuestRole: boolean;
    isOwnerRole: boolean;
    propertyId?: number;
    guestId?: number;
    isEnabled?: boolean;
    onSuccess?: () => void;
}
export declare const useUnavailableDates: ({ isOwnerRole, isGuestRole, bookingId, propertyId, guestId, isEnabled, onSuccess, }: Props) => import("@tanstack/query-core").QueryObserverRefetchErrorResult<import("../../../../../../api/types").APIResponse<import("../../../guest/queries/useGuestUnavailableDates").UnavailableDatesResponse>, Error> | import("@tanstack/query-core").QueryObserverSuccessResult<import("../../../../../../api/types").APIResponse<import("../../../guest/queries/useGuestUnavailableDates").UnavailableDatesResponse>, Error> | import("@tanstack/query-core").QueryObserverLoadingErrorResult<import("../../../../../../api/types").APIResponse<import("../../../guest/queries/useGuestUnavailableDates").UnavailableDatesResponse>, Error> | import("@tanstack/query-core").QueryObserverPendingResult<import("../../../../../../api/types").APIResponse<import("../../../guest/queries/useGuestUnavailableDates").UnavailableDatesResponse>, Error> | import("@tanstack/query-core").QueryObserverPlaceholderResult<import("../../../../../../api/types").APIResponse<import("../../../guest/queries/useGuestUnavailableDates").UnavailableDatesResponse>, Error>;
export {};
