import { UserMessageSubject, UserRoleIDEnum } from '../../../../../api/user/types';
import { APIResponse } from '../../../../../api/types';
interface Args {
    userId: number;
    userTypeId: UserRoleIDEnum;
    bookingId?: number;
    messageId?: number;
    enabled?: boolean;
    onSuccess?: (data?: any) => void;
}
export declare const useUserMessageSubject: ({ userId, userTypeId, bookingId, messageId, enabled, onSuccess, }: Args) => import("@tanstack/react-query").UseQueryResult<APIResponse<{
    SUBJECT: UserMessageSubject;
}>, Error>;
export {};
