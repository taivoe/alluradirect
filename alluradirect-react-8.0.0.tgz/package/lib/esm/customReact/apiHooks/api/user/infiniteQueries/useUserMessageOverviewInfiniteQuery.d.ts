import { UserRoleIDEnum } from '../../../../../api/user/types';
interface Args {
    id: number;
    userTypeId: UserRoleIDEnum;
    /** Optional: filter by a specific property id */
    propertyId?: number;
    enabled?: boolean;
    refetchInterval?: number;
}
export declare const userMessageOverviewQueryKeys: import("../../../queryKeyFactory").QueryKeys;
export declare const useUserMessageOverviewInfiniteQuery: ({ id, userTypeId, propertyId, refetchInterval, enabled, }: Args) => import("@tanstack/react-query").UseInfiniteQueryResult<import("@tanstack/query-core").InfiniteData<any, unknown>, any>;
export {};
