import { APIResponse } from '../../../../../api/types';
import { User } from '../../../../../api/user/types';
import { ConfigurableAppMutationArgs } from '../../../useAppMutation/useAppMutation';
interface SendValue {
    id: number;
    email: string;
    password: string;
}
export declare const useUserCredentialsPutMutation: (args?: ConfigurableAppMutationArgs) => import("@tanstack/react-query").UseMutationResult<APIResponse<User>, Error, SendValue, void>;
export {};
