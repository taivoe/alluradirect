import { InfiniteQueryPageDirections } from '../../../../../api/types';
import { UserRoleIDEnum } from '../../../../../api/user/types';
interface Args {
    id: number;
    userTypeId: UserRoleIDEnum;
    subjectType: 'past_bookings' | 'future_bookings' | 'inquiries';
    filterUserId?: number;
    filterUserTypeId?: UserRoleIDEnum;
    searchFilter?: string;
    pageDirection?: InfiniteQueryPageDirections;
    enabled?: boolean;
}
export declare const userMessageSubjectsQueryKeys: import("../../../queryKeyFactory").QueryKeys;
export declare const useUserMessageSubjectsInfiniteQuery: ({ id, userTypeId, subjectType, searchFilter, filterUserId, filterUserTypeId, pageDirection, enabled, }: Args) => import("@tanstack/react-query").UseInfiniteQueryResult<import("@tanstack/query-core").InfiniteData<any, unknown>, any>;
export {};
