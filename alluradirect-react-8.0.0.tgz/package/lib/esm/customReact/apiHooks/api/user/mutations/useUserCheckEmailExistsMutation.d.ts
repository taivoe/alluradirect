import { APIResponse } from '../../../../../api/types';
import { ConfigurableAppMutationArgs } from '../../../useAppMutation/useAppMutation';
interface Values {
    urlArgs: string[];
}
export declare const useUserCheckEmailExistsMutation: (props?: ConfigurableAppMutationArgs) => import("@tanstack/react-query").UseMutationResult<APIResponse<{
    IS_EMAIL_TAKEN: boolean;
}>, Error, Values, void>;
export {};
