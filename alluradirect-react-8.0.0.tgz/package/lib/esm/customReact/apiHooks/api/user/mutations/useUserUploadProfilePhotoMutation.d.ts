import { ConfigurableAppMutationArgs } from '../../../useAppMutation/useAppMutation';
import { UserRoleIDEnum } from '../../../../../api/user/types';
export interface UploadProfilePhotoSendValues {
    /** base64 version of the image being uploaded */
    file: string;
    id: number;
    user_type_id: UserRoleIDEnum;
    /** x axis point for crop; note if cropped then x,y,width,height,rotation are all required */
    x?: number;
    y?: number;
    width?: number;
    height?: number;
    rotation?: number;
}
export declare const useUserUploadProfilePhotoMutation: (props: ConfigurableAppMutationArgs) => import("@tanstack/react-query").UseMutationResult<any, Error, UploadProfilePhotoSendValues, void>;
