import { UserRoleIDEnum } from '../../../../../api/user/types';
interface Args {
    userId: number;
    userTypeId: UserRoleIDEnum;
    contactId: number | undefined;
    contactUserTypeId: UserRoleIDEnum | undefined;
}
/** When a user selects a subject they can  */
export declare const useMessageSubjectInfiniteQuery: ({ userId, userTypeId, contactId, contactUserTypeId }: Args) => {
    upcomingBookings: {
        ID: number;
        CONTACT: {
            ID: number;
            THUMBNAIL: string;
            NAME: string;
            USER_TYPE_ID: UserRoleIDEnum;
            EMAIL: string;
        };
        BOOKING: {
            ID: number;
            ARRIVAL_DATE: string;
            DEPARTURE_DATE: string;
            CREATED_DATE: string;
            REFERENCE: string;
        };
        PROPERTY: {
            ID: number;
            THUMBNAIL: string;
            NAME: string;
            SIZE_CATEGORY: string;
        };
        MESSAGE: {
            MESSAGE: string;
            SUBJECT: string;
            TO_EMAILS: string;
            DATE_SENT: string;
            FROM_EMAIL: string;
            RECIPIENT: string;
            THUMBNAIL: string;
            TIME_SENT: string;
            ID: number;
            RECIPIENT_ID: number;
            IS_READ: boolean;
            READ_DATE: string;
            READ_TIME: string;
            NUM_UNREAD: number;
            ARRIVAL_DATE: string;
            DEPARTURE_DATE: string;
            CREATED_DATE: string;
            NUM_BEDS: number;
            NUM_GUESTS: number;
            IS_INQUIRY: boolean;
        };
    }[];
    pastBookings: {
        ID: number;
        CONTACT: {
            ID: number;
            THUMBNAIL: string;
            NAME: string;
            USER_TYPE_ID: UserRoleIDEnum;
            EMAIL: string;
        };
        BOOKING: {
            ID: number;
            ARRIVAL_DATE: string;
            DEPARTURE_DATE: string;
            CREATED_DATE: string;
            REFERENCE: string;
        };
        PROPERTY: {
            ID: number;
            THUMBNAIL: string;
            NAME: string;
            SIZE_CATEGORY: string;
        };
        MESSAGE: {
            MESSAGE: string;
            SUBJECT: string;
            TO_EMAILS: string;
            DATE_SENT: string;
            FROM_EMAIL: string;
            RECIPIENT: string;
            THUMBNAIL: string;
            TIME_SENT: string;
            ID: number;
            RECIPIENT_ID: number;
            IS_READ: boolean;
            READ_DATE: string;
            READ_TIME: string;
            NUM_UNREAD: number;
            ARRIVAL_DATE: string;
            DEPARTURE_DATE: string;
            CREATED_DATE: string;
            NUM_BEDS: number;
            NUM_GUESTS: number;
            IS_INQUIRY: boolean;
        };
    }[];
    isLoading: boolean;
    upcomingBookingsQuery: import("@tanstack/react-query").UseInfiniteQueryResult<import("@tanstack/query-core").InfiniteData<any, unknown>, any>;
    pastBookingsQuery: import("@tanstack/react-query").UseInfiniteQueryResult<import("@tanstack/query-core").InfiniteData<any, unknown>, any>;
};
export {};
