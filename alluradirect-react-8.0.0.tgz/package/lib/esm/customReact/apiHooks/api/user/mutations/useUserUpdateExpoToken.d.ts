import { ConfigurableAppMutationArgs } from '../../../useAppMutation/useAppMutation';
interface SendValues {
    id: number;
    token: string;
    is_enabled: boolean;
}
/** Update existing user <-> token link, enable or disable */
export declare const useUserUpdateExpoToken: (args?: ConfigurableAppMutationArgs) => import("@tanstack/react-query").UseMutationResult<any, Error, SendValues, void>;
export {};
