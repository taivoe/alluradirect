import { ConfigurableAppMutationArgs } from '../../../../useAppMutation/useAppMutation';
import { TwilioVerificationChannelEnum } from './types';
interface SendValues {
    value: string;
    channel: TwilioVerificationChannelEnum;
}
/** Can be used if user is authenticated or unauthenticated */
export declare const useTwilioSendCodeMutation: (args?: ConfigurableAppMutationArgs) => import("@tanstack/react-query").UseMutationResult<any, Error, SendValues, void>;
export {};
