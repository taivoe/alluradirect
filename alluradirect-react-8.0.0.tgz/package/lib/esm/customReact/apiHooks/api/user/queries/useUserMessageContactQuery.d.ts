import { ConfigurableAppQueryArgs } from '../../../useAppQuery/useAppQuery';
import { User } from '../../../../../api/user/types';
import { APIResponse } from '../../../../../api/types';
import { UserMessageContactArgs } from '../../../../../api/user/endpoints';
export declare const useUserMessageContactQuery: ({ contactUserId, contactUserTypeId, propertyId, enabled, ...rest }: UserMessageContactArgs & ConfigurableAppQueryArgs<any>) => import("@tanstack/react-query").UseQueryResult<APIResponse<{
    CONTACT: User;
    LAST_RESERVATION_DATE: string;
    NEXT_RESERVATION_DATE: string;
    STATUS: string;
}>, Error>;
