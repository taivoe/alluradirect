import { UserMessage } from '../../../../../../api/user/types';
export declare const useUserCreateMessageMutation: () => import("@tanstack/react-query").UseMutationResult<any, Error, UserMessage, void>;
