import { ConfigurableAppMutationArgs } from '../../../useAppMutation/useAppMutation';
interface SendValues {
    id: number;
    token: string;
}
/** Create a new user <-> token link in db */
export declare const useUserCreateExpoToken: (args?: ConfigurableAppMutationArgs) => import("@tanstack/react-query").UseMutationResult<any, Error, SendValues, void>;
export {};
