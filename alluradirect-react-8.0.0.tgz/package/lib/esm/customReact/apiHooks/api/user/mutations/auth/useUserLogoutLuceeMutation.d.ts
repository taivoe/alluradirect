import { ConfigurableAppMutationArgs } from '../../../../useAppMutation/useAppMutation';
export declare const useUserLogoutLuceeMutation: (args?: ConfigurableAppMutationArgs) => import("@tanstack/react-query").UseMutationResult<any, Error, any, void>;
