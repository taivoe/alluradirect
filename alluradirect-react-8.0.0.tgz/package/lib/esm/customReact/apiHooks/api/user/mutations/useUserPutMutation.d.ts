import { APIResponse } from '../../../../../api/types';
import { User } from '../../../../../api/user/types';
import { ConfigurableAppMutationArgs } from '../../../useAppMutation/useAppMutation';
/** FIRST_NAME, LAST_NAME are empty strings when IS_COMPANY is true
 * COMPANY is empty string when IS_COMPANY is false
 */
interface SendData extends Pick<User, 'ID' | 'EMAIL' | 'PHONE' | 'FIRST_NAME' | 'LAST_NAME' | 'COMPANY_NAME' | 'IS_COMPANY' | 'DATE_OF_BIRTH'> {
    CITY: string;
    COUNTRY: string;
    POSTAL: string;
    REGION: string;
    STREET_NUMBER: string;
    STREET_NAME: string;
    /** empty string for no unit number */
    UNIT: string;
}
export declare const useUserPutMutation: (args?: ConfigurableAppMutationArgs) => import("@tanstack/react-query").UseMutationResult<APIResponse<{
    USER: User;
}>, Error, SendData, void>;
export {};
