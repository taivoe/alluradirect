import { APIResponse } from '../../../../../../api/types';
import { User } from '../../../../../../api/user/types';
import { ConfigurableAppMutationArgs } from '../../../../useAppMutation/useAppMutation';
interface Values {
    email: string;
    password: string;
}
interface Response {
    USER: User;
    JSESSIONID: string;
}
export declare const useUserLoginMutation: (args?: ConfigurableAppMutationArgs) => import("@tanstack/react-query").UseMutationResult<APIResponse<Response>, Error, Values, void>;
export {};
