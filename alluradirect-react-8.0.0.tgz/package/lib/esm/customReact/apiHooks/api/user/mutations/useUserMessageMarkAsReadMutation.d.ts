import { ConfigurableAppMutationArgs } from '../../../useAppMutation/useAppMutation';
import { UserRoleIDEnum } from '../../../../../api/user/types';
interface MessageMarkAsReadSendData {
    id: number;
    user_type_id: UserRoleIDEnum;
    contact_user_id: number;
    contact_user_type_id: UserRoleIDEnum;
}
export declare const useUserMessageMarkAsReadMutation: (args: ConfigurableAppMutationArgs) => import("@tanstack/react-query").UseMutationResult<any, Error, MessageMarkAsReadSendData, void>;
export {};
