import { UserRoleIDEnum } from '../../../../../api/user/types';
import { ConfigurableAppInfiniteQueryArgs } from '../../../useAppInfiniteQuery/types';
interface Args {
    id: number;
    userTypeId: UserRoleIDEnum;
    contactUserId: number;
    contactUserTypeId: UserRoleIDEnum;
}
export declare const userMessageThreadQueryKeys: import("../../../queryKeyFactory").QueryKeys;
export declare const useUserMessageThreadInfiniteQuery: ({ id, userTypeId, contactUserId, contactUserTypeId, ...rest }: Args & ConfigurableAppInfiniteQueryArgs) => import("@tanstack/react-query").UseInfiniteQueryResult<import("@tanstack/query-core").InfiniteData<any, unknown>, any>;
export {};
