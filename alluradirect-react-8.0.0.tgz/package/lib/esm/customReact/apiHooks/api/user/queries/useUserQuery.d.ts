import { APIResponse } from '../../../../../api/types';
import { User } from '../../../../../api/user/types';
import { ConfigurableAppQueryArgs } from '../../../useAppQuery/useAppQuery';
export declare const userQueryKey = "USER";
interface Args {
    /** Force Luccee to reload the user from the db
     * If a django endpoint modifies the user object then Luccee will not get the changes unless this is set to true
     */
    isReloadUser?: boolean;
}
/** This query will return the user object is the user is logged in.
 * It essentially will act as an auth_state query in addition to fetching the user object.
 */
export declare const useUserQuery: ({ isReloadUser, ...useQueryOptions }?: Args & ConfigurableAppQueryArgs) => import("@tanstack/react-query").UseQueryResult<APIResponse<{
    USER: User | false;
}>, Error>;
export {};
