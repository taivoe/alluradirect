import { ConfigurableAppQueryArgs } from '../../../useAppQuery/useAppQuery';
import { UserRoleIDEnum } from '../../../../../api/user/types';
import { APIResponse } from '../../../../../api/types';
interface Args {
    id: number;
    userTypeId: UserRoleIDEnum;
}
export declare const useUserMessageUnreadQuery: ({ id, userTypeId, enabled, ...rest }: Args & ConfigurableAppQueryArgs<any>) => import("@tanstack/react-query").UseQueryResult<APIResponse<{
    USER_MESSAGE_COUNT: number;
}>, Error>;
export {};
