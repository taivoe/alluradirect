export interface QueryKeys {
    all: [string];
    lists: () => [string, 'list'];
    list: (filters: string) => [string, 'list', {
        [key: string]: string;
    }];
    details: () => [string, 'detail'];
    detail: (id: string) => [string, 'detail', string];
}
export declare function queryKeyFactory(keyName: string): QueryKeys;
