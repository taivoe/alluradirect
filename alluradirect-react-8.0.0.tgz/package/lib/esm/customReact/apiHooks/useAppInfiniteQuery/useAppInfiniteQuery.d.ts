import { UseInfiniteQueryOptions } from '@tanstack/react-query';
import { AppInfiniteQueryArgs } from './types';
export declare const useAppInfiniteQuery: <TReturnValues = any>(args: AppInfiniteQueryArgs & UseInfiniteQueryOptions<any, any, any, any, any>) => import("@tanstack/react-query").UseInfiniteQueryResult<import("@tanstack/react-query").InfiniteData<any, unknown>, any>;
