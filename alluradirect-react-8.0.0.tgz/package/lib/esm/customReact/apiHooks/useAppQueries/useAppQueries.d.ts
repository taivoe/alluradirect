interface QueryObject {
    queryKey: string | string[];
    endpoint: string;
    enabled?: boolean;
    select?: (data: any) => any;
    onSuccess?: (data: any) => void;
    onError?: (err: any) => void;
    onSettled?: (data: any | undefined, err: any) => void;
    retry?: boolean | number | ((failureCount: number, error: Error) => boolean) | undefined;
    staleTime?: number | undefined;
    cacheTime?: number | undefined;
    refetchOnWindowFocus?: boolean;
    refetchInterval?: number | false;
    hasToastsEnabled?: boolean;
}
interface Args {
    queries: QueryObject[];
}
export declare const useAppQueries: ({ queries }: Args) => import("@tanstack/react-query").UseQueryResult<unknown, Error>[];
export {};
