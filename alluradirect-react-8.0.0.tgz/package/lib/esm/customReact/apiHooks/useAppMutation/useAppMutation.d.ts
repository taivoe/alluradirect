import { FetchMethodTypes, FetchMethods } from '../types';
interface Args<TVariables = any, TData = any> {
    /** Pass in string unless you need to modify the url based on TVariables data
     * Pass in a function and an array in TVariables urlArgs field to modify the url on send
     * ex) function fun(a, b, c) => string
     *     values.urlArgs = [1, 2, 3]
     * */
    url: string | ((...args: string[]) => string);
    method: FetchMethods | FetchMethodTypes;
    isCustomSendData?: boolean;
    isSubform?: boolean;
    onSuccess?: (data: TData, variables: TVariables) => Promise<unknown> | void;
    onError?: (error: unknown, variables: TVariables, context: void | undefined) => Promise<unknown> | void;
    onSettled?: (data: any, error: unknown, variables: TVariables, context: void | undefined) => Promise<unknown> | void;
    onMutate?: (value: any) => void;
    hasToastsEnabled?: boolean;
    mutationKey?: string;
    hasSuccessToastEnabled?: boolean;
    hasErrorToastEnabled?: boolean;
    /** modify the data before its sent, useful for encapsulating logic in a custom mutation hook */
    modifySendDataFn?: (data: TVariables) => any;
}
export type ConfigurableAppMutationArgs = Omit<Args, 'url' | 'method' | 'isCustomSendData' | 'isSubform'>;
export declare const useAppMutation: <TVariables = any, TData = any>({ url, method, isCustomSendData, isSubform, onSuccess, onError, onSettled, onMutate, hasToastsEnabled, mutationKey, hasSuccessToastEnabled, hasErrorToastEnabled, modifySendDataFn, }: Args<TVariables, TData>) => import("@tanstack/react-query").UseMutationResult<TData, Error, TVariables, void>;
export {};
