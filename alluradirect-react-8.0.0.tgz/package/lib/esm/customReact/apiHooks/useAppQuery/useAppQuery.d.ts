interface Args<T> {
    endpoint: string;
    queryKey?: string | string[];
    enabled?: boolean;
    select?: (data: any) => T;
    onSuccess?: (data: T) => void;
    onError?: (err: any) => void;
    onSettled?: (data: T | undefined, err: any) => void;
    retry?: boolean | number | ((failureCount: number, error: Error) => boolean) | undefined;
    staleTime?: number | undefined;
    cacheTime?: number | undefined;
    refetchOnWindowFocus?: boolean;
    refetchInterval?: number | false;
    useErrorBoundary?: boolean;
    hasToastsEnabled?: boolean;
}
/** Include this type as an argument with your custom query hook to gain access to the defined useQuery methods listed as args in useAppQuery
 * These methods include onSuccess, onError, onSettled, retry, staleTime, cacheTime, etc.
 */
export type ConfigurableAppQueryArgs<T = any> = Omit<Args<T>, 'endpoint' | 'queryKey'>;
export declare function useAppQuery<TData = any>({ endpoint, enabled, select, onSuccess, onError, onSettled, staleTime, cacheTime, retry, refetchOnWindowFocus, queryKey, refetchInterval, hasToastsEnabled, useErrorBoundary, }: Args<TData>): import("@tanstack/react-query").UseQueryResult<import("@tanstack/react-query").NoInfer<TData>, Error>;
export {};
