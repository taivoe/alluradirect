import { MessageThreadItem } from '../../api/user/types';
interface Args {
    lastThreadData: MessageThreadItem | undefined;
    hasCurrentSubjectSelection: boolean;
    setBookingId: (id: number) => void;
    setMessageId: (id: number) => void;
}
/** When a user enters a thread from an overview screen none of bookingId or messageId are set
 *  To set one of these and download the subject we check the last message in the thread
 */
export declare const useUpdateSubjectSelection: ({ lastThreadData, hasCurrentSubjectSelection, setBookingId, setMessageId, }: Args) => void;
export {};
