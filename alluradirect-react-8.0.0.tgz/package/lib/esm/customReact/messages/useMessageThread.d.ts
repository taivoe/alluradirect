import { UserRoleIDEnum } from '../../api/user/types';
import { ConfigurableAppInfiniteQueryArgs } from '../apiHooks/useAppInfiniteQuery/types';
interface Args {
    userId: number;
    userTypeId: UserRoleIDEnum;
    contactUserId: number;
    contactUserTypeId: UserRoleIDEnum;
}
export declare const useMessageThread: ({ userTypeId, userId, contactUserId, contactUserTypeId, ...rest }: Args & ConfigurableAppInfiniteQueryArgs) => {
    threadQuery: import("@tanstack/react-query").UseInfiniteQueryResult<import("@tanstack/query-core").InfiniteData<any, unknown>, any>;
    threadData: {
        MESSAGE: {
            MESSAGE: string;
            IS_READ: boolean;
            SUBJECT: string;
            TO_EMAILS: string;
            FROM_EMAIL: string;
            THUMBNAIL: string;
            SENT_DATE: string;
            SENT_TIME: string;
            BOOKING_ID: number;
            ID: number;
            READ_DATE: string;
            READ_TIME: string;
            INQUIRY_ID: number;
            SENDER_USER_ID: number;
            SENDER_USER_TYPE_ID: UserRoleIDEnum;
            RECEIVER_USER_ID: number;
            RECEIVER_USER_TYPE_ID: UserRoleIDEnum;
            ARRIVAL_DATE: string;
            DEPARTURE_DATE: string;
            IS_INQUIRY: boolean;
            NUM_BEDS: number;
            NUM_GUESTS: number;
        };
        PROPERTY: {
            ID: number;
            THUMBNAIL: string;
            NAME: string;
            SIZE_CATEGORY: string;
        };
        BOOKING: {
            ID: number;
            ARRIVAL_DATE: string;
            DEPARTURE_DATE: string;
            CREATED_DATE: string;
            REFERENCE: string;
        };
    }[];
    lastThreadData: {
        MESSAGE: {
            MESSAGE: string;
            IS_READ: boolean;
            SUBJECT: string;
            TO_EMAILS: string;
            FROM_EMAIL: string;
            THUMBNAIL: string;
            SENT_DATE: string;
            SENT_TIME: string;
            BOOKING_ID: number;
            ID: number;
            READ_DATE: string;
            READ_TIME: string;
            INQUIRY_ID: number;
            SENDER_USER_ID: number;
            SENDER_USER_TYPE_ID: UserRoleIDEnum;
            RECEIVER_USER_ID: number;
            RECEIVER_USER_TYPE_ID: UserRoleIDEnum;
            ARRIVAL_DATE: string;
            DEPARTURE_DATE: string;
            IS_INQUIRY: boolean;
            NUM_BEDS: number;
            NUM_GUESTS: number;
        };
        PROPERTY: {
            ID: number;
            THUMBNAIL: string;
            NAME: string;
            SIZE_CATEGORY: string;
        };
        BOOKING: {
            ID: number;
            ARRIVAL_DATE: string;
            DEPARTURE_DATE: string;
            CREATED_DATE: string;
            REFERENCE: string;
        };
    } | undefined;
    refreshThread: () => Promise<void>;
    refreshingThread: boolean;
};
export {};
