import { CreateMessageSubject } from './types';
import { UserMessageSubject } from '../../api/user/types';
export declare function generateCreateMessageSubject(subject: UserMessageSubject | undefined): CreateMessageSubject | undefined;
