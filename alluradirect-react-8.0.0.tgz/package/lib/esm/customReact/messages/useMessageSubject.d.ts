import { UserMessageSubject, UserRoleIDEnum } from '../../api/user/types';
import { CreateMessageSubject } from './types';
interface Args {
    userId: number;
    userTypeId: UserRoleIDEnum;
    hasCurrentSubjectSelection: boolean;
    bookingId?: number;
    messageId?: number;
}
/** Fetch and set the selected subject and property based on the param passed in
 *  selectedSubject and selectedProperty will be auto-selected when sending a message for convenience
 */
export declare const useMessageSubject: ({ userId, userTypeId, hasCurrentSubjectSelection, bookingId, messageId }: Args) => {
    subjectQuery: import("@tanstack/react-query").UseQueryResult<import("../../api/types").APIResponse<{
        SUBJECT: UserMessageSubject;
    }>, Error>;
    selectedSubject: CreateMessageSubject | undefined;
    setSelectedSubject: import("react").Dispatch<import("react").SetStateAction<CreateMessageSubject | undefined>>;
    selectedProperty: {
        ID: number;
        THUMBNAIL: string;
        NAME: string;
        SIZE_CATEGORY: string;
    } | undefined;
    setSelectedProperty: import("react").Dispatch<import("react").SetStateAction<{
        ID: number;
        THUMBNAIL: string;
        NAME: string;
        SIZE_CATEGORY: string;
    } | undefined>>;
};
export {};
