import { UserRoleIDEnum } from '../../api/user/types';
interface Args {
    userId: number;
    userTypeId: UserRoleIDEnum;
    contactUserId: number;
    contactUserTypeId: UserRoleIDEnum;
}
/** Automatically marks all messages between the current user and a contact user as read */
export declare const useMessageMarkAsRead: ({ contactUserId, contactUserTypeId, userId, userTypeId }: Args) => void;
export {};
