import { UserMessageContactArgs } from '../../api/user/endpoints';
import { MessageUserContact } from '../../api/user/types';
export declare const useMessageContact: ({ propertyId, contactUserId, contactUserTypeId }: UserMessageContactArgs) => {
    userContactQuery: import("@tanstack/react-query").UseQueryResult<import("../../api/types").APIResponse<{
        CONTACT: import("../../api/user/types").User;
        LAST_RESERVATION_DATE: string;
        NEXT_RESERVATION_DATE: string;
        STATUS: string;
    }>, Error>;
    userContact: MessageUserContact | undefined;
};
