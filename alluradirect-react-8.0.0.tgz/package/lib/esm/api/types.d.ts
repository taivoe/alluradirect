import { BLACKOUT_PERIOD, BOOKING_SURCHARGES_LIST, CANCELLATION_POLICY, NOTIFICATION_ENDPOINT_RESPONSE, address, amenity, contactTracingGuest, initialLocationData, notification, propertyGuidebookPDF, propertyOwner, tax, taxSurcharge, transaction } from './constants';
import { FetchMethodTypes, FetchMethods } from '../customReact/apiHooks/types';
export type NotificationEndpointResponse = typeof NOTIFICATION_ENDPOINT_RESPONSE;
export type PropertyGuidebookPDF = typeof propertyGuidebookPDF;
export type BookingSurchargesList = typeof BOOKING_SURCHARGES_LIST;
export type Address = typeof address;
export type CancellationPolicy = typeof CANCELLATION_POLICY;
export type Tax = typeof tax;
export type TaxSurcharge = typeof taxSurcharge;
export type Transaction = typeof transaction;
export type LocationDetails = typeof initialLocationData;
export type AlluraNotification = typeof notification;
export type Amenity = typeof amenity;
export type BlackoutPeriod = typeof BLACKOUT_PERIOD;
/** Group an api url with corresponding methods and typings!
 * Makes it easy for developers to put together related info regarding an endpoint
 */
export type APIEndpoint<TEndpoint = any, TReturn = any, TSend = any> = {
    endpoint: TEndpoint;
    method: FetchMethods | FetchMethodTypes;
    returnType: TReturn;
    sendType?: TSend;
};
export type APIResponse<T> = {
    DATA: T;
    ERRORS: {
        CLIENT_MESSAGE?: string;
        DEVELOPER_MESSAGE?: string;
    };
    MESSAGES: {
        CLIENT_MESSAGE?: string;
        DEVELOPER_MESSAGE?: string;
    };
    SUCCESS: boolean;
};
export interface APIKeyResponse<T, P extends string> extends Omit<APIResponse<T>, 'DATA'> {
    DATA: {
        [key in P]: T;
    };
}
export type WithRequiredProperty<Type, Key extends keyof Type> = Type & {
    [Property in Key]-?: Type[Property];
};
export declare enum SurchargeIDEnum {
    cleaningFee = 1,
    petFee = 2
}
export declare enum SurchargeNameEnum {
    cleaning = "CLEANING",
    pet = "PETS"
}
export declare enum TaxIDEnum {
    GST = 1,
    PST = 2,
    MRDT = 19
}
export declare enum NotificationCategoriesEnum {
    NEWS = "news",
    BOOKING = "booking",
    FINANCE = "finance",
    INQUIRIES = "inquiry",
    PROPERTIES = "properties",
    REVIEW = "review",
    RESERVATION_REQUEST = "reservation_request",
    SUBSCRIPTION_RENEWAL = "subscription_renewal",
    UNBOOKABLE_DATES = "unbookable_dates",
    UPDATE_LISTING = "update_listing"
}
export declare enum NotificationCategoryIdEnum {
    ALLURA_NEWS = 1,
    BOOKING = 2,
    FINANCE = 3,
    INQUIRY = 4,
    REVIEW = 5,
    /** Appears when a property is in gateway closed mode */
    RESERVATION_REQUEST = 6,
    SUBSCRIPTION_RENEWAL = 7,
    UNBOOKABLE_DATES = 8,
    UPDATE_LISTING = 9
}
export declare enum NotificationEndpointFilterCategory {
    NEWS = "news",
    FEATURED = "featured",
    PRIMARY = "primary"
}
export declare enum NotificationEndpointFilterStatus {
    ALL = "all",
    DISMISSED = "dismissed",
    ACTIVE = "active"
}
export declare enum NotificationLevelsEnum {
    INFORMATIONAL = "informational",
    DEADLINE_APPROACHING = "deadline approaching",
    REQUIRES_ACTION = "requires action",
    URGENT_NOTICE = "urgent notice"
}
export declare enum DamageDepositModeId {
    COLLECT_AT_CHECKIN = 1,
    COLLECT_45_DAYS_BEFORE_ARRIVAL = 3,
    COLLECT_DAMAGE_UPON_DEPARTURE = 4
}
export interface LocationDataResort {
    REGION_ID: number;
    NAME: string;
    ID: number;
}
export interface LocationDataDevelopment {
    AREA_ID: number;
    ID: number;
    NAME: string;
    RESORT_ID: number;
}
export interface LocationDataRegion {
    ID: number;
    NAME: string;
    COUNTRY_ID: number;
}
export interface NameIdItem {
    NAME: string;
    ID: number;
}
export declare enum PropertyTaxIDEnum {
    GST = 1,
    PST_BC = 2,
    MRDT_WHISTLER = 19
}
export declare enum PropertyAmenityId {
    PRIVATE_SKI_STORAGE = 14,
    PRIVATE_BIKE_STORAGE = 15,
    BUILDING_BIKE_STORAGE = 21,
    BUILDING_SKI_STORAGE = 22,
    BUILDING_HOT_TUB = 25,
    BUILDING_SAUNA = 26,
    BUILDING_STEAM_ROOM = 27,
    BUILDING_POOL = 28,
    BUILDING_FITNESS_FACILITIES = 30,
    BUILDING_GAMES_REC_ROOM = 31,
    WIFI = 93
}
export declare enum LocationURLParamsEnum {
    developments = "developments",
    countries = "countries",
    resorts = "resorts",
    regions = "regions",
    areas = "areas",
    property_categories = "property_categories"
}
export declare enum ToastVariants {
    default = "default",
    error = "error",
    success = "success",
    warning = "warning",
    info = "info"
}
export declare enum NotificationStatus {
    DISMISSED = "dismissed",
    ACTIVE = ""
}
export type ContactTracingGuest = typeof contactTracingGuest;
export type PropertyOwner = typeof propertyOwner;
export type InfiniteQueryPageDirections = 'future' | 'past';
