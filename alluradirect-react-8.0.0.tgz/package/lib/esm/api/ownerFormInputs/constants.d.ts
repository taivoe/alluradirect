import { AccessCodeIdEnum, AccessCodeTypeIDEnum, AccessMethodIdEnum, Amenities, AmenityCategories, BedroomTypeItem, BedroomTypes, Channel, EmergencyContactType, FormBookingPlatform, FormInputsReservationSettings, FormMostImportant, JoinStatusItem, LabelNameItem, NameIdDescriptionItem, PhotoValidation, Policies, PropertyManagerItem, PropertySetting, PropertySettingItem, RateAutomationItem, RateGroupItem, RateSuggestionItem, SearchFilters, Subforms, SubscriptionTier, SuitabilityItem } from './types';
import { CancellationPolicy, NameIdItem } from '../types';
import { RateInsightLevelIdEnum, RatesSettingsWeekendPremiumId } from '../property/types';
declare const TAX: {
    REGION_NAME: string;
    IS_MANDATORY: boolean;
    IS_REGISTRATION_NUMBER_REQUIRED: boolean;
    NAME: string;
    ID: number;
    RESORT_NAME: string;
    RATE: number;
    COUNTRY_NAME: string;
    DESCRIPTION: string;
};
export declare const initialFormInputs: {
    ACCESS_TO_UNIT: {
        TYPES: {
            NAME: string;
            ID: AccessCodeIdEnum;
        }[];
        METHODS: {
            NAME: string;
            ID: AccessMethodIdEnum;
        }[];
        CODES: {
            NAME: string;
            ID: AccessCodeTypeIDEnum;
        }[];
    };
    ADVANCED_BOOKING: NameIdItem[];
    AMENITIES: Amenities;
    AMENITY_CATEGORIES: AmenityCategories;
    BEDROOM_TYPES: BedroomTypes[];
    BED_TYPES: BedroomTypeItem[];
    CONTACT_EMAIL_NOTIFICATION_TYPES: LabelNameItem[];
    DAMAGE_DEPOSIT_MODES: NameIdItem[];
    DEFAULT_CHANNELS: Channel[];
    EMERGENCY_CONTACT_TYPES: EmergencyContactType[];
    JOIN_STATUSES: JoinStatusItem[];
    MILESTONE_MESSAGES: any;
    NON_RESIDENT: {
        MIN_OWNERS: number;
        MAX_OWNERS: number;
    };
    PARTNERS: any;
    CLEANING_PROTOCOL_URL: string;
    PHOTO_VALIDATION: PhotoValidation;
    POLICIES: Policies;
    POLICIES_CANCELLATION: CancellationPolicy[];
    POLICIES_CANCELLATION_SPECIAL: NameIdDescriptionItem[];
    POLICIES_MANDATORY: NameIdItem[];
    PROPERTY_CATEGORIES: NameIdItem[];
    PROPERTY_MANAGERS: PropertyManagerItem[];
    PROPERTY_STYLES: NameIdItem[];
    RATES_SETTINGS: {
        RATE_GROUP_ITEMS: RateGroupItem[];
        AVAILABILITY_WINDOW: RateAutomationItem[];
        PROPERTY_SETTINGS: PropertySetting[];
        RATE_GROUP_TYPES: PropertySettingItem[];
        WEEKEND_PREMIUMS: PropertySettingItem[];
        LAST_ALLURA_EVENT: string;
        EXTEND_RATES_SCHEDULE_MONTHS: number[];
        REPLACE_RATES_SCHEDULE_MONTHS: number[];
        RATE_INSIGHTS: {
            ID: RateInsightLevelIdEnum;
            NAME: string;
        }[];
    };
    RATES_SETTINGS_SUGGESTIONS: {
        DISCOUNT_GROUP: {
            FIVE_NIGHTS: number;
            ID: number;
            SEVEN_NIGHTS: number;
            TEN_NIGHTS: number;
        };
        WEEKEND_PREMIUM_SUGGESTION: {
            PERCENTAGE_AMOUNT: number;
            DOLLAR_AMOUNT: number;
            ID: RatesSettingsWeekendPremiumId;
        };
        LAST_DAY_OF_SUGGESTIONS: string;
        RATE_INSIGHTS_LEVEL_ID: number;
    };
    RATES_SUGGESTIONS: RateSuggestionItem[];
    RESERVATION_SETTINGS: FormInputsReservationSettings;
    REST_API_SEARCH_MIN_DATE: string;
    SUBSCRIPTION_TIERS: SubscriptionTier[];
    SETUP_QUESTIONS: {
        MOST_IMPORTANT: FormMostImportant[];
        PLATFORMS: FormBookingPlatform[];
    };
    SUBFORMS_OPTIONAL: string[];
    SUBFORMS: {
        OPTIONAL: Subforms[];
        REQUIRED: Subforms[];
    };
    SUITABILITIES: SuitabilityItem[];
    SURCHARGES: NameIdDescriptionItem[];
    TAXES: (typeof TAX)[];
    TAX_NUMBERS: NameIdDescriptionItem[];
    EXTERNAL_CHANNELS: Channel[];
    SEARCH_FILTERS: SearchFilters;
    UNBOOKABLE_NIGHTS_DATE_RANGE: {
        VALUE: number;
        LABEL: string;
    }[];
};
export {};
