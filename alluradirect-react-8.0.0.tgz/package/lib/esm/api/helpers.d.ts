import { APIResponse } from './types';
export declare function generateAPIResponse<T>(data: T): APIResponse<T>;
