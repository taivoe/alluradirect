import { CreditStatusEnum, CreditReasonGivenEnum } from './types';
export declare const CREDITS_OVERVIEW: {
    total_credits: string;
    pending_credits: string;
    remaining_credits: string;
    credit_expiry_date: string;
    refer_guest_link: string;
    refer_owner_link: string;
    offer_amounts: {
        user_referred_owner: string;
        user_referred_guest: string;
        guest_referred_by_user: string;
        owner_referred_by_user: string;
    };
    credit_history: {
        id: number;
        amount_total: string;
        amount_remaining: string;
        sender: {
            id: number;
            first_name: string;
            last_name: string;
            company_name: string;
            is_company: boolean;
            email: string;
        };
        status: {
            status: string;
            id: CreditStatusEnum;
        };
        reason_given: {
            reason: string;
            id: CreditReasonGivenEnum;
        };
        detail: string;
        expiry_date: string;
        created_at: string;
    }[];
};
