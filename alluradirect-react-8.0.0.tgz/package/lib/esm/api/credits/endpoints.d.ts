export declare const generateCreditsOverviewEndpoint: (userId: number) => string;
