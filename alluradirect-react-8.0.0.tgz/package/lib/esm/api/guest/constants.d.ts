import { Bathroom, Bedroom, EmergencyContact, Photo } from '../property/types';
import { GuestBooking, GuestBookingType } from './types';
import { GuestPaymentFee, GuestPaymentTaxes, GuestRatingQuestion, GuestRecommendation } from './types';
import { RatingRange, Review } from '../booking/types';
import { User } from '../user/types';
import { WithRequiredProperty } from '../types';
export declare const GUEST_FORM_INPUTS: {
    GUEST_ID: number;
    REVIEW: {
        RATINGS: GuestRatingQuestion[];
        RESPONSES: {
            GUEST_MAXIMUM_NUMBER: number;
            OWNER_MAXIMUM_NUMBER: number;
        };
        STATUSES: never[];
    };
};
export declare const GUEST_RATING_QUESTION: {
    QUESTION: string;
    MAX_SCORE: number;
    ID: number;
    TITLE: string;
    SCORE: RatingRange;
    SORT_ORDER: number;
};
export declare const GUEST_REVIEWS: {
    REVIEWS: Review[];
    RECOMMENDATIONS: GuestRecommendation[];
};
export declare const GUEST_RECOMMENDATION: {
    ARRIVAL: string;
    COMMENTS: string;
    CONFIRMED: string;
    DEPARTURE: string;
    HAS_COMMENTS_ENABLED: boolean;
    HOST_NAME: string;
    ID: number;
    IS_RECOMMENDED: boolean;
    REFERENCE: string;
    BOOKING_ID: number;
};
export declare const GUEST_PAYMENT: {
    ID: number;
    BOOKING_ID: number;
    BOOKING: GuestBooking;
    BOOKING_TYPE: GuestBookingType;
    PAYMENT_RECEIPT: string;
};
export declare const GUEST_PAYMENT_INFORMATION: {
    ID: number;
    PAYMENT_DUE: {
        BOOKING: {
            AMOUNT_DUE: number;
            ARRIVAL: string;
            BOOKING_NET: number;
            BOOKING_TOTAL: number;
            DAMAGE_DEPOSIT: number;
            DEPARTURE: string;
            ID: number;
            NIGHTLY_RATE: number;
            NIGHTS: number;
            PAID_TO_DATE: number;
            PARTY_SIZE: number;
            TAXES_AND_FEES_TOTAL: number;
        };
        FEES: GuestPaymentFee[];
        TAXES: GuestPaymentTaxes[];
    };
};
export declare const subSection: {
    ID: number;
    HTML: string[] | string;
    DETAILS: {
        NAME: string;
        VALUE: string;
    }[];
};
export declare const propertyGuidebook: Readonly<{
    PROPERTY_GUIDEBOOK: {
        BOOKING: {
            CUSTOM_MESSAGE: {
                MESSAGE: string;
                ENTRY_CODE: string;
            };
            STATUS: {
                ID: import("../booking/types").BookingStatusId;
                NAME: string;
            };
        };
        PROPERTY: {
            ID: number;
            IS_SKI_IN_SKI_OUT: boolean;
            THUMBNAIL: string;
            IS_COMPANY: string;
            ARRIVAL: string;
            DEPARTURE: string;
            CHECK_IN_TIME: string;
            CHECK_OUT_TIME: string;
            QUIET_TIME: string;
            BATHROOMS: Bathroom[];
            BEDROOMS: Bedroom[];
            LOGO: string;
            COVER_PHOTO: string;
            LISTING_PAGE: string;
            ACCESS_TO_UNIT: {
                CODE: {
                    NAME: string;
                    ID: import("../ownerFormInputs/types").AccessCodeIdEnum;
                };
                METHOD: {
                    NAME: string;
                    ID: import("../ownerFormInputs/types").AccessMethodIdEnum;
                };
                STANDARD_CODE: string;
                TYPE: {
                    NAME: string;
                    ID: import("../ownerFormInputs/types").AccessCodeTypeIDEnum;
                };
            };
            ADDRESS: {
                AREA: string;
                AREA_ID: number;
                CITY: string;
                COUNTRY: string;
                COUNTRY_CODE: string;
                COUNTRY_ID: number;
                DEVELOPMENT: string;
                DEVELOPMENT_ID: number;
                ID: number;
                LATITUDE: number;
                LONGITUDE: number;
                POSTAL: string;
                REGION: string;
                REGION_ID: number;
                RESORT: string;
                RESORT_ID: number;
                STREET_NAME: string;
                STREET_NUMBER: string;
                UNIT: string;
            };
            OWNER: WithRequiredProperty<User, "OWNER_PROFILE">;
            CODES: {
                BIKE_LOCKER_CODE: string;
                DEVELOPMENT_DOOR_CODE: string;
                DEVELOPMENT_GYM_CODE: string;
                DEVELOPMENT_HOT_TUB_CODE: string;
                DEVELOPMENT_POOL_CODE: string;
                DEVELOPMENT_SAUNA_CODE: string;
                DEVELOPMENT_STEAM_ROOM_CODE: string;
                FRONT_DOOR_CODE: string;
                GAMES_REC_ROOM_CODE: string;
                GARAGE_DOOR_CODE: string;
                GARBAGE_RECYCLING_CODE: string;
                ID: number;
                INTERNET_NETWORK_NAME: string;
                INTERNET_PASSWORD: string;
                PHONE_NUMBER: string;
                PROPERTY_ID: string;
                SKI_LOCKER_CODE: string;
                DATE_LAST_UPDATED: string;
            };
            EMERGENCY_CONTACTS: {
                DESCRIPTION: string;
                CONTACTS: {
                    OTHERS: EmergencyContact[];
                    PRIMARY: EmergencyContact;
                };
            };
            PHOTOS: Photo[];
            PRIMARY_CONTACT: User;
        };
        SECTIONS: {
            WELCOME: {
                DESCRIPTION_PER_GUEST: string;
                TITLE: string;
                DESCRIPTION_PER_PROPERTY: string;
            };
            ARRIVAL: {
                ACCESS_DETAILS: {
                    DATA: {
                        ID: number;
                        HTML: string[] | string;
                        DETAILS: {
                            NAME: string;
                            VALUE: string;
                        }[];
                    };
                    ICON: string;
                    DESCRIPTION: string;
                    TITLE: string;
                };
                DIRECTIONS_TO_PROPERTY: {
                    DATA: {
                        ID: number;
                        HTML: string[] | string;
                        DETAILS: {
                            NAME: string;
                            VALUE: string;
                        }[];
                    };
                    ICON: string;
                    DESCRIPTION: string;
                    TITLE: string;
                };
                PARKING: {
                    DATA: {
                        ID: number;
                        HTML: string[] | string;
                        DETAILS: {
                            NAME: string;
                            VALUE: string;
                        }[];
                    };
                    ICON: string;
                    DESCRIPTION: string;
                    TITLE: string;
                };
                CHECK_IN_PROCESS: {
                    DATA: {
                        ID: number;
                        HTML: string[] | string;
                        DETAILS: {
                            NAME: string;
                            VALUE: string;
                        }[];
                    };
                    ICON: string;
                    DESCRIPTION: string;
                    TITLE: string;
                };
            };
            DEPARTURE: {
                CHECK_OUT_PROCESS: {
                    DATA: {
                        ID: number;
                        HTML: string[] | string;
                        DETAILS: {
                            NAME: string;
                            VALUE: string;
                        }[];
                    };
                    ICON: string;
                    DESCRIPTION: string;
                    TITLE: string;
                };
                GARBAGE_REMOVAL: {
                    DATA: {
                        ID: number;
                        HTML: string[] | string;
                        DETAILS: {
                            NAME: string;
                            VALUE: string;
                        }[];
                    };
                    ICON: string;
                    DESCRIPTION: string;
                    TITLE: string;
                };
            };
            PROPERTY_AMENITIES: {
                PRIVATE: {
                    DATA: {
                        ID: number;
                        NAME: string;
                        INSTRUCTIONS: string;
                        DESCRIPTION: string;
                        PROPERTY_AMENITY_ID: number;
                        ACCESS_CODE: string;
                        INTERNET_PASSWORD: string;
                        INTERNET_NETWORK_NAME: string;
                    }[];
                    ICON: string;
                    DESCRIPTION: string;
                    TITLE: string;
                };
                ESSENTIALS: {
                    DATA: {
                        ID: number;
                        NAME: string;
                        INSTRUCTIONS: string;
                        DESCRIPTION: string;
                        PROPERTY_AMENITY_ID: number;
                        ACCESS_CODE: string;
                        INTERNET_PASSWORD: string;
                        INTERNET_NETWORK_NAME: string;
                    }[];
                    ICON: string;
                    DESCRIPTION: string;
                    TITLE: string;
                };
                KITCHEN: {
                    DATA: {
                        ID: number;
                        NAME: string;
                        INSTRUCTIONS: string;
                        DESCRIPTION: string;
                        PROPERTY_AMENITY_ID: number;
                        ACCESS_CODE: string;
                        INTERNET_PASSWORD: string;
                        INTERNET_NETWORK_NAME: string;
                    }[];
                    ICON: string;
                    DESCRIPTION: string;
                    TITLE: string;
                };
                SAFETY: {
                    DATA: {
                        ID: number;
                        NAME: string;
                        INSTRUCTIONS: string;
                        DESCRIPTION: string;
                        PROPERTY_AMENITY_ID: number;
                        ACCESS_CODE: string;
                        INTERNET_PASSWORD: string;
                        INTERNET_NETWORK_NAME: string;
                    }[];
                    ICON: string;
                    DESCRIPTION: string;
                    TITLE: string;
                };
                HEATING_INSTRUCTIONS: {
                    DATA: string[] | string;
                    ICON: string;
                    DESCRIPTION: string;
                    TITLE: string;
                };
                LINENS_TOWELS: {
                    DATA: string[] | string;
                    ICON: string;
                    DESCRIPTION: string;
                    TITLE: string;
                };
            };
            BUILDING_FACILITIES: {
                ABOUT_BUILDING: {
                    DATA: {
                        ID: number;
                        HTML: string[] | string;
                        DETAILS: {
                            NAME: string;
                            VALUE: string;
                        }[];
                    };
                    ICON: string;
                    DESCRIPTION: string;
                    TITLE: string;
                };
                FRONT_DESK: {
                    DATA: {
                        ID: number;
                        HTML: string[] | string;
                        DETAILS: {
                            NAME: string;
                            VALUE: string;
                        }[];
                    };
                    ICON: string;
                    DESCRIPTION: string;
                    TITLE: string;
                };
                BUILDING_AMENITIES: {
                    DATA: {
                        ID: number;
                        NAME: string;
                        INSTRUCTIONS: string;
                        DESCRIPTION: string;
                        PROPERTY_AMENITY_ID: number;
                        ACCESS_CODE: string;
                        INTERNET_PASSWORD: string;
                        INTERNET_NETWORK_NAME: string;
                    }[];
                    ICON: string;
                    DESCRIPTION: string;
                    TITLE: string;
                };
            };
            EQUIPMENT_STORAGE: {
                SKI_STORAGE: {
                    DATA: {
                        PRIVATE: {
                            ID: number;
                            NAME: string;
                            INSTRUCTIONS: string;
                            DESCRIPTION: string;
                            PROPERTY_AMENITY_ID: number;
                            ACCESS_CODE: string;
                            INTERNET_PASSWORD: string;
                            INTERNET_NETWORK_NAME: string;
                        };
                        BUILDING: {
                            ID: number;
                            NAME: string;
                            INSTRUCTIONS: string;
                            DESCRIPTION: string;
                            PROPERTY_AMENITY_ID: number;
                            ACCESS_CODE: string;
                            INTERNET_PASSWORD: string;
                            INTERNET_NETWORK_NAME: string;
                        };
                    };
                    ICON: string;
                    DESCRIPTION: string;
                    TITLE: string;
                };
                BIKE_STORAGE: {
                    DATA: {
                        PRIVATE: {
                            ID: number;
                            NAME: string;
                            INSTRUCTIONS: string;
                            DESCRIPTION: string;
                            PROPERTY_AMENITY_ID: number;
                            ACCESS_CODE: string;
                            INTERNET_PASSWORD: string;
                            INTERNET_NETWORK_NAME: string;
                        };
                        BUILDING: {
                            ID: number;
                            NAME: string;
                            INSTRUCTIONS: string;
                            DESCRIPTION: string;
                            PROPERTY_AMENITY_ID: number;
                            ACCESS_CODE: string;
                            INTERNET_PASSWORD: string;
                            INTERNET_NETWORK_NAME: string;
                        };
                    };
                    ICON: string;
                    DESCRIPTION: string;
                    TITLE: string;
                };
            };
            GETTING_AROUND: {
                SKI_IN_OUT: {
                    DATA: {
                        ID: number;
                        HTML: string[] | string;
                        DETAILS: {
                            NAME: string;
                            VALUE: string;
                        }[];
                    };
                    ICON: string;
                    DESCRIPTION: string;
                    TITLE: string;
                };
                DIRECTIONS_TO_LIFTS: {
                    DATA: {
                        ID: number;
                        HTML: string[] | string;
                        DETAILS: {
                            NAME: string;
                            VALUE: string;
                        }[];
                    };
                    ICON: string;
                    DESCRIPTION: string;
                    TITLE: string;
                };
                GETTING_AROUND: {
                    DATA: {
                        ID: number;
                        HTML: string[] | string;
                        DETAILS: {
                            NAME: string;
                            VALUE: string;
                        }[];
                    };
                    ICON: string;
                    DESCRIPTION: string;
                    TITLE: string;
                };
            };
            RECOMMENDATIONS: {
                WHAT_TO_BRING: {
                    DATA: {
                        ID: number;
                        HTML: string[] | string;
                        DETAILS: {
                            NAME: string;
                            VALUE: string;
                        }[];
                    };
                    ICON: string;
                    DESCRIPTION: string;
                    TITLE: string;
                };
                RESTAURANTS: {
                    DATA: {
                        ID: number;
                        HTML: string[] | string;
                        DETAILS: {
                            NAME: string;
                            VALUE: string;
                        }[];
                    };
                    ICON: string;
                    DESCRIPTION: string;
                    TITLE: string;
                };
            };
            SERVICES_OTHER: {
                AVAILABLE_SERVICES: {
                    DATA: {
                        ID: number;
                        HTML: string[] | string;
                        DETAILS: {
                            NAME: string;
                            VALUE: string;
                        }[];
                    };
                    ICON: string;
                    DESCRIPTION: string;
                    TITLE: string;
                };
                HOUSEKEEPING: {
                    DATA: {
                        ID: number;
                        HTML: string[] | string;
                        DETAILS: {
                            NAME: string;
                            VALUE: string;
                        }[];
                    };
                    ICON: string;
                    DESCRIPTION: string;
                    TITLE: string;
                };
                OTHER: {
                    DATA: {
                        ID: number;
                        HTML: string[] | string;
                        DETAILS: {
                            NAME: string;
                            VALUE: string;
                        }[];
                    };
                    ICON: string;
                    DESCRIPTION: string;
                    TITLE: string;
                };
            };
        };
    };
    BOOKING_ID: 0;
    ID: 0;
}>;
export declare const B64_PROPERTY_GUIDEBOOK: {
    PROPERTY_GUIDEBOOK_PDF: string;
};
