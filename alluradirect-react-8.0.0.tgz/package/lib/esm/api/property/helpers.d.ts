import { TransactionsOrReservationsServerSearchTool } from './types';
export declare const generatePropertyTransactionsParameters: (propertyId: number, { startDate, endDate, status, sort, source }: TransactionsOrReservationsServerSearchTool) => string;
