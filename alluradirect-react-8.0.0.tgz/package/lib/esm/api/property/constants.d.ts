import { AccessCodeIdEnum, AccessCodeTypeIDEnum, AccessMethodIdEnum } from '../ownerFormInputs/types';
import { Amenity, DamageDepositModeId, WithRequiredProperty } from '../types';
import { Bathroom, Bedroom, EmergencyContact, GuidebookWalkthrough, JoinStatusIDEnum, NoRatesDate, Photo, Policy, PricingStrategyEnum, PropertySubscriptionTierIdEnum, RateAvailabilityIdEnum, RateGroup, RateInsightLevelIdEnum, RatesSettingsWeekendPremiumId, ServerRateSchedule } from './types';
import { OptionalSubformsEnum, RequiredSubformsEnum } from '../subformNames';
import { EventTypeEnum } from './types';
import { ReviewStatusId } from '../booking/types';
import { User, UserRoleIDEnum } from '../user/types';
import { PropertyPermission } from '../user/constants';
export declare const RATES_SETTINGS: {
    /** Every month, extend the users rate schedule up to their availability window, cannot be use when availability window is unrestricted */
    IS_AVAILABILITY_AUTOMATION_ENABLED: boolean;
    /** AKA Pricing insights/Smart Pricing data
     * If true then the property has the option to enable optimized pricing */
    HAS_RATE_INSIGHTS_DATA: boolean;
    /** Every month, optimize the users rate schedule using the smart pricing level set
     *  Each date range can have its own smart pricing level, otherwise uses the property-level smart pricing level */
    IS_OPTIMIZED_PRICING_ENABLED: boolean;
    NO_RATES_DATES: NoRatesDate[];
    PRICING_STRATEGY: {
        ID: PricingStrategyEnum;
        RATE_INSIGHTS_LEVEL_ID: RateInsightLevelIdEnum;
    };
    WEEKEND_PREMIUM: {
        ID: RatesSettingsWeekendPremiumId;
        DOLLAR_AMOUNT: number;
        PERCENTAGE_AMOUNT: number;
    };
    AVAILABILITY_WINDOW: {
        ID: RateAvailabilityIdEnum;
    };
    DATE_LAST_SAVED: string;
    RATE_GROUPS: {
        HIGH: RateGroup;
        LOW: RateGroup;
        PRIME: RateGroup;
        MID: RateGroup;
    };
    DISCOUNT_GROUP: {
        TEN_DAY: number;
        SEVEN_DAY: number;
        FIVE_DAY: number;
        ID: number;
    };
    ID: number;
};
export declare const ACCESS_TO_UNIT: {
    CODE: {
        NAME: string;
        ID: AccessCodeIdEnum;
    };
    METHOD: {
        NAME: string;
        ID: AccessMethodIdEnum;
    };
    /** STANDARD_CODE and FRONT_DOOR_CODE are linked for a property */
    STANDARD_CODE: string;
    TYPE: {
        NAME: string;
        ID: AccessCodeTypeIDEnum;
    };
};
export declare const SURCHARGE: {
    AMOUNT: string;
    ID: number;
    IS_ENABLED: boolean;
    NAME: string;
};
export declare const PROPERTY_SURCHARGES: {
    CLEANING: {
        AMOUNT: string;
        ID: number;
        IS_ENABLED: boolean;
        NAME: string;
    };
    PETS: {
        AMOUNT: string;
        ID: number;
        IS_ENABLED: boolean;
        NAME: string;
    };
};
export declare const ITN_INFORMATION: {
    ID: number;
    ITN: number;
    PERCENTAGE_OWNERSHIP: number;
    DOB: string;
    FIRST_NAME: string;
    LAST_NAME: string;
};
export declare const NON_RESIDENT: {
    ITN_INFO: {
        ID: number;
        ITN: number;
        PERCENTAGE_OWNERSHIP: number;
        DOB: string;
        FIRST_NAME: string;
        LAST_NAME: string;
    }[];
    IS_NON_RESIDENT: boolean;
    WITHHOLDING_PERCENTAGE: number;
};
export declare const PROPERTY_CODES: {
    BIKE_LOCKER_CODE: string;
    /** Used for building entrance when a single door code is not sufficient */
    DEVELOPMENT_DOOR_CODE: string;
    /** Used for sauna and steam room */
    DEVELOPMENT_GYM_CODE: string;
    DEVELOPMENT_HOT_TUB_CODE: string;
    /** Used for pool and hot-tub */
    DEVELOPMENT_POOL_CODE: string;
    DEVELOPMENT_SAUNA_CODE: string;
    DEVELOPMENT_STEAM_ROOM_CODE: string;
    /** Used for access to unit/building. This is linked to the ACCESS_TO_UNIT STANDARD_CODE field */
    FRONT_DOOR_CODE: string;
    GAMES_REC_ROOM_CODE: string;
    GARAGE_DOOR_CODE: string;
    GARBAGE_RECYCLING_CODE: string;
    ID: number;
    INTERNET_NETWORK_NAME: string;
    INTERNET_PASSWORD: string;
    PHONE_NUMBER: string;
    PROPERTY_ID: string;
    SKI_LOCKER_CODE: string;
    DATE_LAST_UPDATED: string;
};
export declare const PROPERTY_RULES: {
    ID: number;
    ADVANCED_BOOKING: {
        NAME: string;
        ID: number;
    };
    CHECK_IN: string;
    CHECK_OUT: string;
    MAX_BOOKABLE_DAYS: number;
    MAX_GUESTS: number;
    MIN_AGE_TO_BOOK: number;
    QUIET_TIME: string;
};
export declare const initialPropertyState: {
    ID: number;
    ACCESS_TO_UNIT: {
        CODE: {
            NAME: string;
            ID: AccessCodeIdEnum;
        };
        METHOD: {
            NAME: string;
            ID: AccessMethodIdEnum;
        };
        /** STANDARD_CODE and FRONT_DOOR_CODE are linked for a property */
        STANDARD_CODE: string;
        TYPE: {
            NAME: string;
            ID: AccessCodeTypeIDEnum;
        };
    };
    ADDRESS: {
        AREA: string;
        AREA_ID: number;
        CITY: string;
        COUNTRY: string;
        COUNTRY_CODE: string;
        COUNTRY_ID: number;
        DEVELOPMENT: string;
        DEVELOPMENT_ID: number;
        ID: number;
        LATITUDE: number;
        LONGITUDE: number;
        POSTAL: string;
        REGION: string;
        REGION_ID: number;
        RESORT: string;
        RESORT_ID: number;
        STREET_NAME: string;
        STREET_NUMBER: string;
        UNIT: string;
    };
    AMENITIES: {
        BUILDING: {
            TYPE: string;
            LIST: Amenity[];
        };
        ESSENTIAL: {
            TYPE: string;
            LIST: Amenity[];
        };
        KITCHEN: {
            TYPE: string;
            LIST: Amenity[];
        };
        PRIVATE: {
            TYPE: string;
            LIST: Amenity[];
        };
        SAFETY: {
            TYPE: string;
            LIST: Amenity[];
        };
    };
    BANKING: {
        ACCOUNTHOLDER: {
            ADDRESS: {
                AREA: string;
                AREA_ID: number;
                CITY: string;
                COUNTRY: string;
                COUNTRY_CODE: string;
                COUNTRY_ID: number;
                DEVELOPMENT: string;
                DEVELOPMENT_ID: number;
                ID: number;
                LATITUDE: number;
                LONGITUDE: number;
                POSTAL: string;
                REGION: string;
                REGION_ID: number;
                RESORT: string;
                RESORT_ID: number;
                STREET_NAME: string;
                STREET_NUMBER: string;
                UNIT: string;
            };
            COMPANY_NAME: string;
            FIRST_NAME: string;
            IS_COMPANY: boolean;
            LAST_NAME: string;
        };
        BANK: {
            ACCOUNT_NUMBER: string;
            INSTITUTION: string;
            NAME: string;
            TRANSIT: string;
            ID: number;
        };
    };
    BATHROOMS: Bathroom[];
    BEDROOMS: Bedroom[];
    BLOCKOFFS: never[];
    CANCELLATION_POLICY: {
        ADMIN_PENALTY: number;
        ADMIN_PENALTY_UNIT: string;
        BOOKING_GRACE_PERIOD: string;
        DATE_ACTIVATED: string;
        DATE_LAST_UPDATED: string;
        DATE_RANGES: {
            DATE_ACTIVATED: string;
            DESCRIPTION: string;
            FROM_DAYS: string;
            ID: number;
            LABEL: string;
            REFUND_PERCENTAGE: string;
            TO_DAYS: string;
        }[];
        DESCRIPTION: string;
        ID: number;
        IS_CREDIT_ONLY_REFUND: boolean;
        IS_REFUND_REBOOKED_DATES: boolean;
        IS_SPECIAL_CIRCUMSTANCE: boolean;
        NAME: string;
        POLICY_ID: number;
        SERVICE_FEE_REFUND: string;
        SPECIAL_CIRCUMSTANCE_DESCRIPTION: string;
        SPECIAL_CIRCUMSTANCE_ID: number;
        SPECIAL_CIRCUMSTANCE_NAME: string;
        SURCHARGE_REFUND: string;
    };
    CLEANING_PROTOCOL: {
        HAS_AUTOMATIC_BUFFER_DAYS: boolean;
        IS_APPLY_TO_EXISTING_BOOKINGS: boolean;
        NUMBER_OF_BLOCKOFF_DAYS: number;
    };
    CODES: {
        BIKE_LOCKER_CODE: string;
        /** Used for building entrance when a single door code is not sufficient */
        DEVELOPMENT_DOOR_CODE: string;
        /** Used for sauna and steam room */
        DEVELOPMENT_GYM_CODE: string;
        DEVELOPMENT_HOT_TUB_CODE: string;
        /** Used for pool and hot-tub */
        DEVELOPMENT_POOL_CODE: string;
        DEVELOPMENT_SAUNA_CODE: string;
        DEVELOPMENT_STEAM_ROOM_CODE: string;
        /** Used for access to unit/building. This is linked to the ACCESS_TO_UNIT STANDARD_CODE field */
        FRONT_DOOR_CODE: string;
        GAMES_REC_ROOM_CODE: string;
        GARAGE_DOOR_CODE: string;
        GARBAGE_RECYCLING_CODE: string;
        ID: number;
        INTERNET_NETWORK_NAME: string;
        INTERNET_PASSWORD: string;
        PHONE_NUMBER: string;
        PROPERTY_ID: string;
        SKI_LOCKER_CODE: string;
        DATE_LAST_UPDATED: string;
    };
    CO_HOST: {
        COHOST_PROFILE: {
            PERMISSIONS: Omit<PropertyPermission, "PROPERTY_ID">;
            PROPERTY_IDS: never[];
        };
        ID: number;
        FIRST_NAME: string;
        LAST_NAME: string;
        IS_COMPANY: boolean;
        COMPANY_NAME: string;
        THUMBNAIL: string;
        PHONE: string;
        EMAIL: string;
        CREATED_DATE: string;
        DATE_LAST_LOGIN: string;
        DATE_UPDATED: string;
        ADDRESS: {
            AREA: string;
            AREA_ID: number;
            CITY: string;
            COUNTRY: string;
            COUNTRY_CODE: string;
            COUNTRY_ID: number;
            DEVELOPMENT: string;
            DEVELOPMENT_ID: number;
            ID: number;
            LATITUDE: number;
            LONGITUDE: number;
            POSTAL: string;
            REGION: string;
            REGION_ID: number;
            RESORT: string;
            RESORT_ID: number;
            STREET_NAME: string;
            STREET_NUMBER: string;
            UNIT: string;
        };
        IS_SMS_VERIFIED: boolean;
        IS_EMAIL_VERIFIED: boolean;
        DATE_EMAIL_VERIFIED: string;
        DATE_SMS_VERIFIED: string;
        DATE_OF_BIRTH: string;
        IS_ACTIVE: boolean;
        IS_STAFF: boolean;
        IS_SUPERUSER: boolean;
        IS_DUE_DILIGENCE_REQUIRED: boolean;
    };
    CONTENT: {
        ABOUT_THE_BUILDING: string;
        DESCRIPTION: string;
        KITCHEN: string;
        LOCATION: string;
        SUMMARY: string;
        TITLE: string;
    };
    DAMAGE_DEPOSIT: {
        AMOUNT: string;
        TYPE: {
            ID: DamageDepositModeId;
            NAME: string;
        };
    };
    DAYS_TO_EXPIRY: number;
    DIRECT_VACATIONS: {
        ID: number;
        IS_ACTIVE: boolean;
        LOGO: string;
        NAME: string;
        URL: string;
    };
    EMERGENCY_CONTACTS: {
        PRIMARY: EmergencyContact;
        OTHERS: EmergencyContact[];
    };
    EXTERNAL_URLS: {
        URL_AIRBNB: string;
        URL_OTHER: string;
        URL_VRBO: string;
    };
    ICALS: {
        HAS_ICALS: boolean;
        PRIMARY: {
            ALLURA_URL: string;
            AVAILABILITY_WINDOW: number;
            IS_AVAILABILITY_WINDOW: boolean;
            IS_BLOCK_RATELESS: boolean;
        };
        SECONDARY: {
            ALLURA_URL: string;
            AVAILABILITY_WINDOW: number;
            IS_ACTIVE: boolean;
            IS_AVAILABILITY_WINDOW: boolean;
            IS_BLOCK_RATELESS: boolean;
        };
        EXTERNAL: {
            ID: number;
            LISTING_URL: string;
            NAME: string;
            URL: string;
        }[];
    };
    INSTRUCTIONS: {
        ABOUT_THE_BUILDING: string;
        ACTIVITIES: string;
        BUILDING_COMMON_AREAS: string;
        CHECK_IN: string;
        CHECK_OUT: string;
        EMERGENCY_CONTACTS: string;
        FRONT_DESK: string;
        GARBAGE_RECYCLING: string;
        GETTING_AROUND: string;
        GETTING_TO_UNIT: string;
        HEATING: string;
        HOUSEKEEPING: string;
        ID: number;
        INFANT_SUPPLIES: string;
        KITCHEN: string;
        LATE_CHECK_IN: string;
        LINENS_AND_TOWELS: string;
        OTHER: string;
        PARKING: string;
        RESTAURANTS: string;
        SERVICES: string;
        SKI_IN_SKI_OUT: string;
        TO_FROM_LIFTS: string;
        WELCOME: string;
        WHAT_TO_BRING: string;
    };
    IS_ALLURA_RATES: boolean;
    IS_CO_HOST_MANAGER_ENABLED: string;
    IS_ENABLED: boolean;
    IS_SKI_IN_SKI_OUT: boolean;
    JOIN_STATUS: {
        COMPLETION_PERCENTAGE_REQUIRED: number;
        COMPLETION_PERCENTAGE_OPTIONAL: number;
        DATES: {
            CREATED: string;
            LAST_UPDATED: string;
            ACTIVATED: string;
            ACTIVATION_REQUEST: string;
        };
        HAS_COMPLETED_ONBOARDING: boolean;
        STATUS: string;
        STATUS_ID: JoinStatusIDEnum;
        SUBFORMS_COMPLETED: RequiredSubformsEnum[];
        SUBFORMS_OPTIONAL_COMPLETED: OptionalSubformsEnum[];
    };
    LISTING_QUALITY: {
        MESSAGE: string;
        RATES_AVAILABILITY: {
            MESSAGE: string;
            PROPERTY_COUNT: number;
            RECOMMENDED_COUNT: number;
            SCORE: number;
        };
        PROPERTY_GUIDEBOOK: {
            MESSAGE: string;
            PROPERTY_COUNT: number;
            RECOMMENDED_COUNT: number;
            SCORE: number;
        };
        STAR_RATING: number;
        PHOTOS: {
            MESSAGE: string;
            PROPERTY_COUNT: number;
            RECOMMENDED_COUNT: number;
            SCORE: number;
        };
    };
    NAME: string;
    NON_RESIDENT: {
        ITN_INFO: {
            ID: number;
            ITN: number;
            PERCENTAGE_OWNERSHIP: number;
            DOB: string;
            FIRST_NAME: string;
            LAST_NAME: string;
        }[];
        IS_NON_RESIDENT: boolean;
        WITHHOLDING_PERCENTAGE: number;
    };
    OFFERS: {
        IS_NEW_LISTING_OFFER_ENABLED: boolean;
        IS_NEW_LISTING_OFFER_BLACKOUT_ENABLED: boolean;
    };
    OWNER: WithRequiredProperty<User, "OWNER_PROFILE">;
    PARKING: {
        DESCRIPTION: string;
        HAS_ADDITIONAL_FREE_SPOTS: string;
        HAS_ADDITIONAL_PAID_SPOTS: string;
        INSTRUCTIONS: string;
        IS_DEFAULT_DESCRIPTION: boolean;
        NUM_SPOTS_PROVIDED: string;
    };
    PARTNERS: never[];
    PHOTOS: Photo[];
    POLICIES: {
        ACCOUNT: Policy[];
        GENERAL: Policy[];
        GUEST_STAY: Policy[];
        HOUSE_RULES: Policy[];
        PROPERTY: Policy[];
        RESERVATION: Policy[];
    };
    /** Either the owner of the property or the PROPERTY_CONTACT if defined */
    PRIMARY_CONTACT: User;
    /** PROPERTY_CONTACT is either sent with info or sent as an empty object
     * The PROPERTY_CONTACT is the rental manager of the property
     * The values are pre-filled so that the rental manager form can use those values  */
    PROPERTY_CONTACT: {
        PROPERTY_MANAGER_PROFILE: {
            PERMISSIONS: Omit<PropertyPermission, "PROPERTY_ID">;
            PROPERTY_IDS: never[];
        };
        ID: number;
        FIRST_NAME: string;
        LAST_NAME: string;
        IS_COMPANY: boolean;
        COMPANY_NAME: string;
        THUMBNAIL: string;
        PHONE: string;
        EMAIL: string;
        CREATED_DATE: string;
        DATE_LAST_LOGIN: string;
        DATE_UPDATED: string;
        ADDRESS: {
            AREA: string;
            AREA_ID: number;
            CITY: string;
            COUNTRY: string;
            COUNTRY_CODE: string;
            COUNTRY_ID: number;
            DEVELOPMENT: string;
            DEVELOPMENT_ID: number;
            ID: number;
            LATITUDE: number;
            LONGITUDE: number;
            POSTAL: string;
            REGION: string;
            REGION_ID: number;
            RESORT: string;
            RESORT_ID: number;
            STREET_NAME: string;
            STREET_NUMBER: string;
            UNIT: string;
        };
        IS_SMS_VERIFIED: boolean;
        IS_EMAIL_VERIFIED: boolean;
        DATE_EMAIL_VERIFIED: string;
        DATE_SMS_VERIFIED: string;
        DATE_OF_BIRTH: string;
        IS_ACTIVE: boolean;
        IS_STAFF: boolean;
        IS_SUPERUSER: boolean;
        IS_DUE_DILIGENCE_REQUIRED: boolean;
    };
    RATES_SCHEDULE: ServerRateSchedule[];
    RATES_SETTINGS: {
        /** Every month, extend the users rate schedule up to their availability window, cannot be use when availability window is unrestricted */
        IS_AVAILABILITY_AUTOMATION_ENABLED: boolean;
        /** AKA Pricing insights/Smart Pricing data
         * If true then the property has the option to enable optimized pricing */
        HAS_RATE_INSIGHTS_DATA: boolean;
        /** Every month, optimize the users rate schedule using the smart pricing level set
         *  Each date range can have its own smart pricing level, otherwise uses the property-level smart pricing level */
        IS_OPTIMIZED_PRICING_ENABLED: boolean;
        NO_RATES_DATES: NoRatesDate[];
        PRICING_STRATEGY: {
            ID: PricingStrategyEnum;
            RATE_INSIGHTS_LEVEL_ID: RateInsightLevelIdEnum;
        };
        WEEKEND_PREMIUM: {
            ID: RatesSettingsWeekendPremiumId;
            DOLLAR_AMOUNT: number;
            PERCENTAGE_AMOUNT: number;
        };
        AVAILABILITY_WINDOW: {
            ID: RateAvailabilityIdEnum;
        };
        DATE_LAST_SAVED: string;
        RATE_GROUPS: {
            HIGH: RateGroup;
            LOW: RateGroup;
            PRIME: RateGroup;
            MID: RateGroup;
        };
        DISCOUNT_GROUP: {
            TEN_DAY: number;
            SEVEN_DAY: number;
            FIVE_DAY: number;
            ID: number;
        };
        ID: number;
    };
    RESERVATION_SETTINGS: {
        DEPOSIT_PERCENTAGE: number;
        BALANCE_DAYS_BEFORE_ARRIVAL: number;
        BOOKING_GATEWAY_MODE_ID: number;
    };
    RULES: {
        ID: number;
        ADVANCED_BOOKING: {
            NAME: string;
            ID: number;
        };
        CHECK_IN: string;
        CHECK_OUT: string;
        MAX_BOOKABLE_DAYS: number;
        MAX_GUESTS: number;
        MIN_AGE_TO_BOOK: number;
        QUIET_TIME: string;
    };
    SETUP_QUESTIONS: {
        NUM_PROPERTIES: number;
        PLATFORMS_LISTED: {
            ID: number;
            URL: string;
        }[];
        ID: number;
    };
    SIZE_CATEGORY: {
        NAME: string;
        ID: number;
    };
    SQUARE_FEET: string;
    STYLE: {
        NAME: string;
        ID: number;
    };
    SURCHARGES: {
        CLEANING: {
            AMOUNT: string;
            ID: number;
            IS_ENABLED: boolean;
            NAME: string;
        };
        PETS: {
            AMOUNT: string;
            ID: number;
            IS_ENABLED: boolean;
            NAME: string;
        };
    };
    SUBSCRIPTION: {
        COMMISSION_PERCENTAGE: number;
        CREDIT_CARD_PERCENTAGE: number;
        DESCRIPTION: string;
        DURATION: string;
        FEE: string;
        GST: string;
        GST_RATE: number;
        ID: number;
        NAME: string;
        NUMBER_OF_DAYS: number;
        RESORT_ID: number;
        SUBSCRIPTION_TIER_ID: PropertySubscriptionTierIdEnum;
    };
    SUITABILITIES: {
        LONG_TERM_RENTALS: {
            ID: number;
            DESCRIPTION: string;
            IS_SUITABLE: boolean;
            NAME: string;
        };
        PARTIES_EVENTS: {
            ID: number;
            DESCRIPTION: string;
            IS_SUITABLE: boolean;
            NAME: string;
        };
        PETS: {
            ID: number;
            DESCRIPTION: string;
            IS_SUITABLE: boolean;
            NAME: string;
        };
        SMOKING: {
            ID: number;
            DESCRIPTION: string;
            IS_SUITABLE: boolean;
            NAME: string;
        };
        TRAVEL_RESELLERS: {
            ID: number;
            DESCRIPTION: string;
            IS_SUITABLE: boolean;
            NAME: string;
        };
        WHEELCHAIR_ACCESSIBLE: {
            ID: number;
            DESCRIPTION: string;
            IS_SUITABLE: boolean;
            NAME: string;
        };
    };
    TAXES: {
        IS_MANDATORY: boolean;
        IS_PASS_THROUGH_TO_OWNER: boolean;
        NAME: string;
        ID: number;
        RATE: number;
        REGISTRATION_NUMBER: string;
        DESCRIPTION: string;
    }[];
    TAX_NUMBERS: {
        BC_SHORT_TERM_REGISTRY_NUMBER: string;
        BUSINESS_LICENCE_NUMBER: string;
        GST_NUMBER: string;
        PST_NUMBER: string;
    };
    THUMBNAIL_URL: string;
    URL: string;
    VIDEOS: {
        THREESIXTY: {
            DATA: string;
            ID: number;
        };
        YOUTUBE: {
            DATA: string;
            ID: number;
        }[];
        FEATURED: {
            DATA: string;
            ID: number;
        };
    };
    WALKTHROUGH: {
        PROPERTY_GUIDEBOOK: GuidebookWalkthrough;
    };
};
export declare const calendarEvent: {
    ARRIVAL: string;
    ARRIVAL_UTC: number;
    BOOKING_NET: string;
    DATE_CREATED: string;
    DEPARTURE: string;
    DEPARTURE_UTC: number;
    GUEST: {
        EMAIL: string;
        FIRST_NAME: string;
        LAST_NAME: string;
        MEMBER_SINCE: string;
        NAME: string;
        NUM_BOOKINGS: number;
        NUM_RECOMMENDATIONS: number;
        NUM_REVIEWS: number;
        PHONE: string;
        THUMBNAIL: string;
    };
    GUEST_REQUESTS: string;
    HAS_PETS: boolean;
    ID: number;
    IS_ALLURA_BOOKING: boolean;
    NOTES_OWNER: string;
    PAID_TO_DATE: string;
    PARTY_SIZE_ADULTS: number;
    PARTY_SIZE_KIDS: string;
    PROPERTY: {
        THUMBNAIL_URL: string;
    };
    REFERENCE: string;
    SOURCE: string;
    STATUS: string;
    TITLE: string;
    TYPE: EventTypeEnum;
};
export declare const sparseRate: {
    NIGHTS: number;
    ID: number;
    RATE: string;
};
export declare const sparseSeason: {
    START: string;
    NAME: string;
    ID: number;
    COMMENT: string;
    END: string;
    RATES: never[];
};
export declare const calendarDate: {
    IS_BOOKED: boolean;
    DATE: string;
    DATE_UTC: number;
    ID: number;
    TYPE: string;
    SEASON: {
        START: string;
        NAME: string;
        ID: number;
        COMMENT: string;
        END: string;
        RATES: never[];
    };
};
export declare const reservationDetails: {
    ARRIVAL_DATE: string;
    DEPARTURE_DATE: string;
    GUEST_NAME: string;
    GUEST_EMAIL: string;
    GUEST_PHONE: string;
    /** The guest's ID */
    ID: number;
    USER_TYPE_ID: UserRoleIDEnum;
    REFERENCE: string;
    BOOKING_ID: string;
    BOOKING_STATUS: string;
    CONFIRMED_DATE: string;
};
export declare const initialLastAndNextGuest: {
    HAS_LAST_GUEST: boolean;
    LAST_GUEST: {
        ARRIVAL_DATE: string;
        DEPARTURE_DATE: string;
        GUEST_NAME: string;
        GUEST_EMAIL: string;
        GUEST_PHONE: string;
        /** The guest's ID */
        ID: number;
        USER_TYPE_ID: UserRoleIDEnum;
        REFERENCE: string;
        BOOKING_ID: string;
        BOOKING_STATUS: string;
        CONFIRMED_DATE: string;
    };
    HAS_NEXT_GUEST: boolean;
    NEXT_GUEST: {
        ARRIVAL_DATE: string;
        DEPARTURE_DATE: string;
        GUEST_NAME: string;
        GUEST_EMAIL: string;
        GUEST_PHONE: string;
        /** The guest's ID */
        ID: number;
        USER_TYPE_ID: UserRoleIDEnum;
        REFERENCE: string;
        BOOKING_ID: string;
        BOOKING_STATUS: string;
        CONFIRMED_DATE: string;
    };
    PROPERTY_ID: string;
};
export declare const BANK_DEPOSITS: {
    TRANSFERRED: {
        BANK_ACCOUNT_HOLDER: string;
        BANK_ACCOUNT_NUMBER: string;
        EXPECTED_DEPOSIT_DATE: string;
        TRANSACTION_ID: number;
        BOOKING_ID: number;
        REFERENCE: string;
        TRANSFER_DATE: string;
        AMOUNT: number;
    }[];
    EXPECTED: {
        EXPECTED_PAYOUT: string;
        SUM_IN_TRANSIT: number;
    };
};
export declare const UNAVAILABLE_DATES: {
    CANNOT_ARRIVE: string[];
    CANNOT_DEPART: string[];
    UNAVAILABILITY_ARRIVAL: string[];
    UNAVAILABILITY_DEPARTURE: string[];
};
export declare const PHOTO: {
    ORIGINAL: string;
    CAPTION: string;
    SORT_ORDER: number;
    THUMB: string;
    FULL: string;
    ID: number;
};
export declare const PROPERTY_DEFAULT_CONTENT: {
    DEFAULT_CONTENT: string;
    OTHER_DEFAULTS: string[];
    ID: number;
};
export declare const EXTERNAL_EVENT: {
    SOURCE: string;
    NIGHTS: number;
    ARRIVAL: string;
    DEPARTURE: string;
    ID: number;
    SUMMARY: string;
};
export declare const PROPERTY_REVIEWS: {
    PROPERTY_ID: number;
    AVERAGE_SCORE: number;
    AVERAGE_SCORES: {
        AVERAGE_SCORE: number;
        TITLE: string;
    }[];
    NUM_REVIEWS: number;
    REVIEWS: {
        ID: number;
        IS_GUEST_RESPONSE_POSSIBLE: boolean;
        BOOKING_INFO: {
            RESORT: string;
            PROPERTY_IMAGE: string;
            NIGHTS: number;
            ARRIVAL: string;
            DEPARTURE: string;
            REFERENCE: string;
            CONFIRMED: string;
            ID: number;
            DEVELOPMENT: string;
        };
        REVIEW: string;
        STATUS: string;
        STATUS_ID: ReviewStatusId;
        REVIEW_DATE: string;
        GUEST_INFO: {
            MEMBER_SINCE: string;
            COUNTRY: string;
            NUM_BOOKINGS: number;
            FIRST_NAME: string;
            STATUS: string;
            NUM_HOST_RECOMMENDATIONS: number;
            LAST_NAME: string;
            ID: number;
            NUM_RECOMMENDS: number;
            CITY: string;
            NUM_REVIEWS: number;
            USER_TYPE_ID: number;
            THUMBNAIL: string;
        };
        RATINGS: {
            QUESTION: string;
            MAX_SCORE: number;
            ID: number;
            TITLE: string;
            SCORE: number;
        }[];
        RATINGS_AVERAGE: number;
        IS_PUBLISHED: boolean;
        WOULD_RECOMMEND: boolean;
        PUBLISHED_DATE: string;
        TITLE: string;
        RESPONSES: {
            RESPONSE: string;
            RESPONSE_DATE: string;
            USER_ROLE: string;
            TITLE: string;
        }[];
    }[];
};
export declare const RATE_SUGGESTION: {
    DATE: string;
    LOW: string;
    LOW_MID: string;
    MID: string;
    MID_HIGH: string;
    HIGH: string;
    ID: number;
};
export declare const RATE_SUGGESTIONS: {
    ID: number;
    RESORT: string;
    RESORT_ID: number;
    SIZE_CATEGORY: string;
    SIZE_CATEGORY_ID: number;
    RATES_SCHEDULE: {
        DATE: string;
        LOW: string;
        LOW_MID: string;
        MID: string;
        MID_HIGH: string;
        HIGH: string;
        ID: number;
    }[];
};
export declare const RATE_SCHEDULE_GENERATE_OPTIMIZE: {
    ID: string | number;
    RATES_SCHEDULE: ServerRateSchedule[];
};
export declare const RATE_SCHEDULE_GENERATE_INSIGHT: {
    ID: string | number;
    RATES_SCHEDULE: ServerRateSchedule[];
};
