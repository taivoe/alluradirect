import { GenerateRateMode, PropertyDefaultContentTypes, RateInsightLevelIdEnum } from './types';
import { InfiniteQueryPageDirections, NotificationEndpointFilterCategory, NotificationEndpointFilterStatus } from '../types';
import { BookingStatusId } from '../booking/types';
export declare const additionalContactEndpoint = "/RESTAUTH/property/emergencycontact/";
export declare const bookingsFilteredEndPoint = "/RESTAUTH/property/bookings/filtered/";
export declare const bookingsPaginatedEndPoint = "/RESTAUTH/property/bookings/paginated/";
export declare const calendarDatesEndpoint = "/RESTAUTH/property/calendardates/";
export declare const cancellationPoliciesEndpoint = "/RESTAUTH/property/cancellationpolicy/";
export declare const checkinEmailPreviewSendEndpoint = "/RESTAUTH/property/checkinemail/";
export declare const contentEndpoint = "/RESTAUTH/property/content/";
export declare const directVacationLogoEndpoint = "/RESTAUTH/property/directvacationslogo/";
export declare const directVacationSubdomainEndpoint = "/RESTAUTH/property/directvacationssubdomain/";
export declare const externalUrlsEndpoint = "/RESTAUTH/property/externalurls/";
export declare const formEndpoint = "/RESTAUTH/property/forminput/";
export declare const instructionsEndpoint = "/RESTAUTH/property/instructions/";
export declare const photoSortEndpoint = "/RESTAUTH/property/photo/sort/";
export declare const photosEndpoint = "/RESTAUTH/property/photo/";
export declare const propertyAmenityEndpoint = "/RESTAUTH/property/amenity/";
export declare const propertyBlockoffEndpoint = "/RESTAUTH/property/blockoff/";
export declare const propertyDefaultContentEndpoint = "/RESTAUTH/property/defaultcontent/";
export declare const propertyWalkthroughGuidebookEndpoint = "/RESTAUTH/property/walkthrough/propertyguidebook/";
export declare const propertyICalEndpoint = "/RESTAUTH/property/ical/";
export declare const propertyNonResidentEmail = "/RESTAUTH/property/nonresidentsubscription/";
export declare const propertyPoliciesEndpoint = "/RESTAUTH/property/policies/";
export declare const propertyRateGroupEndpoint = "/RESTAUTH/property/rategroup/";
export declare const propertyRatesScheduleGenerateEndpoint = "/RESTAUTH/property/rateschedule/generate/";
export declare const propertyTransactionsEndpoint = "/RESTAUTH/property/transactions/";
export declare const propertyVideosEndpoint = "/RESTAUTH/property/video/";
export declare const rateScheduleEndpoint = "/RESTAUTH/property/rateschedule/";
export declare const rentalAgreementSummaryEndpoint = "/RESTAUTH/property/rentalagreement/";
export declare const resendSubscriptionReceiptEndPoint = "/RESTAUTH/property/resendreceipt/";
export declare const reservationRequestEndpoint = "/RESTAUTH/property/reservationrequest/";
export declare const reservationSettings = "/RESTAUTH/property/reservationsettings/";
export declare const subformEndpoint = "/RESTAUTH/property/subform/";
export declare const generateBookingsFilteredEndpoint: ({ propertyId, startDate, endDate, status, sort, source, }: {
    propertyId: number;
    startDate: string;
    endDate: string;
    status: any;
    sort: any;
    source: any;
}) => string;
export declare const generatePropertyGuidebookEndpoint: (propertyId: number) => string;
export declare const generatePropertyGuidebookPDFEndpoint: (propertyId: number) => string;
export declare const generateLegacyCheckInHTML: (propertyId: number) => string;
export declare const generateBookingReservationEndpoint: (bookingId: number, includeTimeline?: boolean) => string;
/** Extend or Replace Rate Schedule using rate group data */
export declare const generateRateScheduleRateGroup: ({ propertyId, num_months, start_date, is_replace, }: {
    propertyId: number;
    num_months: number;
    start_date: string;
    is_replace?: boolean;
}) => string;
/** Extend or Replace Rate Schedule using pricing insight data */
export declare const generateRateScheduleInsight: ({ propertyId, num_months, start_date, rate_insights_level_id, is_preview, is_replace, }: {
    propertyId: number;
    num_months: number;
    start_date: string;
    rate_insights_level_id: RateInsightLevelIdEnum;
    is_preview?: boolean;
    is_replace?: boolean;
}) => string;
/** generate a property rate schedule with AirDNA daily insights, using existing date ranges
 * PUT
 */
export declare const rateScheduleOptimizeEndpoint = "/RESTAUTH/property/rateschedule/generate/optimize/";
export declare const generatePropertyCodesEndpoint: (propertyId: number) => string;
export declare const generatePropertyRatesScheduleGenerateEndpoint: ({ propertyId, mode, }: {
    propertyId: number;
    mode: GenerateRateMode;
}) => string;
export declare const generatePhotosEndPoint: (propertyId: number) => string;
export declare const generateFormInputEndpoint: (propertyId: number) => string;
export declare const generateBookingsPaginatedEndPoint: ({ amount, direction, page, status_id, propertyId, }: {
    amount: number;
    direction: "past" | "future" | "all";
    propertyId: number;
    /** This value must always be greater than 0 */
    page: number;
    status_id?: BookingStatusId | undefined;
}) => string;
export declare const generateExternalEventsEndPoint: (propertyId: number) => string;
export declare const generateResyncICalEndPoint: (propertyId: number) => string;
export declare const generatePropertyEndPoint: (propertyId: number) => string;
export declare const generatePropertyEndPointQuery: (propertyId: number) => string;
export declare const generatePropertyNotificationsEndPoint: ({ amountPerPage, status, category, propertyId, page, }: {
    amountPerPage: number;
    status: NotificationEndpointFilterStatus;
    category: NotificationEndpointFilterCategory;
    propertyId: number;
    page: number;
}) => string;
export declare const propertyDismissNotificationsEndpoint = "/RESTAUTH/property/notifications/dismiss/";
export declare const generatePropertyDismissNotificationEndpoint: (propertyId: number, notificationIds: number[] | "all") => string;
export declare const generateReviewsEndPoint: ({ propertyId, page, amountPerPage, pageDirection, }: {
    propertyId: number;
    page: number;
    amountPerPage: number;
    pageDirection: InfiniteQueryPageDirections;
}) => string;
export declare const generateActivationEndPoint: (propertyId: number) => string;
export declare const generateUnavailabilityEndpoint: ({ bookingId, propertyId, }: {
    bookingId?: number | null;
    propertyId: number;
}) => string;
export declare const generateLastAndNextGuestEndpoint: (propertyId: number) => string;
export declare const generateBankDepositsEndPoint: (propertyId: number) => string;
export declare const generatePropertyDefaultContentEndpoint: (propertyId: number, contentType: PropertyDefaultContentTypes) => string;
export declare const generateExternalUrlsEndpoint: (propertyId: number) => string;
export declare const generateCheckInEmailPreviewEndpoint: ({ propertyId }: {
    propertyId: number;
}) => string;
export declare const generateRentalAgreementSummaryEndpoint: (propertyId: number) => string;
export declare const generateCalendarEventsEndpoint: ({ propertyId, startDate, endDate, }: {
    propertyId: number;
    startDate: string;
    endDate: string;
}) => string;
export declare const generateCalendarDatesEndpoint: ({ propertyId, startDate, endDate, }: {
    propertyId: number;
    startDate: string;
    endDate: string;
}) => string;
export declare const generateReservationRequest: (propertyId: number) => string;
export declare const generateRateSuggestionEndpoint: ({ propertyId }: {
    propertyId: number;
}) => string;
export declare const generatePropertyBlockoffsEndpoint: (propertyId: number) => string;
