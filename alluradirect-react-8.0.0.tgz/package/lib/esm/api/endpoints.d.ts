import { LocationURLParamsEnum } from './types';
import { UserRoleIDEnum } from './user/types';
export declare const defaultLocationURLParams: any[];
export declare const generateOwnerLocationEndPoint: (requirements?: LocationURLParamsEnum[]) => string;
export declare const generateGuestLocationEndPoint: (userId: number, requirements?: LocationURLParamsEnum[]) => string;
export declare const errorsEndPoint = "/RESTAUTH/error/";
export declare const generateCancellationPolicyEndpoint: ({ policy_id, is_credit_only_refund, is_refund_rebooked_dates, is_special_circumstance, special_circumstance_id, special_circumstance_description, admin_penalty, admin_penalty_unit, }: {
    policy_id: any;
    is_credit_only_refund: any;
    is_refund_rebooked_dates: any;
    is_special_circumstance: any;
    special_circumstance_id: any;
    special_circumstance_description: string;
    admin_penalty: any;
    admin_penalty_unit: any;
}) => string;
export declare const generateTermsOfServiceAgreementEndpoint: (userTypeId: UserRoleIDEnum) => string;
