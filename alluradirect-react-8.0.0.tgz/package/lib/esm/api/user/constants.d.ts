import { UserRoleIDEnum } from './types';
export declare const GUEST_PROFILE: {
    MEMBER_SINCE: string;
    PERMISSIONS: {
        SHOW_NUM_REVIEWS: boolean;
        SHOW_MEMBER_SINCE: boolean;
        SHOW_NUM_RECOMMENDS: boolean;
    };
    NUM_BOOKINGS: number;
    NUM_RECOMMENDATIONS: number;
    NUM_REVIEWS: number;
};
export declare const OWNER_PROFILE: {
    PROPERTY_IDS: number[];
    MEMBER_SINCE: string;
};
export interface PropertyPermission {
    PROPERTY_ID: number;
    NOTIFY_CHECKIN_REMINDER: false;
    NOTIFY_RESORT_SPECIFIC: false;
    NOTIFY_GENERAL_INQUIRIES: false;
    NOTIFY_ALL_OWNERS: false;
    NOTIFY_RESERVATION_REQUESTS: false;
    NOTIFY_RENEWALS: false;
    NOTIFY_RESERVATIONS_CANCELLED: false;
    NOTIFY_RESERVATIONS_ADDED: false;
}
export declare const PROPERTY_MANAGER_PROFILE: {
    PERMISSIONS: PropertyPermission[];
    PROPERTY_IDS: number[];
};
export declare const COHOST_PROFILE: {
    PERMISSIONS: PropertyPermission[];
    PROPERTY_IDS: number[];
};
export declare const USER: {
    ID: number;
    FIRST_NAME: string;
    LAST_NAME: string;
    IS_COMPANY: boolean;
    COMPANY_NAME: string;
    THUMBNAIL: string;
    PHONE: string;
    EMAIL: string;
    CREATED_DATE: string;
    DATE_LAST_LOGIN: string;
    DATE_UPDATED: string;
    ADDRESS: {
        AREA: string;
        AREA_ID: number;
        CITY: string;
        COUNTRY: string;
        COUNTRY_CODE: string;
        COUNTRY_ID: number;
        DEVELOPMENT: string;
        DEVELOPMENT_ID: number;
        ID: number;
        LATITUDE: number;
        LONGITUDE: number;
        POSTAL: string;
        REGION: string;
        REGION_ID: number;
        RESORT: string;
        RESORT_ID: number;
        STREET_NAME: string;
        STREET_NUMBER: string;
        UNIT: string;
    };
    IS_SMS_VERIFIED: boolean;
    IS_EMAIL_VERIFIED: boolean;
    DATE_EMAIL_VERIFIED: string;
    DATE_SMS_VERIFIED: string;
    DATE_OF_BIRTH: string;
    /** Django-compatibility fields */
    IS_ACTIVE: boolean;
    IS_STAFF: boolean;
    IS_SUPERUSER: boolean;
    IS_DUE_DILIGENCE_REQUIRED: boolean;
};
/** Inquiry message OR Booking message */
export declare const MESSAGE: {
    MESSAGE: string;
    SUBJECT: string;
    TO_EMAILS: string;
    DATE_SENT: string;
    FROM_EMAIL: string;
    RECIPIENT: string;
    THUMBNAIL: string;
    TIME_SENT: string;
    ID: number;
    RECIPIENT_ID: number;
    IS_READ: boolean;
    READ_DATE: string;
    READ_TIME: string;
    NUM_UNREAD: number;
    ARRIVAL_DATE: string;
    DEPARTURE_DATE: string;
    CREATED_DATE: string;
    NUM_BEDS: number;
    NUM_GUESTS: number;
    IS_INQUIRY: boolean;
};
/** Only appears on Booking messages */
export declare const MESSAGE_BOOKING: {
    ID: number;
    ARRIVAL_DATE: string;
    DEPARTURE_DATE: string;
    CREATED_DATE: string;
    REFERENCE: string;
};
export declare const MESSAGE_PROPERTY: {
    ID: number;
    THUMBNAIL: string;
    NAME: string;
    SIZE_CATEGORY: string;
};
export declare const MESSAGE_CONTACT: {
    ID: number;
    THUMBNAIL: string;
    NAME: string;
    USER_TYPE_ID: UserRoleIDEnum;
    EMAIL: string;
};
export declare const USER_LOGIN: {
    IS_AUTHENTICATED_GUEST: boolean;
    IS_AUTHENTICATED_OWNER: boolean;
    GUEST_ID: number;
    OWNER_ID: number;
    HAS_GUEST_AND_OWNER_ACCOUNTS: boolean;
    IS_PASSWORDS_SYNCED: boolean;
    OLD_PASSWORD_USER_ROLE_ID: UserRoleIDEnum;
};
export declare const GUEST_OWNER_LOGIN: {
    USER_ROLE_ID: UserRoleIDEnum.owner;
    JSESSIONID: string;
    ID: number;
};
export declare const USER_MESSAGE_SUBJECT: {
    ID: number;
    CONTACT: {
        ID: number;
        THUMBNAIL: string;
        NAME: string;
        USER_TYPE_ID: UserRoleIDEnum;
        EMAIL: string;
    };
    BOOKING: {
        ID: number;
        ARRIVAL_DATE: string;
        DEPARTURE_DATE: string;
        CREATED_DATE: string;
        REFERENCE: string;
    };
    PROPERTY: {
        ID: number;
        THUMBNAIL: string;
        NAME: string;
        SIZE_CATEGORY: string;
    };
    MESSAGE: {
        MESSAGE: string;
        SUBJECT: string;
        TO_EMAILS: string;
        DATE_SENT: string;
        FROM_EMAIL: string;
        RECIPIENT: string;
        THUMBNAIL: string;
        TIME_SENT: string;
        ID: number;
        RECIPIENT_ID: number;
        IS_READ: boolean;
        READ_DATE: string;
        READ_TIME: string;
        NUM_UNREAD: number;
        ARRIVAL_DATE: string;
        DEPARTURE_DATE: string;
        CREATED_DATE: string;
        NUM_BEDS: number;
        NUM_GUESTS: number;
        IS_INQUIRY: boolean;
    };
};
export declare const USER_MESSAGE_OVERVIEW: {
    ID: number;
    MESSAGE: {
        MESSAGE: string;
        MESSAGE_HTML: string;
        SUBJECT: string;
        TO_EMAILS: string;
        DATE_SENT: string;
        FROM_EMAIL: string;
        RECIPIENT: string;
        THUMBNAIL: string;
        TIME_SENT: string;
        ID: number;
        RECIPIENT_ID: number;
        IS_READ: boolean;
        READ_DATE: string;
        READ_TIME: string;
        NUM_UNREAD: number;
    };
    PROPERTY: {
        ID: number;
        THUMBNAIL: string;
        NAME: string;
        SIZE_CATEGORY: string;
    };
    CONTACT: {
        ID: number;
        THUMBNAIL: string;
        NAME: string;
        USER_TYPE_ID: UserRoleIDEnum;
        EMAIL: string;
        DETAILS: {
            NEXT_RESERVATION_DATE: string;
            MEMBER_SINCE: string;
            HAS_NEXT_RESERVATION: boolean;
            HAS_MEMBER_SINCE: boolean;
            DETAILS_NUMBER_OF_RESERVATIONS: number;
            HAS_NUMBER_OF_RESERVATIONS: boolean;
            HAS_LAST_RESERVATION: boolean;
            LAST_RESERVATION_DATE: string;
        };
    };
};
export declare const MESSAGE_THREAD: {
    MESSAGE: {
        MESSAGE: string;
        IS_READ: boolean;
        SUBJECT: string;
        TO_EMAILS: string;
        FROM_EMAIL: string;
        THUMBNAIL: string;
        SENT_DATE: string;
        SENT_TIME: string;
        BOOKING_ID: number;
        ID: number;
        READ_DATE: string;
        READ_TIME: string;
        INQUIRY_ID: number;
        SENDER_USER_ID: number;
        SENDER_USER_TYPE_ID: UserRoleIDEnum;
        RECEIVER_USER_ID: number;
        RECEIVER_USER_TYPE_ID: UserRoleIDEnum;
        ARRIVAL_DATE: string;
        DEPARTURE_DATE: string;
        IS_INQUIRY: boolean;
        NUM_BEDS: number;
        NUM_GUESTS: number;
    };
    PROPERTY: {
        ID: number;
        THUMBNAIL: string;
        NAME: string;
        SIZE_CATEGORY: string;
    };
    BOOKING: {
        ID: number;
        ARRIVAL_DATE: string;
        DEPARTURE_DATE: string;
        CREATED_DATE: string;
        REFERENCE: string;
    };
};
export declare const MESSAGE_UNREAD_COUNT: {
    USER_MESSAGE_COUNT: number;
};
