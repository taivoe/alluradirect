import { InfiniteQueryPageDirections } from '../types';
import { UserRoleIDEnum } from './types';
/** This is the standard user endpoint for Lucee now. It will also return
 * the auth state of the current client's session in that it will return the user object
 * or an empty object if the user is not logged in.
 */
export declare const userPutEndpoint = "/RESTAUTH/user/";
export declare const userEndpoint = "/RESTAUTH/user/checklogin/";
export declare const userCredentialsEndpoint = "/RESTAUTH/user/credentials/";
export declare const userLoginEndpoint = "/RESTAUTH/user/login/";
export declare const userPasswordSyncEndpoint = "/RESTAUTH/user/accountsync/";
export declare const userProfilePhotoEndpoint = "/RESTAUTH/user/profilephoto/";
export declare const userMessageEndpoint = "/RESTAUTH/user/message/";
export declare const twilioSendCodeEndpoint = "/RESTAUTH/user/verification/";
export declare const twilioSendCodeEndpointCheck = "/RESTAUTH/user/verification/check/";
/** POST: accepts an email */
export declare const userPasswordResetEndpoint = "/RESTAUTH/user/passwordreset/";
export declare const generateUserProfilePhotoEndpoint: (userId: number, userTypeId: UserRoleIDEnum) => string;
/** Get number of unread messages */
export declare const generateUserMessageUnreadEndpoint: (id: number, userTypeId: UserRoleIDEnum) => string;
/** Mark all messages in the contact thread as read for the current user */
export declare const userMessageMarkAsReadEndpoint = "/RESTAUTH/user/message/thread/markasread/";
/** Get detailed information about a specific user
 * Send a propertyId when contactUserTypeId is not guest
 */
export type UserMessageContactArgs = {
    contactUserTypeId: UserRoleIDEnum;
    contactUserId: number;
    propertyId?: number;
};
export declare const generateUserMessageContactEndpoint: ({ contactUserTypeId, contactUserId, propertyId, }: UserMessageContactArgs) => string;
/** Gets UserMessageSubject information from a reservation. One of bookingId or messageId is required */
export declare const generateUserMessageSubjectEndpoint: ({ id, userTypeId, bookingId, messageId, }: {
    id: number;
    userTypeId: UserRoleIDEnum;
    bookingId?: number;
    messageId?: number;
}) => string;
export declare const generateUserMessageSubjectsEndpoint: ({ id, userTypeId, page, page_direction, amountPerPage, subjectType, filterUserId, filterUserTypeId, searchFilter, }: {
    id: number;
    userTypeId: UserRoleIDEnum;
    page: number;
    page_direction: InfiniteQueryPageDirections;
    amountPerPage: number;
    subjectType: "past_bookings" | "future_bookings" | "inquiries";
    searchFilter?: string;
    filterUserId?: number;
    filterUserTypeId?: UserRoleIDEnum;
}) => string;
export declare const generateUserMessageOverviewEndpoint: ({ id, userTypeId, page, amountPerPage, propertyId, }: {
    id: number;
    userTypeId: UserRoleIDEnum;
    page: number;
    amountPerPage: number;
    propertyId?: number;
}) => string;
export declare const generateUserMessageThreadEndpoint: ({ id, userTypeId, page, amountPerPage, contactUserId, contactUserTypeId, }: {
    id: number;
    userTypeId: UserRoleIDEnum;
    page: number;
    amountPerPage: number;
    contactUserId: number;
    contactUserTypeId: UserRoleIDEnum;
}) => string;
export declare const userExpoTokenEndpoint = "/RESTAUTH/user/expopushtoken/";
export declare const generateUserCheckEmailTaken: (email: string) => string;
export declare const generateUserCheckEmailExists: (email: string) => string;
