import { JoinStatusIDEnum, PropertySubscriptionTierIdEnum, PropertySurcharge } from '../property/types';
import { MobileWalkThroughNameEnum, RenewalFeesItem, RenewalTypeItem } from './types';
import { SubscriptionTier } from '../ownerFormInputs/types';
import { User } from '../user/types';
import { WithRequiredProperty } from '../types';
export declare const OWNER_PROPERTY: {
    ACTIVE_SINCE: string;
    ADDRESS: {
        AREA: string;
        AREA_ID: number;
        CITY: string;
        COUNTRY: string;
        COUNTRY_CODE: string;
        COUNTRY_ID: number;
        DEVELOPMENT: string;
        DEVELOPMENT_ID: number;
        ID: number;
        LATITUDE: number;
        LONGITUDE: number;
        POSTAL: string;
        REGION: string;
        REGION_ID: number;
        RESORT: string;
        RESORT_ID: number;
        STREET_NAME: string;
        STREET_NUMBER: string;
        UNIT: string;
    };
    CAN_RENEW: boolean;
    COMPLETION_PERCENTAGE: number;
    DAYS_TO_EXPIRY: number;
    DAMAGE_DEPOSIT_MODE_ID: number;
    EXPIRY_DATE: string;
    HAS_COMPLETED_ONBOARDING: boolean;
    HAS_SUBSCRIPTION_RECEIPT: boolean;
    ID: number;
    IS_ENABLED: boolean;
    JOIN_STATUS: string;
    JOIN_STATUS_ID: JoinStatusIDEnum;
    NAME: string;
    NUM_BATHROOMS: number;
    NUM_BEDROOMS: number;
    SIZE_CATEGORY: string;
    THUMBNAIL: string;
    SUBSCRIPTION_TIER: {
        NAME: string;
        ID: PropertySubscriptionTierIdEnum;
        DESCRIPTION: string;
    };
    LISTING_QUALITY: {
        MESSAGE: string;
        STAR_RATING: number;
    };
    SURCHARGES: PropertySurcharge[];
    RESERVATION_SETTINGS: {
        DEPOSIT_PERCENTAGE: number;
        BALANCE_DAYS_BEFORE_ARRIVAL: number;
        BOOKING_GATEWAY_MODE_ID: number;
    };
};
export declare const OWNER_MEMBERSHIP_RENEWAL_INFO: {
    IS_ACTIVATION: boolean;
    IS_ALLURA_ADMIN: boolean;
    RENEWAL_TYPE: string;
    OWNER: WithRequiredProperty<User, "OWNER_PROFILE">;
    OWNER_ID: string;
    PROPERTY_ID: string;
    PROPERTY_NAME: string;
    RENEWAL_DURATION: string;
    RENEWAL_EXPIRY_DATE: string;
    RENEWAL_FEES: RenewalFeesItem;
    RENEWAL_PAYMENT_OPTIONS: RenewalTypeItem[];
    STRIPE_PUBLISHABLE_KEY: string;
    STRIPE_CUSTOMER: {};
    SUBSCRIPTION_TIERS: SubscriptionTier[];
    RENEWAL_PAYMENT_TYPE: string;
};
export declare const FINANCES_SUMMARY: {
    PROPERTY_ID: number;
    PROPERTY_ADDRESS: string;
    PROPERTY_THUMBNAIL_URL: string;
    UPCOMING: {
        NON_RESIDENT_WITHHELD: string;
        TAXES: {
            OWNER_REMIT_AMOUNT: string;
            NAME: string;
            ID: number;
            AMOUNT: string;
        }[];
        CREDIT_CARD_FEES: string;
        COMMISSION: string;
        RESERVATIONS_COUNT: number;
        SURCHARGES_AMOUNT: string;
        RESERVATIONS_AMOUNT: string;
    };
    TOTAL: {
        NON_RESIDENT_WITHHELD: string;
        TAXES: {
            OWNER_REMIT_AMOUNT: string;
            NAME: string;
            ID: number;
            AMOUNT: string;
        }[];
        CREDIT_CARD_FEES: string;
        COMMISSION: string;
        RESERVATIONS_COUNT: number;
        SURCHARGES_AMOUNT: string;
        RESERVATIONS_AMOUNT: string;
    };
    PAID: {
        NON_RESIDENT_WITHHELD: string;
        TAXES: {
            OWNER_REMIT_AMOUNT: string;
            NAME: string;
            ID: number;
            AMOUNT: string;
        }[];
        CREDIT_CARD_FEES: string;
        COMMISSION: string;
        RESERVATIONS_COUNT: number;
        SURCHARGES_AMOUNT: string;
        RESERVATIONS_AMOUNT: string;
    };
};
export declare const OWNER_FINANCES_SUMMARY: {
    OWNER_ID: number;
    PROPERTIES: {
        PROPERTY_ID: number;
        PROPERTY_ADDRESS: string;
        PROPERTY_THUMBNAIL_URL: string;
        UPCOMING: {
            NON_RESIDENT_WITHHELD: string;
            TAXES: {
                OWNER_REMIT_AMOUNT: string;
                NAME: string;
                ID: number;
                AMOUNT: string;
            }[];
            CREDIT_CARD_FEES: string;
            COMMISSION: string;
            RESERVATIONS_COUNT: number;
            SURCHARGES_AMOUNT: string;
            RESERVATIONS_AMOUNT: string;
        };
        TOTAL: {
            NON_RESIDENT_WITHHELD: string;
            TAXES: {
                OWNER_REMIT_AMOUNT: string;
                NAME: string;
                ID: number;
                AMOUNT: string;
            }[];
            CREDIT_CARD_FEES: string;
            COMMISSION: string;
            RESERVATIONS_COUNT: number;
            SURCHARGES_AMOUNT: string;
            RESERVATIONS_AMOUNT: string;
        };
        PAID: {
            NON_RESIDENT_WITHHELD: string;
            TAXES: {
                OWNER_REMIT_AMOUNT: string;
                NAME: string;
                ID: number;
                AMOUNT: string;
            }[];
            CREDIT_CARD_FEES: string;
            COMMISSION: string;
            RESERVATIONS_COUNT: number;
            SURCHARGES_AMOUNT: string;
            RESERVATIONS_AMOUNT: string;
        };
    }[];
    GROSS_VALUES: {
        UPCOMING: string;
        TOTAL: string;
        PAID: string;
    };
};
export declare const OWNER_FINANCES_TRANSACTION: {
    BOOKING_DATES: string;
    BOOKING_ID: number;
    BOOKING_REFERENCE: string;
    DETAIL_ID: number;
    GUEST_NAME: string;
    PROPERTY_ID: number;
    TRANSFER_AMOUNT: string;
    TRANSFER_DATE: string;
    TRANSFER_DETAILS: string;
};
export declare const OWNER_FINANCES_TRANSACTIONS: {
    OWNER_ID: number;
    TRANSACTIONS: {
        BOOKING_DATES: string;
        BOOKING_ID: number;
        BOOKING_REFERENCE: string;
        DETAIL_ID: number;
        GUEST_NAME: string;
        PROPERTY_ID: number;
        TRANSFER_AMOUNT: string;
        TRANSFER_DATE: string;
        TRANSFER_DETAILS: string;
    }[];
};
export declare const OWNER_FINANCES_RESERVATIONS_COLUMN: {
    NAME: string;
    KEY: string;
};
export declare const OWNER_FINANCES_RESERVATIONS_TRANSACTION: {
    arrival_date: string;
    bank_deposit: string;
    booking_id: number;
    booking_ref: string;
    booking_status: string;
    commission_gst: string;
    commission_net: string;
    credit_card_fee: string;
    damage_deposit: string;
    gst: string;
    guest_name: string;
    mrdt: string;
    non_resident_withheld: string;
    number_of_nights: number;
    payment_category: string;
    property_id: number;
    property_manager_service_fee: string;
    property_manager_service_fee_tax: string;
    pst: string;
    qst: string;
    service_fee_total: string;
    surcharge_gst: string;
    surcharge_mrdt: string;
    surcharge_net: string;
    surcharge_pst: string;
    surcharge_qst: string;
    transaction_amount: string;
    transaction_date: string;
    transaction_id: number;
    transfer_date: string;
};
export declare const OWNER_FINANCES_RESERVATIONS: {
    PROPERTY_ID: string;
    OWNER_ID: number;
    COLUMNS: {
        NAME: string;
        KEY: string;
    }[];
    TRANSACTIONS: {
        arrival_date: string;
        bank_deposit: string;
        booking_id: number;
        booking_ref: string;
        booking_status: string;
        commission_gst: string;
        commission_net: string;
        credit_card_fee: string;
        damage_deposit: string;
        gst: string;
        guest_name: string;
        mrdt: string;
        non_resident_withheld: string;
        number_of_nights: number;
        payment_category: string;
        property_id: number;
        property_manager_service_fee: string;
        property_manager_service_fee_tax: string;
        pst: string;
        qst: string;
        service_fee_total: string;
        surcharge_gst: string;
        surcharge_mrdt: string;
        surcharge_net: string;
        surcharge_pst: string;
        surcharge_qst: string;
        transaction_amount: string;
        transaction_date: string;
        transaction_id: number;
        transfer_date: string;
    }[];
};
export declare const OWNER_MINIMAL_PROPERTY: {
    ID: number;
    TITLE: string;
    THUMBNAIL: string;
};
export declare const OWNER_EXTERNAL_EVENTS: {
    PROPERTIES: {
        PROPERTY: {
            ID: number;
            TITLE: string;
            THUMBNAIL: string;
        };
        EXTERNAL_BOOKINGS: {
            SOURCE: string;
            NIGHTS: number;
            ARRIVAL: string;
            DEPARTURE: string;
            ID: number;
            SUMMARY: string;
        }[];
    }[];
    OWNER_ID: string;
};
export declare const OWNER_BLOCKED_DATE: {
    ARRIVAL: string;
    DEPARTURE: string;
    BOOKING_ID: number;
    TITLE: string;
    DESCRIPTION: string;
};
export declare const OWNER_MIN_NIGHT_GAP: {
    PROPERTY_ID: number;
    START: string;
    MIN_NIGHTS: number;
    AVAILABLE_NIGHTS: number;
    END: string;
};
export declare const OWNER_UNBOOKABLE_DATES: {
    OWNER_ID: string;
    PROPERTIES: {
        PROPERTY: {
            ID: number;
            TITLE: string;
            THUMBNAIL: string;
        };
        BLOCKED_DATES: {
            ARRIVAL: string;
            DEPARTURE: string;
            BOOKING_ID: number;
            TITLE: string;
            DESCRIPTION: string;
        }[];
        MIN_NIGHT_GAPS: {
            PROPERTY_ID: number;
            START: string;
            MIN_NIGHTS: number;
            AVAILABLE_NIGHTS: number;
            END: string;
        }[];
        LAST_AVAILABLE_DATE: string;
    }[];
};
export declare const OWNER_MOBILE_WALKTHROUGH: {
    WALKTHROUGH_MOBILE: {
        COMPLETED_STEPS: MobileWalkThroughNameEnum[];
        COMPLETION_PERCENTAGE: number;
        NUM_STEPS: number;
        STEPS: MobileWalkThroughNameEnum[];
    };
};
