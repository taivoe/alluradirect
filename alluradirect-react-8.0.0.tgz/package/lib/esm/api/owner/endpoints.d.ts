import { NotificationEndpointFilterCategory, NotificationEndpointFilterStatus } from '../types';
import { BookingStatusId } from '../booking/types';
import { OwnerFinancesSort } from './types';
export declare const ownerContactAlluraEndpoint = "/RESTAUTH/owner/contact/allura/";
export declare const ownerCredentialsEndpoint = "/RESTAUTH/owner/credentials/";
export declare const ownerLoginEndpoint = "/RESTAUTH/owner/login/";
export declare const ownerLogoutEndpoint = "/RESTAUTH/owner/logout/";
export declare const ownerMobileWalkthroughEndpoint = "/RESTAUTH/owner/walkthrough/mobile/complete/";
export declare const ownerPutEndpoint = "/RESTAUTH/owner/";
export declare const ownerReferalEndpoint = "/RESTAUTH/owner/referral/";
export declare const requestPropertyDeactivationEndPoint = "/RESTAUTH/owner/property/requestdeactivation/";
export declare const ownerPropertyLoginEndpoint = "/RESTAUTH/owner/property/login/";
export declare const ownerPropertyCreateEndpoint = "/RESTAUTH/owner/property/create/";
export declare const generateOwnerGuestsEndpoint: (ownerId: number) => string;
export declare const generateOwnerMobileWalkthroughEndpoint: (id: number) => string;
export declare const generatePriorityBookingsEndpoint: (ownerId: number) => string;
export declare const membershipRenewalInfo: (propertyId: number, ownerId: number) => string;
export declare const renewalTransaction: (propertyId: number, ownerId: number) => string;
export declare const generateOwnerNotificationsEndPoint: ({ amountPerPage, page, category, ownerId, status, propertyId, }: {
    amountPerPage: number;
    page: number;
    ownerId: number;
    category: NotificationEndpointFilterCategory;
    status: NotificationEndpointFilterStatus;
    propertyId?: number;
}) => string;
export declare const ownerDismissNotificationsEndpoint = "/RESTAUTH/owner/notifications/dismiss/";
export declare const generateOwnerPropertiesEndPoint: (ownerId: number) => string;
export declare const generateOwnerBookingsEndpoint: ({ page, ownerId, status_id, amountPerPage, direction, propertyIds, }: {
    page: number;
    ownerId: number;
    direction?: "future" | "past" | "all";
    amountPerPage?: number;
    propertyIds: number[];
    status_id?: BookingStatusId | undefined;
}) => string;
export interface FinancesArgs {
    ownerId: number;
    year: number;
    fromMonth: number;
    toMonth: number;
    sortOrder: OwnerFinancesSort;
    propertyId?: number;
}
export declare const generateOwnerFinancesSummaryEndpoint: ({ ownerId, year, fromMonth, toMonth, sortOrder, propertyId, }: FinancesArgs) => string;
export interface TransactionsArgs extends FinancesArgs {
    filter: 'completed' | 'upcoming';
}
export declare const generateOwnerFinancesTransactionsEndpoint: ({ ownerId, year, fromMonth, toMonth, sortOrder, propertyId, filter, }: TransactionsArgs) => string;
export declare const generateOwnerFinancesReservationsEndpoint: ({ ownerId, year, fromMonth, toMonth, sortOrder, propertyId, }: FinancesArgs) => string;
export declare const generateOwnerFinancesReservationsCsvEndpoint: ({ ownerId, year, fromMonth, toMonth, sortOrder, propertyId, }: FinancesArgs) => string;
export declare const generateOwnerFinancesTransactionsCsvEndpoint: ({ ownerId, year, fromMonth, toMonth, sortOrder, propertyId, }: FinancesArgs) => string;
interface OwnerUnbookableProps {
    ownerId: number;
    propertyId?: number;
    numMonths: number;
}
/** Despite what the name might suggest, this endpoint returns all external events from synced iCals */
export declare const generateOwnerExternalBookingsEndpoint: ({ ownerId, propertyId, numMonths, }: OwnerUnbookableProps) => string;
export declare const generateOwnerUnbookableDates: ({ ownerId, numMonths, propertyId }: OwnerUnbookableProps) => string;
export {};
