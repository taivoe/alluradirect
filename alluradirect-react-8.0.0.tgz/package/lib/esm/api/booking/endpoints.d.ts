export declare const bookingEndpoint = "/RESTAUTH/booking/";
export declare const bookingQuoteEndpoint = "/RESTAUTH/booking/quote/";
export declare const bookingNotesEndpoint = "/RESTAUTH/booking/notes/";
export declare const reviewPublishEndPoint = "/RESTAUTH/booking/review/publish/";
export declare const reviewDisputeEndpoint = "/RESTAUTH/booking/review/dispute/";
export declare const reviewResponseEndpoint = "/RESTAUTH/booking/review/response/";
export declare const bookingEmailEndpoint = "/RESTAUTH/booking/email/";
export declare const bookingcustomMessageEndpoint = "/RESTAUTH/booking/custommessage/";
export declare const generateBookingEmailEndpoint: (reservationId: number, emailTemplate: "details" | "checkin", cc_emails?: string) => string;
export declare const generateBookingCancellationDetailEndpoint: (bookingId: string) => string;
export declare const generateQuoteEndPoint: () => string;
export declare const generateBookingContactTracingEndpoint: () => string;
export declare const generateBookingNotesEndpoint: (notesParamString: any) => string;
export declare const generateBookingPropertyGuidebook: (ownerId: number) => string;
export declare const generateBookingPropertyGuidebookBinaryEndpoint: ({ bookingId }: {
    bookingId: number;
}) => string;
/** @param guestEmail the email of the guest to check if a guest account with that email exists */
export declare const generateBookingGuestExists: (guestEmail: string) => string;
