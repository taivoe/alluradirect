import { BookingStatusId, MessageRecipientIdEnum, RatingItem, RatingRange, ReviewResponse, ReviewStatusId } from './types';
import { BookingGateWayModeIdEnum, EmergencyContact, JoinStatusIDEnum } from '../property/types';
import { DamageDepositModeId, WithRequiredProperty } from '../types';
import { User } from '../user/types';
export declare const bookingStatus: {
    DATE: string;
    IS_DONE: boolean;
    LABEL: string;
};
export declare const bookingInfo: {
    RESORT: string;
    NIGHTS: number;
    ARRIVAL: string;
    DEPARTURE: string;
    DEVELOPMENT: string;
    REFERENCE: string;
    CONFIRMED: string;
    ID: number;
    PROPERTY_IMAGE: string;
};
declare const inquiry: {
    GUEST_ID: number;
    MESSAGE: string;
    PROPERTY_ID: number;
    SUBJECT: string;
    TO_EMAILS: string;
    DATE_SENT: string;
    MESSAGE_RECIPIENT_ID: MessageRecipientIdEnum;
    FROM_EMAIL: string;
    TIME_SENT: string;
    BOOKING_ID: number;
    ID: number;
    INQUIRY_ID: number;
};
export declare const reviewRating: {
    QUESTION: string;
    MAX_SCORE: string;
    ID: number;
    TITLE: string;
    SCORE: RatingRange;
};
export declare const reviewResponses: {
    ID: number;
    CHECKIN_DATE: string;
    CHECKOUT_DATE: string;
    BOOKING_NUMBER: string;
    HOST_NAME: string;
    HOST_RECOMMENDATION: boolean;
    HOST_COMMENTS: string;
    HAS_COMMENT_ENABLED: boolean;
};
export declare const ELIGIBLE_REVIEW: {
    BOOKING_INFO: {
        RESORT: string;
        NIGHTS: number;
        ARRIVAL: string;
        DEPARTURE: string;
        DEVELOPMENT: string;
        REFERENCE: string;
        CONFIRMED: string;
        ID: number;
        PROPERTY_IMAGE: string;
    };
    ID: number;
    IS_GUEST_RESPONSE_POSSIBLE: boolean;
    IS_PUBLISHED: boolean;
    STATUS: string;
    STATUS_ID: ReviewStatusId;
};
export declare const REVIEW: Readonly<{
    PRIVATE_MESSAGE_TO_OWNER: "";
    REVIEW: "";
    GUEST_INFO: any;
    PUBLISHED_DATE: "";
    RATINGS: RatingItem[];
    RATINGS_AVERAGE: 0;
    RESPONSES: ReviewResponse[];
    REVIEW_DATE: "";
    TITLE: "";
    WOULD_RECOMMEND: false;
    BOOKING_INFO: {
        RESORT: string;
        NIGHTS: number;
        ARRIVAL: string;
        DEPARTURE: string;
        DEVELOPMENT: string;
        REFERENCE: string;
        CONFIRMED: string;
        ID: number;
        PROPERTY_IMAGE: string;
    };
    ID: number;
    IS_GUEST_RESPONSE_POSSIBLE: boolean;
    IS_PUBLISHED: boolean;
    STATUS: string;
    STATUS_ID: ReviewStatusId;
}>;
export declare const BOOKING_PROPERTY: {
    ADDRESS: {
        AREA: string;
        AREA_ID: number;
        CITY: string;
        COUNTRY: string;
        COUNTRY_CODE: string;
        COUNTRY_ID: number;
        DEVELOPMENT: string;
        DEVELOPMENT_ID: number;
        ID: number;
        LATITUDE: number;
        LONGITUDE: number;
        POSTAL: string;
        REGION: string;
        REGION_ID: number;
        RESORT: string;
        RESORT_ID: number;
        STREET_NAME: string;
        STREET_NUMBER: string;
        UNIT: string;
    };
    DIRECT_VACATIONS: {
        ID: number;
        IS_ACTIVE: boolean;
        LOGO: string;
        NAME: string;
        URL: string;
    };
    DAMAGE_DEPOSIT: {
        AMOUNT: string;
        DESCRIPTION: string;
        ID: number;
        IS_COLLECTED: boolean;
        MODE: string;
    };
    GATEWAY_MODE: {
        ID: BookingGateWayModeIdEnum;
        VALUE: string;
    };
    RULES: {
        ID: number;
        ADVANCED_BOOKING: {
            NAME: string;
            ID: number;
        };
        CHECK_IN: string;
        CHECK_OUT: string;
        MAX_BOOKABLE_DAYS: number;
        MAX_GUESTS: number;
        MIN_AGE_TO_BOOK: number;
        QUIET_TIME: string;
    };
    IS_ENABLED: boolean;
    MAX_GUESTS: number;
    NAME: string;
    SIZE_CATEGORY: string;
    SQUARE_FEET: number;
    SURCHARGES: {
        PETS: {
            IS_ENABLED: boolean;
            NAME: string;
            ID: number;
            AMOUNT: string;
        };
        CLEANING: {
            IS_ENABLED: boolean;
            NAME: string;
            ID: number;
            AMOUNT: string;
        };
    };
    STYLE: string;
    URL: string;
    JOIN_STATUS: {
        STATUS_ID: JoinStatusIDEnum;
    };
    ID: number;
    THUMBNAIL_URL: string;
    ACCESS_TO_UNIT: {
        CODE: {
            NAME: string;
            ID: import("../ownerFormInputs/types").AccessCodeIdEnum;
        };
        METHOD: {
            NAME: string;
            ID: import("../ownerFormInputs/types").AccessMethodIdEnum;
        };
        STANDARD_CODE: string;
        TYPE: {
            NAME: string;
            ID: import("../ownerFormInputs/types").AccessCodeTypeIDEnum;
        };
    };
    CODES: {
        BIKE_LOCKER_CODE: string;
        DEVELOPMENT_DOOR_CODE: string;
        DEVELOPMENT_GYM_CODE: string;
        DEVELOPMENT_HOT_TUB_CODE: string;
        DEVELOPMENT_POOL_CODE: string;
        DEVELOPMENT_SAUNA_CODE: string;
        DEVELOPMENT_STEAM_ROOM_CODE: string;
        FRONT_DOOR_CODE: string;
        GAMES_REC_ROOM_CODE: string;
        GARAGE_DOOR_CODE: string;
        GARBAGE_RECYCLING_CODE: string;
        ID: number;
        INTERNET_NETWORK_NAME: string;
        INTERNET_PASSWORD: string;
        PHONE_NUMBER: string;
        PROPERTY_ID: string;
        SKI_LOCKER_CODE: string;
        DATE_LAST_UPDATED: string;
    };
    PRIMARY_CONTACT: EmergencyContact & {
        THUMBNAIL_URL: string;
    };
};
export declare const fullPayment: {
    DAMAGE_DEPOSIT: {
        AMOUNT: string;
        DUE_DATE: string;
        IS_COLLECTED: boolean;
        MODE: string;
        MODE_ID: DamageDepositModeId;
    };
    DEPOSIT: {
        AMOUNT: string;
        DUE_DATE: string;
        NET: string;
        PAYMENT_DATE: string;
        PERCENTAGE: number;
        TOTAL: string;
    };
    BOOKING_NET: string;
    BOOKING_GROSS: string;
    PAID_TO_DATE: string;
    PRICE_PER_NIGHT: string;
    TAXES_AND_FEES_TOTAL: string;
    LOS_DISCOUNT: string;
    AMOUNT_OUTSTANDING: string;
    AMOUNT_REFUNDED: string;
    BALANCE: {
        DUE_DATE: string;
        PAYMENT_DATE: string;
        TOTAL: string;
    };
    NEXT_PAYMENT: {
        DUE_DATE: string;
        IS_PAST_DUE: boolean;
        NAME: string;
        TOTAL: string;
    };
};
export declare const BOOKING_STATUS: {
    ID: BookingStatusId;
    NAME: string;
};
export declare const CUSTOM_MESSAGE: {
    MESSAGE: string;
    ENTRY_CODE: string;
};
export declare const SPARSE_BOOKING: {
    CUSTOM_MESSAGE: {
        MESSAGE: string;
        ENTRY_CODE: string;
    };
    DATES: {
        ARRIVAL: string;
        BOOKING: string;
        BOOKING_TIME: string;
        CHECK_IN_SENT: string;
        DEPARTURE: string;
        SERVER_TIMESTAMP: string;
    };
    FLAGS: {
        IS_PAST_DUE: boolean;
    };
    GUEST: {
        AGE: string;
        EMAIL: string;
        FIRST_NAME: string;
        GUEST_PROFILE: {
            MEMBER_SINCE: string;
            PERMISSIONS: {
                SHOW_NUM_REVIEWS: boolean;
                SHOW_MEMBER_SINCE: boolean;
                SHOW_NUM_RECOMMENDS: boolean;
            };
            NUM_BOOKINGS: number;
            NUM_RECOMMENDATIONS: number;
            NUM_REVIEWS: number;
        };
        ID: number;
        IS_AGE_VERIFIED: boolean;
        IS_EMAIL_VERIFIED: boolean;
        IS_SMS_VERIFIED: boolean;
        LAST_NAME: string;
        PHONE: string;
        THUMBNAIL: string;
    };
    GUEST_COMMENT: string;
    GUEST_REQUESTS: string;
    ID: number;
    NIGHTS: number;
    NIGHTLY_RATES: {
        DATE: string;
        DAY: string;
        RATE: string;
        BASE_RATE: string;
        LOS_DISCOUNT: string;
        OFFER_DISCOUNT: string;
    }[];
    NOTES_OWNER: string;
    PARTY_SIZE: {
        ADULTS: number;
        KIDS: number;
    };
    PAYMENT: {
        AMOUNT_OUTSTANDING: string;
        AMOUNT_REFUNDED: string;
        BALANCE: {
            DUE_DATE: string;
            PAYMENT_DATE: string;
            TOTAL: string;
        };
        BOOKING_NET: string;
        DAMAGE_DEPOSIT: {
            MODE: string;
            MODE_ID: DamageDepositModeId;
        };
        DEPOSIT: {
            DUE_DATE: string;
            PAYMENT_DATE: string;
            TOTAL: string;
        };
        NEXT_PAYMENT: {
            DUE_DATE: string;
            IS_PAST_DUE: boolean;
            NAME: string;
            TOTAL: string;
        };
        PAID_TO_DATE: string;
    };
    PAYMENT_INFORMATION: {
        ACCOMMODATION_SUBTOTAL: string;
        ALLURA_OFFER_DISCOUNT: string;
        BOOKING_NET_BASE_RATE: string;
        BOOKING_NET_BASE_RATE_MINUS_LOS: string;
        LENGTH_OF_STAY_DISCOUNT: string;
        OWNER_OFFER_DISCOUNT: string;
    };
    PROPERTY: {
        RULES: {
            CHECK_IN: string;
            CHECK_OUT: string;
            MAX_GUESTS: string;
            MIN_AGE_TO_BOOK: number;
            MAX_BOOKABLE_DAYS: number;
            QUIET_TIME: number;
        };
        ADDRESS: {
            UNIT: string;
            RESORT: string;
            DEVELOPMENT: string;
            STREET_NAME: string;
            STREET_NUMBER: string;
        };
        JOIN_STATUS: {
            STATUS_ID: JoinStatusIDEnum;
        };
        ID: number;
        THUMBNAIL_URL: string;
        ACCESS_TO_UNIT: {
            CODE: {
                NAME: string;
                ID: import("../ownerFormInputs/types").AccessCodeIdEnum;
            };
            METHOD: {
                NAME: string;
                ID: import("../ownerFormInputs/types").AccessMethodIdEnum;
            };
            STANDARD_CODE: string;
            TYPE: {
                NAME: string;
                ID: import("../ownerFormInputs/types").AccessCodeTypeIDEnum;
            };
        };
        CODES: {
            BIKE_LOCKER_CODE: string;
            DEVELOPMENT_DOOR_CODE: string;
            DEVELOPMENT_GYM_CODE: string;
            DEVELOPMENT_HOT_TUB_CODE: string;
            DEVELOPMENT_POOL_CODE: string;
            DEVELOPMENT_SAUNA_CODE: string;
            DEVELOPMENT_STEAM_ROOM_CODE: string;
            FRONT_DOOR_CODE: string;
            GAMES_REC_ROOM_CODE: string;
            GARAGE_DOOR_CODE: string;
            GARBAGE_RECYCLING_CODE: string;
            ID: number;
            INTERNET_NETWORK_NAME: string;
            INTERNET_PASSWORD: string;
            PHONE_NUMBER: string;
            PROPERTY_ID: string;
            SKI_LOCKER_CODE: string;
            DATE_LAST_UPDATED: string;
        };
        PRIMARY_CONTACT: EmergencyContact & {
            THUMBNAIL_URL: string;
        };
    };
    REFERENCE: string;
    REVIEW: {
        ID: number;
    };
    SOURCE: string;
    STATUS: {
        ID: BookingStatusId;
        NAME: string;
    };
    STATUSES: {
        DATE: string;
        IS_DONE: boolean;
        LABEL: string;
    }[];
    SURCHARGES: {
        NET: string;
        TAXES_TOTAL: string;
    };
    TAX: {
        TOTAL: string;
    };
    TOTAL: string;
};
export declare const FULL_BOOKING: {
    /** Total credit card processing fee on this booking.
     *  Deducted from net amount owner recieves for a booking
     *  Calculated from (accomodation + surcharges) x 0.3 = CREDIT_CARD_FEE
     */
    COMMISSION: string;
    CREDIT_CARD_FEE: string;
    /** Percentage fee deducted from the accomodation + surcharges total  */
    CREDIT_CARD_PERCENTAGE: number;
    /** The total amount that the owner will receive for this booking after all other deductions and additions */
    BANK_DEPOSIT: {
        AMOUNT: string;
        DATE: string;
        ACCOUNT: string;
    };
    BLOCK_OFF_REASON: string;
    CONTACT_TRACING: {
        EMAIL: string;
        FIRST_NAME: string;
        ID: number;
        IS_CHILD: boolean;
        LAST_NAME: string;
        PHONE: string;
    }[];
    DATES: {
        NEXT_PAYMENT: string;
        PROPERTY_GUIDEBOOK_SEND: string;
        ARRIVAL: string;
        BOOKING: string;
        BOOKING_TIME: string;
        CHECK_IN_SENT: string;
        DEPARTURE: string;
        SERVER_TIMESTAMP: string;
    };
    FLAGS: {
        IS_ALLURA_BOOKING: boolean;
        IS_BLOCK_OFF: boolean;
        IS_DIRECT_VACATIONS: boolean;
        IS_EDITABLE: boolean;
        IS_INNTOPIA_BOOKING: boolean;
        IS_LMVR_PARTNER_BOOKING: boolean;
        IS_LMVR_PM_BOOKING: boolean;
        IS_PAST_DUE: boolean;
    };
    GUEST: WithRequiredProperty<User, "GUEST_PROFILE">;
    GUEST_COMMENT: string;
    INQUIRIES: (typeof inquiry)[];
    NR6_PERCENTAGE: string;
    NR6_WITHHELD: string;
    PARTNER: {
        INFLATION_TOTAL: number;
    };
    PARTY_SIZE: {
        MAX: number;
        ADULTS: number;
        KIDS: number;
    };
    PAYMENT: {
        DAMAGE_DEPOSIT: {
            AMOUNT: string;
            DUE_DATE: string;
            IS_COLLECTED: boolean;
            MODE: string;
            MODE_ID: DamageDepositModeId;
        };
        DEPOSIT: {
            AMOUNT: string;
            DUE_DATE: string;
            NET: string;
            PAYMENT_DATE: string;
            PERCENTAGE: number;
            TOTAL: string;
        };
        BOOKING_NET: string;
        BOOKING_GROSS: string;
        PAID_TO_DATE: string;
        PRICE_PER_NIGHT: string;
        TAXES_AND_FEES_TOTAL: string;
        LOS_DISCOUNT: string;
        AMOUNT_OUTSTANDING: string;
        AMOUNT_REFUNDED: string;
        BALANCE: {
            DUE_DATE: string;
            PAYMENT_DATE: string;
            TOTAL: string;
        };
        NEXT_PAYMENT: {
            DUE_DATE: string;
            IS_PAST_DUE: boolean;
            NAME: string;
            TOTAL: string;
        };
    };
    PROPERTY: {
        ADDRESS: {
            AREA: string;
            AREA_ID: number;
            CITY: string;
            COUNTRY: string;
            COUNTRY_CODE: string;
            COUNTRY_ID: number;
            DEVELOPMENT: string;
            DEVELOPMENT_ID: number;
            ID: number;
            LATITUDE: number;
            LONGITUDE: number;
            POSTAL: string;
            REGION: string;
            REGION_ID: number;
            RESORT: string;
            RESORT_ID: number;
            STREET_NAME: string;
            STREET_NUMBER: string;
            UNIT: string;
        };
        DIRECT_VACATIONS: {
            ID: number;
            IS_ACTIVE: boolean;
            LOGO: string;
            NAME: string;
            URL: string;
        };
        DAMAGE_DEPOSIT: {
            AMOUNT: string;
            DESCRIPTION: string;
            ID: number;
            IS_COLLECTED: boolean;
            MODE: string;
        };
        GATEWAY_MODE: {
            ID: BookingGateWayModeIdEnum;
            VALUE: string;
        };
        RULES: {
            ID: number;
            ADVANCED_BOOKING: {
                NAME: string;
                ID: number;
            };
            CHECK_IN: string;
            CHECK_OUT: string;
            MAX_BOOKABLE_DAYS: number;
            MAX_GUESTS: number;
            MIN_AGE_TO_BOOK: number;
            QUIET_TIME: string;
        };
        IS_ENABLED: boolean;
        MAX_GUESTS: number;
        NAME: string;
        SIZE_CATEGORY: string;
        SQUARE_FEET: number;
        SURCHARGES: {
            PETS: {
                IS_ENABLED: boolean;
                NAME: string;
                ID: number;
                AMOUNT: string;
            };
            CLEANING: {
                IS_ENABLED: boolean;
                NAME: string;
                ID: number;
                AMOUNT: string;
            };
        };
        STYLE: string;
        URL: string;
        JOIN_STATUS: {
            STATUS_ID: JoinStatusIDEnum;
        };
        ID: number;
        THUMBNAIL_URL: string;
        ACCESS_TO_UNIT: {
            CODE: {
                NAME: string;
                ID: import("../ownerFormInputs/types").AccessCodeIdEnum;
            };
            METHOD: {
                NAME: string;
                ID: import("../ownerFormInputs/types").AccessMethodIdEnum;
            };
            STANDARD_CODE: string;
            TYPE: {
                NAME: string;
                ID: import("../ownerFormInputs/types").AccessCodeTypeIDEnum;
            };
        };
        CODES: {
            BIKE_LOCKER_CODE: string;
            DEVELOPMENT_DOOR_CODE: string;
            DEVELOPMENT_GYM_CODE: string;
            DEVELOPMENT_HOT_TUB_CODE: string;
            DEVELOPMENT_POOL_CODE: string;
            DEVELOPMENT_SAUNA_CODE: string;
            DEVELOPMENT_STEAM_ROOM_CODE: string;
            FRONT_DOOR_CODE: string;
            GAMES_REC_ROOM_CODE: string;
            GARAGE_DOOR_CODE: string;
            GARBAGE_RECYCLING_CODE: string;
            ID: number;
            INTERNET_NETWORK_NAME: string;
            INTERNET_PASSWORD: string;
            PHONE_NUMBER: string;
            PROPERTY_ID: string;
            SKI_LOCKER_CODE: string;
            DATE_LAST_UPDATED: string;
        };
        PRIMARY_CONTACT: EmergencyContact & {
            THUMBNAIL_URL: string;
        };
    };
    PROPERTY_GUIDEBOOK_SEND_DATE: string;
    PROPERTY_MANAGER_SERVICE_FEE: {
        IS_FEE_ON_SUBTOTAL_TO_OWNER: boolean;
        NET: string;
        TAXES: {
            AMOUNT: string;
            ID: number;
            IS_PASS_THROUGH_TO_OWNER: boolean;
            NAME: string;
            RATE: number;
        }[];
        TOTAL: string;
    };
    PROPERTY_OWNER: {
        COMPANY_NAME: string;
        FIRST_NAME: string;
        ID: number;
        IS_COMPANY: boolean;
        LAST_NAME: string;
        EMAIL: string;
        THUMBNAIL: string;
    };
    REVIEW: Readonly<{
        PRIVATE_MESSAGE_TO_OWNER: "";
        REVIEW: "";
        GUEST_INFO: any;
        PUBLISHED_DATE: "";
        RATINGS: RatingItem[];
        RATINGS_AVERAGE: 0;
        RESPONSES: ReviewResponse[];
        REVIEW_DATE: "";
        TITLE: "";
        WOULD_RECOMMEND: false;
        BOOKING_INFO: {
            RESORT: string;
            NIGHTS: number;
            ARRIVAL: string;
            DEPARTURE: string;
            DEVELOPMENT: string;
            REFERENCE: string;
            CONFIRMED: string;
            ID: number;
            PROPERTY_IMAGE: string;
        };
        ID: number;
        IS_GUEST_RESPONSE_POSSIBLE: boolean;
        IS_PUBLISHED: boolean;
        STATUS: string;
        STATUS_ID: ReviewStatusId;
    }>;
    SERVICE_FEE: {
        DESCRIPTION: string;
        FEE: string;
        ID: number;
        NAME: string;
        TAX: string;
        TAXES: {
            AMOUNT: string;
            ID: number;
            IS_PASS_THROUGH_TO_OWNER: boolean;
            NAME: string;
            RATE: number;
        }[];
        TAXES_STRING: string;
        TOTAL: string;
    };
    SURCHARGES: {
        GROSS: string;
        LIST: {
            [key: string]: {
                IS_ENABLED: boolean;
                TAX: string;
                TAXES: {};
                FEE: string;
                NAME: string;
                ID: number;
                TOTAL: string;
            };
        };
        NET: string;
        TAXES_TOTAL: string;
        TAXES_TOTALS: {
            AMOUNT: string;
            ID: number;
            IS_PASS_THROUGH_TO_OWNER: boolean;
            NAME: string;
            RATE: number;
        }[];
    };
    /** Taxes applied to the accommodation subtotal */
    TAX: {
        RATE_TOTAL: number;
        /** Taxes aplied to the accomodation/booking subtotal (PAYMENT.BOOKING_NET)
         * This can be an empty array due to the rulesets below:
         *
        # Bookings and Surcharges on Inntopia (Partner Bookings)
        * will have GST applied, if an owner collects GST and has supplied a GST Number
        * if rental in BC, has PST and MRDT applied
      
        # Bookings on alluraDirect
        * will have GST applied, if an owner collects GST and has supplied a GST Number, and if the booking is under 30 nights, else it is GST exempt and the tax is not applied
        * if rental in BC, has PST and MRDT applied if the booking is under 27 nights, else it is PST/MRDT exempt and those taxes are not applied
        * if rental in PQ, has QST and MTLT applied if owner decides to charge and remit these taxes
         */
        BOOKING: {
            AMOUNT: string;
            ID: number;
            IS_PASS_THROUGH_TO_OWNER: boolean;
            NAME: string;
            RATE: number;
        }[];
        BOOKING_AND_FEES: {
            AMOUNT: string;
            ID: number;
            IS_PASS_THROUGH_TO_OWNER: boolean;
            NAME: string;
            RATE: number;
        }[];
        BOOKING_AND_FEES_TOTAL: number;
        PERCENTAGES: string;
        TOTAL: number;
        TOTALS: {
            AMOUNT: string;
            ID: number;
            IS_PASS_THROUGH_TO_OWNER: boolean;
            NAME: string;
            RATE: number;
        }[];
        WITHHELD: {
            GST: string;
            PST: string;
            MRDT: string;
        };
    };
    THUMBNAIL_URL: string;
    TOTALS_PAID: {
        ACCOMMODATION_NET: string;
        ACCOMMODATION_TAXES: {
            AMOUNT: string;
            NAME: string;
        }[];
        BANK_DEPOSIT: string;
        COMMISSION: string;
        COMMISSION_PARTNER: string;
        CREDIT_CARD_FEE: string;
        DAMAGE_DEPOSIT: string;
        NR6: string;
        OWNER_PASS_THROUGH_TAXES: {
            AMOUNT: string;
            ID: number;
            IS_PASS_THROUGH_TO_OWNER: boolean;
            NAME: string;
            RATE: number;
        }[];
        REVENUE_NET: string;
        PROPERTY_MANAGER_SERVICE_FEE: {
            IS_FEE_ON_SUBTOTAL_TO_OWNER: boolean;
            NET: string;
            TAXES: {
                AMOUNT: string;
                ID: number;
                IS_PASS_THROUGH_TO_OWNER: boolean;
                NAME: string;
                RATE: number;
            }[];
            TOTAL: string;
        };
        SURCHARGE: {
            TAXES: {
                AMOUNT: string;
                ID: number;
                IS_PASS_THROUGH_TO_OWNER: boolean;
                NAME: string;
                RATE: number;
            }[];
            NET: string;
        };
        SURCHARGE_NET: string;
        SURCHARGE_TAXES: {
            AMOUNT: string;
            ID: number;
            IS_PASS_THROUGH_TO_OWNER: boolean;
            NAME: string;
            RATE: number;
        }[];
        TAX: string;
    };
    TRANSACTIONS: {
        AMOUNT: string;
        BANK_DEPOSIT: {
            ACCOUNT: string;
            AMOUNT: string;
            DATE: string;
        };
        BOOKING_NET: string;
        CATEGORY: string;
        COMMISSION: {
            GST: string;
            MRDT: string;
            NET: string;
            PST: string;
            TOTAL: string;
        };
        CREDIT_CARD: {
            CARDHOLDER_NAME: string;
            NAME: string;
            NUMBER: string;
        };
        CREDIT_CARD_WITHHELD: string;
        DAMAGE_DEPOSIT_AMOUNT: string;
        DATE: string;
        ID: number;
        NR6_PERCENTAGE: number;
        NR6_WITHHELD: string;
        SERVICE_FEE: {
            FEE: number;
            ID: number;
            NAME: string;
            TAX: number;
            TAXES: {
                AMOUNT: number;
                ID: number;
                NAME: string;
                RATE: number;
            }[];
            TOTAL: number;
        };
        SURCHARGES: {
            GROSS: string;
            LIST: {
                [key: string]: {
                    IS_ENABLED: boolean;
                    TAX: string;
                    TAXES: {};
                    FEE: string;
                    NAME: string;
                    ID: number;
                    TOTAL: string;
                };
            };
            NET: string;
            TAXES_TOTAL: string;
            TAXES_TOTALS: {
                AMOUNT: string;
                ID: number;
                IS_PASS_THROUGH_TO_OWNER: boolean;
                NAME: string;
                RATE: number;
            }[];
        };
        TAX: {
            TAXES: {
                AMOUNT: string;
                ID: number;
                IS_PASS_THROUGH_TO_OWNER: boolean;
                NAME: string;
                RATE: number;
            }[];
            TOTAL: string;
            WITHHELD: {
                MRDT: string;
                PST: string;
            };
        };
        TYPE: string;
    }[];
    TIMELINE: {
        DATE: string;
        TITLE: string;
        IS_COMPLETED: boolean;
    }[];
    CUSTOM_MESSAGE: {
        MESSAGE: string;
        ENTRY_CODE: string;
    };
    GUEST_REQUESTS: string;
    ID: number;
    NIGHTS: number;
    NIGHTLY_RATES: {
        DATE: string;
        DAY: string;
        RATE: string;
        BASE_RATE: string;
        LOS_DISCOUNT: string;
        OFFER_DISCOUNT: string;
    }[];
    NOTES_OWNER: string;
    PAYMENT_INFORMATION: {
        ACCOMMODATION_SUBTOTAL: string;
        ALLURA_OFFER_DISCOUNT: string;
        BOOKING_NET_BASE_RATE: string;
        BOOKING_NET_BASE_RATE_MINUS_LOS: string;
        LENGTH_OF_STAY_DISCOUNT: string;
        OWNER_OFFER_DISCOUNT: string;
    };
    REFERENCE: string;
    SOURCE: string;
    STATUS: {
        ID: BookingStatusId;
        NAME: string;
    };
    STATUSES: {
        DATE: string;
        IS_DONE: boolean;
        LABEL: string;
    }[];
    TOTAL: string;
};
export declare const bookingSurcharge: {
    FEE: string;
    ID: number;
    NAME: string;
    TAX: string;
    Taxes: {
        IS_PASS_THROUGH_TO_OWNER: boolean;
        AMOUNT: string;
        ID: number;
        NAME: string;
    };
};
export declare const bookingSurchargesTotal: {
    TAXES_TOTAL: number;
    LIST: never[];
    NET: string;
    GROSS: string;
    TAXES_TOTALS: string;
};
export declare const bookingTax: {
    RATE: number;
    IS_PASS_THROUGH_TO_OWNER: boolean;
    AMOUNT: string;
    ID: number;
    NAME: string;
};
export declare const BOOKING_GUEST_EXISTS: {
    IS_EXISTING_GUEST: boolean;
};
export {};
