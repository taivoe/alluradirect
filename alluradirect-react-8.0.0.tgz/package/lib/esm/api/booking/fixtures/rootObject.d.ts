export declare const rootObject: {
    GUEST_REQUESTS: string;
    SURCHARGES: {
        TAXES_TOTALS: never[];
        LIST: {};
        NET: string;
        GROSS: string;
        TAXES_TOTAL: string;
    };
    TAX: {
        RATE_TOTAL: number;
        BOOKING: {
            IS_PASS_THROUGH_TO_OWNER: boolean;
            NAME: string;
            ID: number;
            RATE: number;
            AMOUNT: string;
        }[];
        TOTAL: string;
        PERCENTAGES: string;
        TOTALS: {
            IS_PASS_THROUGH_TO_OWNER: boolean;
            NAME: string;
            ID: number;
            RATE: number;
            AMOUNT: string;
        }[];
    };
    GUEST_COMMENT: string;
    TOTALS_PAID: {
        REVENUE_NET: string;
        OWNER_PASS_THROUGH_TAXES: never[];
        BANK_DEPOSIT: string;
        TAX: string;
        ACCOMMODATION_NET: string;
        ACCOMMODATION_TAXES: never[];
        COMMISSION: string;
        CREDIT_CARD_FEE: string;
        SURCHARGE: {
            TAXES: never[];
            NET: string;
        };
        COMMISSION_PARTNER: string;
        NR6: string;
        PROPERTY_MANAGER_SERVICE_FEE: {
            TAXES: {
                IS_PASS_THROUGH_TO_OWNER: boolean;
                NAME: string;
                ID: number;
                RATE: number;
                AMOUNT: string;
            }[];
            NET: string;
            TOTAL: string;
            IS_FEE_ON_SUBTOTAL_TO_OWNER: boolean;
        };
        DAMAGE_DEPOSIT: string;
    };
    REVIEW: {};
    PROPERTY: {
        IS_ENABLED: number;
        SURCHARGES: {
            PETS: {
                IS_ENABLED: boolean;
                NAME: string;
                ID: number;
                AMOUNT: string;
            };
            CLEANING: {
                IS_ENABLED: boolean;
                NAME: string;
                ID: number;
                AMOUNT: string;
            };
        };
        MAX_GUESTS: number;
        DIRECT_VACATIONS: {
            IS_ACTIVE: boolean;
            URL: string;
            LOGO: string;
            NAME: string;
            ID: number;
        };
        THUMBNAIL_URL: string;
        ACCESS_TO_UNIT: {
            STANDARD_CODE: string;
            CODE: {
                NAME: string;
                ID: number;
            };
            TYPE: {
                NAME: string;
                ID: number;
            };
            METHOD: {
                NAME: string;
                ID: number;
            };
        };
        CODES: {
            FRONT_DOOR_CODE: string;
            DEVELOPMENT_POOL_CODE: string;
            DEVELOPMENT_GYM_CODE: string;
            DEVELOPMENT_HOT_TUB_CODE: string;
            DEVELOPMENT_STEAM_ROOM_CODE: string;
            PROPERTY_ID: number;
            SKI_LOCKER_CODE: string;
            DEVELOPMENT_DOOR_CODE: string;
            INTERNET_NETWORK_NAME: string;
            BIKE_LOCKER_CODE: string;
            PHONE_NUMBER: string;
            INTERNET_PASSWORD: string;
            DEVELOPMENT_SAUNA_CODE: string;
            ID: number;
            GAMES_REC_ROOM_CODE: string;
            GARBAGE_RECYCLING_CODE: string;
            GARAGE_DOOR_CODE: string;
            DATE_LAST_UPDATED: string;
        };
        SQUARE_FEET: number;
        STYLE: string;
        URL: string;
        NAME: string;
        ID: number;
        RULES: {
            MAX_GUESTS: number;
            CHECK_OUT: string;
            MIN_AGE_TO_BOOK: number;
            QUIET_TIME: string;
            ADVANCED_BOOKING: {
                NAME: string;
                ID: number;
            };
            ID: number;
            CHECK_IN: string;
        };
        ADDRESS: {
            RESORT: string;
            LONGITUDE: number;
            AREA: string;
            COUNTRY: string;
            AREA_ID: number;
            POSTAL: string;
            COUNTRY_CODE: string;
            STREET_NAME: string;
            DEVELOPMENT_ID: number;
            LATITUDE: number;
            REGION_ID: number;
            ID: number;
            UNIT: string;
            REGION: string;
            CITY: string;
            STREET_NUMBER: string;
            COUNTRY_ID: number;
            DEVELOPMENT: string;
            RESORT_ID: number;
        };
        SIZE_CATEGORY: string;
    };
    REFERENCE: string;
    STATUS: {
        NAME: string;
        ID: number;
    };
    FLAGS: {
        IS_ALLURA_BOOKING: boolean;
        IS_BLOCK_OFF: boolean;
        IS_DIRECT_VACATIONS: boolean;
        IS_EDITABLE: boolean;
        IS_INNTOPIA_BOOKING: boolean;
        IS_LMVR_PARTNER_BOOKING: boolean;
        IS_PAST_DUE: boolean;
        IS_LMVR_PM_BOOKING: boolean;
    };
    CONTACT_TRACING: {
        FIRST_NAME: string;
        LAST_NAME: string;
        ID: number;
        PHONE: string;
        IS_CHILD: boolean;
        EMAIL: string;
    }[];
    STATUSES: {
        DATE: string;
        IS_DONE: boolean;
        LABEL: string;
    }[];
    TOTAL: string;
    DATES: {
        NEXT_PAYMENT: string;
        ARRIVAL: string;
        CHECK_IN_SENT: string;
        DEPARTURE: string;
        PROPERTY_GUIDEBOOK_SEND: string;
        BOOKING: string;
    };
    PARTY_SIZE: {
        ADULTS: number;
        KIDS: number;
        MAX: number;
    };
    TRANSACTIONS: never[];
    CUSTOM_MESSAGE: {
        MESSAGE: string;
        ENTRY_CODE: string;
    };
    BLOCK_OFF_REASON: string;
    INQUIRIES: never[];
    SOURCE: string;
    NIGHTS: number;
    PURPOSE: string;
    PROPERTY_RULES: {
        CHECK_OUT_TIME: string;
        MAX_GUESTS: number;
        QUIET_TIME: string;
        CHECK_IN_TIME: string;
    };
    NOTES_OWNER: string;
    SERVICE_FEE: {
        TAX: string;
        TAXES: {
            IS_PASS_THROUGH_TO_OWNER: boolean;
            NAME: string;
            ID: number;
            RATE: number;
            AMOUNT: string;
        }[];
        TAXES_STRING: string;
        FEE: string;
        NAME: string;
        ID: number;
        TOTAL: string;
        DESCRIPTION: string;
    };
    PROPERTY_OWNER: {
        COMPANY_NAME: string;
        FIRST_NAME: string;
        THUMBNAIL: string;
        LAST_NAME: string;
        ID: number;
        IS_COMPANY: boolean;
        EMAIL: string;
    };
    ID: number;
    PROPERTY_MANAGER_SERVICE_FEE: {
        TAXES: {
            IS_PASS_THROUGH_TO_OWNER: boolean;
            NAME: string;
            ID: number;
            RATE: number;
            AMOUNT: string;
        }[];
        NET: string;
        TOTAL: string;
        IS_FEE_ON_SUBTOTAL_TO_OWNER: boolean;
    };
    PAYMENT: {
        PAID_TO_DATE: string;
        AMOUNT_OUTSTANDING: string;
        AMOUNT_REFUNDED: string;
        BOOKING_NET: string;
        PRICE_PER_NIGHT: string;
        BALANCE: {
            DUE_DATE: string;
            NET: string;
            TOTAL: string;
            PAYMENT_DATE: string;
        };
        DEPOSIT: {
            DUE_DATE: string;
            NET: string;
            TOTAL: string;
            PAYMENT_DATE: string;
            PERCENTAGE: number;
        };
        DAMAGE_DEPOSIT: {
            MODE: string;
            DUE_DATE: string;
            IS_COLLECTED: boolean;
            MODE_ID: number;
            AMOUNT: string;
        };
        BOOKING_GROSS: string;
    };
    GUEST: {
        COMPANY_NAME: string;
        MEMBER_SINCE: string;
        PERMISSIONS: {
            SHOW_NUM_REVIEWS: boolean;
            SHOW_MEMBER_SINCE: boolean;
            SHOW_NUM_RECOMMENDS: boolean;
        };
        NUM_BOOKINGS: number;
        FIRST_NAME: string;
        STATUS: string;
        THUMBNAIL: string;
        LAST_NAME: string;
        ID: number;
        NUM_RECOMMENDATIONS: number;
        LOGIN: string;
        NUM_REVIEWS: number;
        PHONE: string;
        IS_COMPANY: boolean;
        CREATED_DATE: string;
        USER_TYPE_ID: number;
        ADDRESS: {
            RESORT: string;
            LONGITUDE: number;
            AREA: string;
            COUNTRY: string;
            AREA_ID: number;
            POSTAL: string;
            COUNTRY_CODE: string;
            STREET_NAME: string;
            DEVELOPMENT_ID: number;
            LATITUDE: number;
            REGION_ID: number;
            ID: number;
            UNIT: string;
            REGION: string;
            CITY: string;
            STREET_NUMBER: string;
            COUNTRY_ID: number;
            DEVELOPMENT: string;
            RESORT_ID: number;
        };
        EMAIL: string;
    };
};
