import { TaxIDEnum } from '../../types';
export type TaxItem = ReturnType<typeof generateTaxItem>;
export type BookingTax = typeof TAX;
declare const generateTaxItem: ({ AMOUNT }: {
    AMOUNT: string;
}) => {
    IS_PASS_THROUGH_TO_OWNER: boolean;
    NAME: string;
    ID: TaxIDEnum;
    RATE: number;
    AMOUNT: string;
};
declare const TAX: {
    RATE_TOTAL: number;
    BOOKING: {
        IS_PASS_THROUGH_TO_OWNER: boolean;
        NAME: string;
        ID: TaxIDEnum;
        RATE: number;
        AMOUNT: string;
    }[];
    TOTAL: string;
    PERCENTAGES: string;
    TOTALS: {
        IS_PASS_THROUGH_TO_OWNER: boolean;
        NAME: string;
        ID: TaxIDEnum;
        RATE: number;
        AMOUNT: string;
    }[];
};
export {};
