import { AlluraNotification, BlackoutPeriod, LocationDataDevelopment, LocationDataRegion, LocationDataResort, NameIdItem, NotificationCategoriesEnum, NotificationCategoryIdEnum, NotificationLevelsEnum } from './types';
export declare const address: {
    AREA: string;
    AREA_ID: number;
    CITY: string;
    COUNTRY: string;
    COUNTRY_CODE: string;
    COUNTRY_ID: number;
    DEVELOPMENT: string;
    DEVELOPMENT_ID: number;
    ID: number;
    LATITUDE: number;
    LONGITUDE: number;
    POSTAL: string;
    REGION: string;
    REGION_ID: number;
    RESORT: string;
    RESORT_ID: number;
    STREET_NAME: string;
    STREET_NUMBER: string;
    UNIT: string;
};
export declare const amenity: {
    ID: number;
    NAME: string;
    INSTRUCTIONS: string;
    DESCRIPTION: string;
    PROPERTY_AMENITY_ID: number;
    /** Optional field on an amenity */
    ACCESS_CODE: string;
    /** Only appears when using the internet amenity */
    INTERNET_PASSWORD: string;
    INTERNET_NETWORK_NAME: string;
};
export declare const CANCELLATION_POLICY: {
    ADMIN_PENALTY: number;
    ADMIN_PENALTY_UNIT: string;
    BOOKING_GRACE_PERIOD: string;
    DATE_ACTIVATED: string;
    DATE_LAST_UPDATED: string;
    DATE_RANGES: {
        DATE_ACTIVATED: string;
        DESCRIPTION: string;
        FROM_DAYS: string;
        ID: number;
        LABEL: string;
        REFUND_PERCENTAGE: string;
        TO_DAYS: string;
    }[];
    DESCRIPTION: string;
    ID: number;
    IS_CREDIT_ONLY_REFUND: boolean;
    IS_REFUND_REBOOKED_DATES: boolean;
    IS_SPECIAL_CIRCUMSTANCE: boolean;
    NAME: string;
    POLICY_ID: number;
    SERVICE_FEE_REFUND: string;
    SPECIAL_CIRCUMSTANCE_DESCRIPTION: string;
    SPECIAL_CIRCUMSTANCE_ID: number;
    SPECIAL_CIRCUMSTANCE_NAME: string;
    SURCHARGE_REFUND: string;
};
export declare const notification: {
    CATEGORY_ID: NotificationCategoryIdEnum;
    LEVEL_ID: number;
    IS_DISMISSIBLE: boolean;
    DATE_CREATED: string;
    CATEGORY_LINK_ID: number;
    LEVEL_NAME: NotificationLevelsEnum;
    LEVEL: number;
    HTML_CONTENT: string;
    IS_FEATURED: boolean;
    IS_DISMISSED: boolean;
    CATEGORY: NotificationCategoriesEnum;
    DATE_DISMISSED: string;
    ID: number;
    IMAGE_URL: string;
    TITLE: string;
    DESCRIPTION: string;
    PROPERTY_ID: number;
    PROPERTY_NAME: string;
    PROPERTY_ADDRESS: string;
};
export declare const NOTIFICATION_ENDPOINT_RESPONSE: {
    PROPERTY_ID: number;
    UNREAD_COUNT: number;
    NOTIFICATIONS: AlluraNotification[];
};
export declare const BLACKOUT_PERIOD: {
    ID: number;
    START: string;
    END: string;
};
export declare const OFFER: {
    BLACKOUT_PERIODS: BlackoutPeriod[];
    CODE: string;
    DESCRIPTION: string;
    DISTRIBUTION: string;
    DISTRIBUTION_ID: number;
    DOLLAR: string;
    GIFT_CERTIFICATE_URL: string;
    GUEST_EMAIL: string;
    GUEST_ID: number;
    INSTRUCTIONS: string;
    IS_ALL_PROPERTIES: boolean;
    IS_EDITABLE: boolean;
    IS_ENABLED: boolean;
    IS_PERMANENT_REPEAT_GUEST_OFFER: boolean;
    IS_PROMOTED: boolean;
    IS_PUBLIC: boolean;
    MAX_USAGE_COUNT: number;
    MIN_NIGHTS: number;
    NIGHTS_FREE: number;
    NIGHTS_REQUIRED: number;
    OFFER_AVAILABILITY_ID: number;
    OFFER_AVAILABLE_END: string;
    OFFER_AVAILABLE_START: string;
    OFFER_CATEGORY: string;
    OFFER_CATEGORY_ID: number;
    OFFER_END: string;
    OFFER_ID: number;
    OFFER_START: string;
    OFFER_TYPE_ID: number;
    OFFER_URL: string;
    PERCENTAGE: number;
    PROMOTED_OFFER_ID: number;
    PROPERTY_IDS: string;
    STATUS: string;
    TITLE: string;
    USAGE_COUNT: number;
    USER_ID: number;
};
export declare const tax: {
    AMOUNT: string;
    ID: number;
    NAME: string;
};
export declare const taxSurcharge: {
    IS_PASS_THROUGH_TO_OWNER: boolean;
    AMOUNT: string;
    ID: number;
    NAME: string;
};
export declare const contactTracingGuest: {
    EMAIL: string;
    FIRST_NAME: string;
    ID: number;
    IS_CHILD: boolean;
    LAST_NAME: string;
    PHONE: string;
};
export declare const surchargeTaxItem: {
    ACCOUNT: string;
    STRING: string;
};
export declare const taxItem: {
    AMOUNT: string;
    ID: number;
    IS_PASS_THROUGH_TO_OWNER: boolean;
    NAME: string;
    RATE: number;
};
declare const BOOKING_SURCHARGE: {
    IS_ENABLED: boolean;
    TAX: string;
    TAXES: {};
    FEE: string;
    NAME: string;
    ID: number;
    TOTAL: string;
};
export declare const BOOKING_SURCHARGES_LIST: {
    [key: string]: typeof BOOKING_SURCHARGE;
};
export declare const BOOKING_SURCHARGES: {
    GROSS: string;
    LIST: {
        [key: string]: {
            IS_ENABLED: boolean;
            TAX: string;
            TAXES: {};
            FEE: string;
            NAME: string;
            ID: number;
            TOTAL: string;
        };
    };
    NET: string;
    TAXES_TOTAL: string;
    TAXES_TOTALS: {
        AMOUNT: string;
        ID: number;
        IS_PASS_THROUGH_TO_OWNER: boolean;
        NAME: string;
        RATE: number;
    }[];
};
export declare const DIRECT_VACATIONS: {
    ID: number;
    IS_ACTIVE: boolean;
    LOGO: string;
    NAME: string;
    URL: string;
};
export declare const propertyGuidebookPDF: {
    PROPERTY_GUIDEBOOK_PDF: string;
    BOOKING_ID: number;
    ID: number;
};
export declare const propertyOwner: {
    COMPANY_NAME: string;
    FIRST_NAME: string;
    ID: number;
    IS_COMPANY: boolean;
    LAST_NAME: string;
    EMAIL: string;
    THUMBNAIL: string;
};
export declare const propertyRules: {
    CHECK_IN_TIME: string;
    CHECK_OUT_TIME: string;
    MAX_GUESTS: number;
    QUIET_TIME: string;
};
export declare const serviceFee: {
    DESCRIPTION: string;
    FEE: string;
    ID: number;
    NAME: string;
    TAX: string;
    TAXES: {
        AMOUNT: string;
        ID: number;
        IS_PASS_THROUGH_TO_OWNER: boolean;
        NAME: string;
        RATE: number;
    }[];
    TAXES_STRING: string;
    TOTAL: string;
};
export declare const accommodationTaxItem: {
    AMOUNT: string;
    NAME: string;
};
export declare const totalsPaid: {
    ACCOMMODATION_NET: string;
    ACCOMMODATION_TAXES: {
        AMOUNT: string;
        NAME: string;
    }[];
    BANK_DEPOSIT: string;
    COMMISSION: string;
    COMMISSION_PARTNER: string;
    CREDIT_CARD_FEE: string;
    DAMAGE_DEPOSIT: string;
    NR6: string;
    OWNER_PASS_THROUGH_TAXES: {
        AMOUNT: string;
        ID: number;
        IS_PASS_THROUGH_TO_OWNER: boolean;
        NAME: string;
        RATE: number;
    }[];
    REVENUE_NET: string;
    PROPERTY_MANAGER_SERVICE_FEE: {
        IS_FEE_ON_SUBTOTAL_TO_OWNER: boolean;
        NET: string;
        TAXES: {
            AMOUNT: string;
            ID: number;
            IS_PASS_THROUGH_TO_OWNER: boolean;
            NAME: string;
            RATE: number;
        }[];
        TOTAL: string;
    };
    SURCHARGE: {
        TAXES: {
            AMOUNT: string;
            ID: number;
            IS_PASS_THROUGH_TO_OWNER: boolean;
            NAME: string;
            RATE: number;
        }[];
        NET: string;
    };
    SURCHARGE_NET: string;
    SURCHARGE_TAXES: {
        AMOUNT: string;
        ID: number;
        IS_PASS_THROUGH_TO_OWNER: boolean;
        NAME: string;
        RATE: number;
    }[];
    TAX: string;
};
export declare const serviceFeeTaxItem: {
    AMOUNT: number;
    ID: number;
    NAME: string;
    RATE: number;
};
export declare const transaction: {
    AMOUNT: string;
    BANK_DEPOSIT: {
        ACCOUNT: string;
        AMOUNT: string;
        DATE: string;
    };
    BOOKING_NET: string;
    CATEGORY: string;
    COMMISSION: {
        GST: string;
        MRDT: string;
        NET: string;
        PST: string;
        TOTAL: string;
    };
    CREDIT_CARD: {
        CARDHOLDER_NAME: string;
        NAME: string;
        NUMBER: string;
    };
    CREDIT_CARD_WITHHELD: string;
    DAMAGE_DEPOSIT_AMOUNT: string;
    DATE: string;
    ID: number;
    NR6_PERCENTAGE: number;
    NR6_WITHHELD: string;
    SERVICE_FEE: {
        FEE: number;
        ID: number;
        NAME: string;
        TAX: number;
        TAXES: {
            AMOUNT: number;
            ID: number;
            NAME: string;
            RATE: number;
        }[];
        TOTAL: number;
    };
    SURCHARGES: {
        GROSS: string;
        LIST: {
            [key: string]: {
                IS_ENABLED: boolean;
                TAX: string;
                TAXES: {};
                FEE: string;
                NAME: string;
                ID: number;
                TOTAL: string;
            };
        };
        NET: string;
        TAXES_TOTAL: string;
        TAXES_TOTALS: {
            AMOUNT: string;
            ID: number;
            IS_PASS_THROUGH_TO_OWNER: boolean;
            NAME: string;
            RATE: number;
        }[];
    };
    TAX: {
        TAXES: {
            AMOUNT: string;
            ID: number;
            IS_PASS_THROUGH_TO_OWNER: boolean;
            NAME: string;
            RATE: number;
        }[];
        TOTAL: string;
        WITHHELD: {
            MRDT: string;
            PST: string;
        };
    };
    TYPE: string;
};
export declare const initialLocationData: {
    COUNTRIES: NameIdItem[];
    REGIONS: LocationDataRegion[];
    AREAS: NameIdItem[];
    RESORTS: LocationDataResort[];
    DEVELOPMENTS: LocationDataDevelopment[];
    PROPERTY_CATEGORIES: NameIdItem[];
};
export declare const RESERVATION_SETTINGS: {
    DEPOSIT_PERCENTAGE: number;
    BALANCE_DAYS_BEFORE_ARRIVAL: number;
    BOOKING_GATEWAY_MODE_ID: number;
};
export {};
