/** Produces a url for use in the React Web App
 ** ex: https://staging.alluradirect.com/guest/booking/1234
 */
export declare const generateGuestBookingPageLink: ({ baseUrl, bookingId }: {
    baseUrl: string;
    bookingId: string | number;
}) => string;
