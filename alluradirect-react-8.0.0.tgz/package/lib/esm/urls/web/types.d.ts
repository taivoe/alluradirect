export declare enum GuestURLPathsEnum {
    booking = "guest/booking"
}
